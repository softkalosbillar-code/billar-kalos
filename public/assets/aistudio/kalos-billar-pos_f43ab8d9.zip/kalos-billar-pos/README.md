# Kalos Billar Club — Punto de Venta (POS)

Web App **Punto de Venta para billar**, 100 % responsive (Android, iPhone, tablet y escritorio), con
**menú de iconos**, **tema oscuro premium minimalista** y el logo de **Kalos Billar Club**.

> Renta de mesas por **tiempo cronometrado exacto** + venta de productos (cerveza, refrescos, botana)
> agregados a la cuenta de la mesa, con **IVA 16 %**, turnos de caja y reportes.

---

## ✨ Funcionalidades implementadas

| Módulo | Detalle |
| --- | --- |
| 🎱 **Mesas** | Tablero en tiempo real: libre / rentada / pausada / limpieza / mantenimiento. Tarifa por tipo de mesa. |
| ⏱ **Renta por tiempo** | Cronómetro por mesa con **inicio, pausa y reanudar**. Tiempo facturable = transcurrido − pausas. |
| 💰 **Cobro por tiempo** | Orden canónico: **mínimo → redondeo** (exacto / minuto / cuarto de hora / hora) × tarifa/hora. |
| 🍺 **Cuenta de mesa (tab)** | Agregar productos (cerveza, refresco, botana) a la cuenta de la mesa mientras se renta. |
| 🧾 **Cobro** | IVA 16 % por línea, propina opcional, métodos de pago (efectivo/tarjeta/transferencia/otro), recibo. |
| 📦 **Productos** | Catálogo con categorías, precio, stock y emoji. Alta/edición (admin). |
| 📈 **Ventas** | Historial de tickets cerrados (hoy / todas). |
| 🏦 **Caja** | Apertura/cierre de turno con arqueo y resumen por método de pago. |
| 📊 **Reportes** | KPIs: ventas hoy, horas rentadas, ticket promedio, mesas ocupadas; top productos; ventas por mesa. |
| 🔐 **Roles** | Cajero y Administrador (admin ve Reportes y Ajustes). |
| 📱 **PWA** | Instalable, manifiesto + iconos, funciona offline (demo local). |

---

## 🧭 Investigación previa (resumen)

La investigación se realizó en 4 frentes y quedó documentada en la carpeta [`docs/`](docs/):

1. **`docs/informe_pos_billar.md`** — Funcionalidades de un POS y su adaptación al billar. Conclusión clave:
   un POS de billar es un **híbrido** entre POS de bar (cuenta abierta, productos a la mesa) y
   sistema de **recursos rentables por tiempo** (mesas, temporizador, tarifa por hora/fracción). La mayor
   fuga de ingresos no es fraude, sino **facturación manual e inconsistente del tiempo**.
2. **`docs/due-diligence-pos-billar.md`** — 14 repositorios de GitHub evaluados. No existe un POS open-source
   maduro específico de billar; los más útiles como referencia de stack son los React/TS/Tailwind y los
   que ya usan Firestore.
3. **`docs/renta-mesa-billar-especificacion.md`** — Especificación técnica del cobro por tiempo: máquinas de
   estado (mesa + cuenta), **reloj del servidor como fuente de verdad**, fórmula
   `elapsed = (fin − inicio) − Σ(resume − pause)`, orden mínimo→redondeo, IVA y casos borde.
4. **`docs/kalos-pos-guia-diseno.md`** — Guía de diseño: paleta oscura con acento oro `#E6B349`, tipografía
   Inter/Sora/JetBrains Mono, sistema de iconos (lucide-react), navegación rail/bottom-bar y micro-interacciones.

---

## 🛠 Stack

- **React 18 + Vite 5 + TypeScript**
- **Tailwind CSS 3** (tokens de la guía de diseño)
- **lucide-react** (iconos)
- **Firebase 10** (Firestore + Auth + Hosting)
- **react-router-dom 6** (HashRouter → funciona también abriendo `dist/index.html`)

### Arquitectura

```
src/
├── lib/          # Dominio puro (sin UI): types, time (cronómetro/redondeo), billing, money, format, seed
├── data/         # Repositorio: Store (interfaz) → LocalStore (demo) | FirestoreStore (Firebase)
├── state/        # AppContext (estado global + acciones + toasts)
├── components/   # Shell (menú de iconos), TableCard, ProductTile, Modal, Logo
└── screens/      # Login, Mesas, CuentaMesa, Productos, Ventas, Caja, Reportes, Ajustes
```

La **lógica de negocio vive en `lib/`** (pura y testeable), separada de la persistencia (`data/`) y de la
UI (`screens/`). Esto permite cambiar de modo demo a Firebase sin tocar la lógica.

---

## 🚀 Ejecutar en local

```bash
pnpm install
pnpm dev        # http://localhost:5173
pnpm build      # genera dist/
pnpm preview    # sirve la build de producción
```

Por defecto corre en **modo demo** (`VITE_DEMO_MODE=true`): los datos viven en `localStorage`, sin backend.
Entra como **Cajero** o **Administrador** desde la pantalla de inicio.

---

## 🔥 Desplegar en infraestructura Google (Firebase)

1. Crea un proyecto en [console.firebase.google.com](https://console.firebase.google.com) y habilita
   **Firestore** y **Authentication** (proveedor anónimo).
2. Copia `.env.example` a `.env.local` y pega la config de tu app web
   (Configuración del proyecto → Tus apps → App web).
3. Pon `VITE_DEMO_MODE=false` en `.env.local`.
4. Instala Firebase CLI y despliega:

```bash
npm i -g firebase-tools
firebase login
firebase use <tu-proyecto>
pnpm build
firebase deploy
```

5. Para el primer arranque, crea las colecciones semilla (o déjalas crearse solas con las reglas).

> `firestore.rules` trae una regla inicial (solo usuarios autenticados). Para producción, endurecer con
> Custom Claims (admin/cajero) y sellar los timestamps de renta desde una **Cloud Function** con Admin SDK
> (ver sección "Endurecer" abajo).

---

## 📦 Empaquetar en ZIP

```bash
pnpm build
# el proyecto completo (sin node_modules/dist) se puede comprimir tal cual:
```

El entregable `kalos-billar-pos.zip` incluye el código fuente + `dist/` (la app ya compilada, lista para
subir a cualquier hosting estático o Firebase).

---

## 🎨 Identidad visual

- Logo: `public/logo-black.png` (fondo negro) y `public/logo-transparent.png`.
- Paleta: fondo `#0B0B0C`, superficies `#121214…`, acento oro `#E6B349`, verde `#34D399`, rojo `#F87171`.
- Tipografía: Inter (UI), Sora (display), JetBrains Mono (cronómetro/importes).

---

## 🔒 Endurecer para producción (checklist)

- [ ] Roles reales con **Firebase Auth + Custom Claims** (`admin` / `cajero`) y reglas por colección.
- [ ] Sellar timestamps (`startedAt`, `pauses`, `endedAt`) con `FieldValue.serverTimestamp()` desde una
      Cloud Function con Admin SDK, para que el reloj no dependa del dispositivo del cajero.
- [ ] Transacciones Firestore para "una sola sesión activa por mesa" y cierres atómicos.
- [ ] Cierres automáticos de cuentas abandonadas y tope de tiempo facturable.
- [ ] Impresión de tickets (impresora térmica 80 mm) vía `print()` o SDK de impresora.
