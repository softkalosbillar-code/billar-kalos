/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#0B0B0C',
        surface: {
          1: '#121214',
          2: '#17181B',
          3: '#1E1F24',
          4: '#25262C',
        },
        brand: {
          DEFAULT: '#E6B349',
          hover: '#F0C570',
          pressed: '#C99A32',
          soft: 'rgba(230,179,73,0.14)',
          on: '#171008',
        },
        ink: {
          1: '#F4F4F5',
          2: '#A1A1AA',
          3: '#7A7A83',
        },
        success: '#34D399',
        warning: '#FBBF24',
        danger: '#F87171',
        info: '#38BDF8',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Sora', 'Inter', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'monospace'],
      },
      borderRadius: {
        card: '16px',
        modal: '20px',
      },
      boxShadow: {
        card: '0 1px 2px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.04)',
        popover: '0 8px 24px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.06)',
        modal: '0 16px 48px rgba(0,0,0,0.6)',
      },
    },
  },
  plugins: [],
}
