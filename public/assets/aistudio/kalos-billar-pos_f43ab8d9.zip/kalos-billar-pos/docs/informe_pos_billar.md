# Sistema POS para Salas de Billar (Renta de Mesas por Tiempo)
### Informe técnico — Funcionalidades imprescindibles, flujo de negocio, modelo de datos y reglas de cobro

> **Alcance:** determinar qué funcionalidades son realmente necesarias en un POS moderno y cómo se adaptan al caso específico de una **sala de billar/snooker con mesas rentadas por tiempo**. Basado en fuentes 2024–2026 (documentación de producto, guías de operación y guías financieras del sector). Los nombres y precios citados son ilustrativos del mercado; tu mercado local define los valores reales.

---

## 1. Resumen ejecutivo

Un POS de billar **no es un POS minorista con una función añadida**. Es un híbrido entre:

- un **POS de bar/restaurante** (cuenta abierta/"tab", productos a la mesa, split de cuenta, cocina/barra), y
- un **sistema de gestión de recursos rentables por tiempo** (mesas/pistas como recurso, temporizador, tarifa por hora/fracción, pausa/reanudar, tarifas por horario).

La conclusión recurrente de las fuentes del sector es la misma: **el mayor "robo silencioso" de ingresos no es el fraude, sino la facturación manual del tiempo** — redondear hacia abajo, olvidar iniciar/detener el temporizador, y la inconsistencia entre turnos. Por eso el **temporizador automático por segundo/minuto con tarifas aplicadas por reglas** es la funcionalidad #1 de este tipo de negocio, por encima incluso del catálogo o del inventario.

---

## 2. (a) Lista priorizada de funcionalidades

### Nivel 0 — Imprescindibles (sin estas, no es un POS de billar, es una calculadora)

| # | Funcionalidad | Por qué es imprescindible | Referencia del sector |
|---|---|---|---|
| 1 | **Gestión de mesas como recurso y tablero de ocupación en tiempo real** | Cada mesa es un recurso bookeable con estado (libre/ocupada/reservada/fuera de servicio). Ver toda la sala de un vistazo y proteger contra doble reserva. | [CuePoint — Billiard Hall POS](https://www.cuepoint.cloud/use-cases/billiard-hall-pos); [Cerevantix Odoo](https://apps.odoo.com/apps/modules/17.0/cerevantix_pos_time_based_product) |
| 2 | **Temporizador de sesión por segundo/minuto con inicio/parada/pausa/reanudar** | El cobro depende del tiempo real transcurrido, no de lo que el cajero recuerde. La pausa evita cobrar descansos o interrupciones. | [CuePoint — Time-Based Billing](https://www.cuepoint.cloud/blog/billiard-hall-time-based-billing-setup); [NX Restaurant — Timed Items](https://help.joinnx.com/hc/en-us/articles/39854187855892-Setting-Up-Time-Based-Menu-Items) |
| 3 | **Cobro automático por hora/fracción con redondeo configurable y cargo mínimo** | El sistema calcula el total (no el cajero). Redondeo exacto/15 min/30 min y un mínimo (p. ej. 30–60 min) que protege sesiones cortas. | [CuePoint — Pricing](https://www.cuepoint.cloud/blog/how-to-price-pool-table-time) |
| 4 | **Cuenta abierta ("tab") por mesa + agregar productos a la mesa** | El cliente consume productos (cervezas, snacks) que se cargan a la mesa abierta; al cerrar, tiempo + productos en un solo ticket. | [Deelo — POS at the lane](https://www.deelo.ai/blog/bowling-alley-management-software); [CuePoint POS](https://www.cuepoint.cloud/use-cases/billiard-hall-pos) |
| 5 | **Tarifas por horario/tipo de mesa (pico vs. valle, happy hour)** | Una mesa a las 2 PM del martes no vale lo mismo que el sábado a las 10 PM. La tarifa correcta debe aplicarse sola al iniciar el temporizador. | [CuePoint — Pricing](https://www.cuepoint.cloud/blog/how-to-price-pool-table-time); [NX — Price Points](https://help.joinnx.com/hc/en-us/articles/39854187855892-Setting-Up-Time-Based-Menu-Items) |
| 6 | **Cobro y métodos de pago (efectivo, tarjeta, wallet, transferencia, mixto/split)** | Múltiples métodos por ticket y pago dividido entre jugadores. Registrar el método sin procesar el pago también es válido en mercados con lectores independientes. | [CuePoint POS](https://www.cuepoint.cloud/use-cases/billiard-hall-pos); [Square](https://squareup.com/au/en/the-bottom-line/operating-your-business/best-retail-pos-system) |
| 7 | **Roles y permisos + pista de auditoría** | El cajero inicia/pausa/cierra; pero modificar hora de inicio, anular un mínimo o descontar requiere **nivel de supervisor con registro obligatorio**. | [CuePoint — Billing](https://www.cuepoint.cloud/blog/billiard-hall-time-based-billing-setup); [CueDesk](https://apps.apple.com/tr/app/cuedesk-snooker-manager/id6763288911) |
| 8 | **Ticket/recibo detallado (hora inicio, hora fin, duración, tarifa)** | El recibo debe mostrar inicio/fin/duración de cada línea cronometrada; es la herramienta que resuelve disputas de cobro. | [Cerevantix Odoo](https://apps.odoo.com/apps/modules/17.0/cerevantix_pos_time_based_product) |
| 9 | **Catálogo de productos + inventario con descuento automático** | Productos de barra/tienda (cerveza, refrescos, tacos, renta de tiza) con deducción automática de stock y alerta de bajo inventario. | [Square](https://squareup.com/au/en/the-bottom-line/operating-your-business/best-retail-pos-system); [CuePoint](https://www.cuepoint.cloud/use-cases/pool-hall-inventory) |
| 10 | **Cierre de turno y caja (X/Z, arqueo, efectivo esperado vs. real)** | Reconciliar por cajero/turno: efectivo, tarjetas y el total de sesiones y productos. El cierre diario debe cuadrar tiempo + barra en un solo libro. | [Deelo](https://www.deelo.ai/blog/bowling-alley-management-software) |
| 11 | **Reportes: ingresos por mesa, tiempo vendido, utilización, producto más vendido** | Ver §4. Sin esto no puedes saber si una mesa pierde dinero. | [Beancount](https://beancount-cms-v2.onbex.co/blog/2026/07/13/billiards-pool-hall-bookkeeping-guide) |

### Nivel 1 — Muy deseables (alto impacto, se justifican rápido)

- **Clientes y membresías/loyalty:** perfiles, historial, tarifa de miembro, crédito prepago, horas gratis. La fidelización es clave porque el costo de adquisición en un barrio es alto. [CuePoint — Memberships](https://www.cuepoint.cloud/use-cases/billiard-hall-memberships); [CueDesk](https://apps.apple.com/tr/app/cuedesk-snooker-manager/id6763288911).
- **Reservas de mesa con depósito:** reduce no-shows; el depósito se aplica al ticket final. [CuePoint — Reservations](https://www.cuepoint.cloud/use-cases/billiard-hall-reservations).
- **Transferencia de sesión entre mesas sin perder el tiempo acumulado** (si un grupo se mueve). [CuePoint — Billing](https://www.cuepoint.cloud/blog/billiard-hall-time-based-billing-setup).
- **Precio dinámico por franjas horarias y días de la semana** (tiers valle/estándar/pico/premium). [Deelo](https://www.deelo.ai/blog/bowling-alley-management-software); [CuePoint](https://www.cuepoint.cloud/blog/how-to-price-pool-table-time).
- **Corte automático de nuevas sesiones** (p. ej. no abrir mesas 30–60 min antes del cierre). [CuePoint — Billing](https://www.cuepoint.cloud/blog/billiard-hall-time-based-billing-setup).
- **Modo offline / local-first con sincronización** (ver §5).
- **Split de cuenta y merge de tabs** (el papá pidió en barra antes de que su mesa estuviera lista). [Deelo](https://www.deelo.ai/blog/bowling-alley-management-software).

### Nivel 2 — Deseables (escala, marketing, operación avanzada)

- Multilocal / multi-sucursal con finanzas aisladas por sitio. [CueDesk](https://apps.apple.com/tr/app/cuedesk-snooker-manager/id6763288911).
- Pedido por QR desde la mesa (el cliente escanea y pide a la barra sin caminar). [CuePoint — QR ordering](https://www.cuepoint.cloud/use-cases/billiard-hall-qr-ordering).
- Ligas y torneos (rosters, cuotas semanales, fondos de premios) — más relevante para snooker competitivo; manejar cuotas como **ingreso diferido**. [Deelo](https://www.deelo.ai/blog/bowling-alley-management-software); [Beancount](https://beancount-cms-v2.onbex.co/blog/2026/07/13/billiards-pool-hall-bookkeeping-guide).
- Notificaciones/alertas de tiempo (recordar al cajero o al cliente cuando la sesión supera N minutos).
- Marketing por email/SMS de "vuelve este mes" y analítica de cliente repetido. [Deelo](https://www.deelo.ai/blog/bowling-alley-management-software).

---

## 3. (b) Flujo de negocio del billar en pasos

**Paso 1 — Llega el cliente / asignación de mesa.**
El cajero ve el tablero de ocupación, elige una mesa libre (o la reserva existente). Verifica tipo de mesa (7 ft bar box vs. 9 ft torneo) porque determina la tarifa.

**Paso 2 — Apertura de sesión (inicio del temporizador).**
Al tocar "abrir mesa" el sistema: (a) crea una **cuenta abierta (tab)** asociada a esa mesa, (b) **inicia automáticamente el temporizador** con la tarifa que corresponde a la hora/día actuales, y (c) opcionalmente aplica el "auto-ring" del cargo por tiempo (configuración recomendada por NX para mesas de pool: el ítem cronometrado se agrega solo al abrir). [NX — Auto-Ring](https://help.joinnx.com/hc/en-us/articles/39854206361620-Auto-Ringing-Menu-Items-When-Starting-a-Table).

**Paso 3 — Consumo durante la sesión.**
El cliente pide productos; se agregan a la cuenta de esa mesa. Si hay descanso o falla de mesa, se **pausa** el temporizador (el tiempo pausado no se cobra). Si el grupo se mueve, la sesión se **transfiere** a otra mesa conservando el tiempo. [CuePoint — Billing](https://www.cuepoint.cloud/blog/billiard-hall-time-based-billing-setup).

**Paso 4 — Cierre de cuenta y cobro.**
Al "cerrar mesa", el sistema **detiene el temporizador**, aplica redondeo y cargo mínimo, y presenta en una sola pantalla: **tiempo de mesa + productos + descuentos/membresía = total**. Se registra el método de pago (efectivo/tarjeta/wallet/transferencia) y se imprime el ticket con inicio/fin/duración. [CuePoint POS](https://www.cuepoint.cloud/use-cases/billiard-hall-pos).

**Paso 5 — Liberación de mesa.**
El pago marca la mesa como **libre** y disponible en el tablero. El sistema registra la sesión en el log para auditoría y reportes. [Cerevantix Odoo](https://apps.odoo.com/apps/modules/17.0/cerevantix_pos_time_based_product).

**Paso 6 — Cierre de turno.**
Al final del turno, el cajero hace arqueo de caja; el sistema cuadra **tiempo vendido + barra/tienda** en un solo cierre diario, con desglose efectivo vs. tarjeta. [Deelo](https://www.deelo.ai/blog/bowling-alley-management-software).

---

## 4. Métricas y reportes clave para el dueño

> El reporte financiero estándar **no muestra** lo más importante en este negocio: la utilización de mesas. Hay que construirlo desde el POS. [Beancount](https://beancount-cms-v2.onbex.co/blog/2026/07/13/billiards-pool-hall-bookkeeping-guide).

| Métrica | Fórmula | Para qué sirve |
|---|---|---|
| **Ingreso por mesa-hora disponible (RevPASH de mesas)** | Ingreso de mesas ÷ (nº mesas × horas abierto × días) | Detecta si la tarifa publicada, los descuentos y el pricing pico/valle funcionan. Ej.: 20 mesas × 12 h × 30 días = 7 200 mesa-horas; $50 400 ÷ 7 200 = **$7/mesa-hora**. |
| **Utilización de mesas (%)** | Horas vendidas ÷ horas disponibles | Identifica huecos por franja/día. "58 % entre semana, 91 % en fin de semana" es la respuesta que un banco/inversor quiere oír. |
| **Ventas por mesa** | Ingreso total (tiempo + productos) por mesa | Detecta mesas "muertas" o con bajo atractivo, y qué tipo de mesa rinde más. |
| **Tiempo vendido y duración promedio de sesión** | Suma de duración; promedio por sesión | Mide comportamiento del cliente y valida el redondeo. |
| **Mix de ingresos (tiempo vs. barra/tienda vs. membresía)** | % de cada línea sobre el total | El **tiempo de mesa** tiene margen casi 100 %; la **barra** 70–80 % (cerveza) y la **comida** 28–35 % de costo. Separarlos es la clave del diagnóstico. |
| **Attach rate de barra por mesa-hora (F&B por mesa-hora)** | Ingreso barra ÷ horas de mesa vendidas | ¿Los clientes piden de beber mientras juegan? Un valor bajo = problema de venta/attach. [Deelo](https://www.deelo.ai/blog/bowling-alley-management-software) |
| **Producto más vendido (y margen)** | Ranking por unidades e ingreso | Ajusta catálogo y precios de barra. |
| **Costo laboral por turno/día-parte** | Costo de nómina ÷ ingreso del turno | La carga laboral oscila mucho entre un martes tranquilo y un viernes de torneo; promediar mensual esconde el exceso de personal. |
| **Tasa de cliente repetido** | % de clientes que regresan en el trimestre | Requiere capturar email/teléfono; es la palanca de fidelización. [Deelo](https://www.deelo.ai/blog/bowling-alley-management-software) |

---

## 5. Consideraciones de hardware y software

### Hardware (mínimo viable → completo)

- **Tablet o teléfono** (Android/iOS o web) como terminal principal: suficiente para iniciar/detener mesas, cobrar y ver el tablero. CuePoint destaca que corre en navegador sin hardware especial. [CuePoint](https://www.cuepoint.cloud/use-cases/billiard-hall-pos).
- **Impresora de tickets** (térmica 80 mm) con soporte de conexión (USB/LAN/Bluetooth) — el recibo con duración es esencial para transparencia. [Cerevantix](https://apps.odoo.com/apps/modules/17.0/cerevantix_pos_time_based_product).
- **Cajón de dinero** (opcional si predomina tarjeta, pero estándar si hay efectivo): apertura automática al cobro en efectivo y control en cierre. [NX — Drawers](https://help.joinnx.com/hc/en-us/articles/36805263671700-Devices-Drawers-Configuring-a-Cash-Drawer).
- **Lector de pagos** (EMV/contactless) si el POS procesa tarjetas; si usas lectores bancarios independientes, el POS solo registra el método. [Square](https://squareup.com/au/en/the-bottom-line/operating-your-business/best-retail-pos-system).
- **Escaner de código de barras** (útil para barra/tienda, no para mesas).
- **Pantalla de mostrador/segundo monitor** opcional para que el cliente vea el tiempo corriendo.

### Software (requisitos de arquitectura)

- **Nube vs. local:** la nube da acceso remoto, multi-sucursal y sincronización automática; el local da control pero exige mantenimiento. La elección afecta al offline. [Square](https://squareup.com/au/en/the-bottom-line/operating-your-business/best-retail-pos-system).
- **Offline / local-first:** en un sótano o sala con wifi inestable, el POS **debe** seguir abriendo/cerrando mesas y cobrando sin conexión, y sincronizar al reconectar. Los patrones "offline-first con sync local-first" son el estándar moderno para retail. [Retailer-POS (offline-first)](https://github.com/codedbyhassan/Retailer-POS).
- **Multiusuario y roles:** cajero / supervisor / administrador con permisos granulares y auditoría de toda acción sensible (override de tiempo, anular mínimo, descuentos). [CuePoint — Staff & Roles](https://www.cuepoint.cloud/use-cases/billiard-hall-staff-management).
- **Sincronización entre terminales y reloj único:** el temporizador debe vivir **en el servidor/estado compartido**, no en el reloj de cada tablet, para que pausar en un dispositivo se refleje en todos. El estado de cada mesa debe ser único y consistente en todos los terminales (una mesa no puede estar "ocupada" en dos pantallas). [Cerevantix](https://apps.odoo.com/apps/modules/17.0/cerevantix_pos_time_based_product).
- **Seguridad/PCI** si procesas tarjetas; tokenización y cumplimiento PCI DSS. [Square — PCI](https://squareup.com/au/en/the-bottom-line/operating-your-business/pci-compliance).

---

## 6. (c) Modelo de datos sugerido (entidades y relaciones)

### Entidades principales

```
Ubicacion (sucursal)
  └── Mesa (recurso rentable)
        · id, nombre ("Mesa 1"), tipo_mesa_id, estado (libre|ocupada|reservada|mantenimiento)
        · tarifa_predeterminada_id, capacidad

TipoMesa
  · id, nombre ("7 ft bar box", "9 ft torneo", "snooker 12 ft")
  · costo_hora_base (referencia de mantenimiento)

Tarifa (regla de precio por tiempo)
  · id, tipo_mesa_id, dia_semana (lun..dom o "*"), hora_inicio, hora_fin
  · precio_por_hora / precio_por_minuto, tipo ("normal"|"happy_hour"|"pico"|"promo")
  · aplica_desde / aplica_hasta (vigencia de la promo)

Sesion (la renta de mesa activa o cerrada)
  · id, mesa_id, cliente_id (nullable), usuario_id (quien abre), turno_id
  · inicio, fin (nullable), estado (activa|pausada|cerrada|cancelada)
  · tiempo_pausado_acumulado (seg), tarifa_aplicada_id (snapshot)
  · redondeo, cargo_minimo_aplicado, override: quien/razon (auditoría)

Cliente
  · id, nombre, telefono, email, membresia_id, saldo_credito

Membresia
  · id, nombre, descuento_tarifa (%), descuento_producto (%), horas_incluidas

Producto (catálogo)
  · id, nombre, categoria_id, precio, es_cronometrado (bool), costo (para margen)
  · unidad ("unidad"|"hora"|"minuto"), sku/codigo_barras

Categoria
  · id, nombre ("cerveza", "snacks", "renta", "mesa tiempo")

Inventario (stock por producto/ubicación)
  · producto_id, ubicacion_id, cantidad_disponible, umbral_bajo

Pedido (tab/cuenta abierta de una mesa o de barra)
  · id, mesa_id (nullable, null = venta directa barra), cliente_id, usuario_id, turno_id
  · estado (abierto|cerrado), total, subtotal, impuestos, propina

LineaPedido
  · id, pedido_id, producto_id, tipo ("tiempo"|"producto"|"descuento"|"cargo")
  · cantidad, precio_unitario, descuento
  · inicio, fin, duracion_seg (solo para líneas de tiempo)
  · sesion_id (referencia a la sesión cronometrada)

Pago
  · id, pedido_id, metodo (efectivo|tarjeta|wallet|transferencia|mixto), monto
  · referencia, fecha, usuario_id

Turno (turno de caja)
  · id, usuario_id, apertura (hora + efectivo inicial), cierre, efectivo_esperado, efectivo_real, diferencia

Usuario / Empleado
  · id, nombre, pin, rol_id, ubicacion_id

Rol / Permiso
  · id, nombre; permisos: abrir_mesa, pausar, cerrar, cobrar, override_tiempo,
    anular_minimo, descuento, cierre_turno, ver_reportes, gestion_catalogo

Ticket / Recibo (auditoría)
  · id, pedido_id, numero, fecha, contenido (inicio/fin/duracion por línea), usuario_id
```

### Relaciones clave

- `Mesa 1—N Sesion` (una mesa tiene muchas sesiones a lo largo del tiempo, pero **solo una activa** a la vez → restricción de unicidad sobre `mesa_id WHERE estado = 'activa'`).
- `TipoMesa 1—N Mesa` y `TipoMesa 1—N Tarifa` (las tarifas se definen por tipo de mesa y franja).
- `Sesion 1—1..N LineaPedido` (la línea de tipo "tiempo" enlaza con la sesión).
- `Mesa 1—N Pedido` (un tab está ligado a una mesa; una venta directa de barra tiene `mesa_id = NULL`).
- `Pedido 1—N LineaPedido`, `Pedido 1—N Pago` (permite split y métodos mixtos).
- `Usuario 1—N Sesion / Pedido / Pago / Turno` (toda acción queda trazada a un usuario).
- `Cliente 1—N Sesion / Pedido`, `Cliente N—1 Membresia`.

> **Nota de diseño:** el **tiempo debe guardarse como dato bruto** (inicio, fin, tiempo pausado) y el **precio calcularse/almacenarse como snapshot** de la tarifa en el momento de abrir. Guardar solo "precio final" sin el desglose de tiempo impide auditorías y reportes de utilización. [Cerevantix](https://apps.odoo.com/apps/modules/17.0/cerevantix_pos_time_based_product); [Beancount](https://beancount-cms-v2.onbex.co/blog/2026/07/13/billiards-pool-hall-bookkeeping-guide).

---

## 7. (d) Reglas de negocio para el cobro por tiempo

**R1 — Modelo de tarifa.** Por mesa (más simple y común en juego libre) o por persona. Por mesa: una tarifa sin importar cuántos jueguen. Definir tarifa por **tipo de mesa**. [CuePoint — Billing](https://www.cuepoint.cloud/blog/billiard-hall-time-based-billing-setup).

**R2 — Precisión del cronómetro.** Medir por segundo o minuto (nunca por timestamps manuales). El cargo = `duración_efectiva × tarifa_por_minuto`. [Cerevantix](https://apps.odoo.com/apps/modules/17.0/cerevantix_pos_time_based_product).

**R3 — Redondeo.** Uno de: **exacto** (por segundo/minuto), **bloque de 15 min**, **bloque de 30 min**, **hora completa**. Aplicar **siempre hacia arriba** al bloque elegido y de forma **consistente** en todos los turnos (la inconsistencia genera disputas). [CuePoint — Billing](https://www.cuepoint.cloud/blog/billiard-hall-time-based-billing-setup); [NX — Rounding](https://help.joinnx.com/hc/en-us/articles/39854187855892-Setting-Up-Time-Based-Menu-Items).

**R4 — Cargo mínimo.** Mínimo de 30 o 60 min por sesión, aplicado **automáticamente** (no a discreción del cajero), para cubrir el costo de preparación/limpieza y desincentivar sesiones de 10 min en hora pico. [CuePoint — Pricing](https://www.cuepoint.cloud/blog/how-to-price-pool-table-time).

**R5 — Tarifas por franja (pico/valle) y promos.** Reglas por día de semana + hora (valle entre semana, estándar, pico viernes/sábado, "overnight", happy hour, estudiante, miembro). Deben **activarse/desactivarse solas** según el reloj; el cajero **no elige** la tarifa. [CuePoint — Pricing](https://www.cuepoint.cloud/blog/how-to-price-pool-table-time); [NX — Price Points](https://help.joinnx.com/hc/en-us/articles/39854187855892-Setting-Up-Time-Based-Menu-Items).

**R6 — Tarifa congelada (snapshot) al abrir.** La tarifa aplicada se fija al abrir la sesión; si una promo termina a mitad de la sesión, definir si la sesión conserva su tarifa o se prorratea (recomendado: conservar la tarifa de apertura para evitar disputas, o prorratear por segmentos como hace ServiceCore). [ServiceCore — Proration](https://support.servicecore.com/hc/en-us/articles/360035751111-Proration-Overview).

**R7 — Pausa/reanudar.** El tiempo pausado **no se cobra** (descansos, falla de mesa). La pausa queda registrada en el log. [Cerevantix](https://apps.odoo.com/apps/modules/17.0/cerevantix_pos_time_based_product).

**R8 — Transferencia entre mesas.** Conserva el tiempo acumulado; cambia la mesa asociada sin reiniciar el cronómetro. [CuePoint — Billing](https://www.cuepoint.cloud/blog/billiard-hall-time-based-billing-setup).

**R9 — Override de supervisor.** Corregir hora de inicio/fin o anular el mínimo exige **rol supervisor + razón + registro de auditoría** indeleble. [CuePoint — Billing](https://www.cuepoint.cloud/blog/billiard-hall-time-based-billing-setup); [Cerevantix](https://apps.odoo.com/apps/modules/17.0/cerevantix_pos_time_based_product).

**R10 — Corte de apertura.** No abrir sesiones nuevas en los últimos 30–60 min antes del cierre; comunicarlo al cliente al iniciar la sesión. [CuePoint — Billing](https://www.cuepoint.cloud/blog/billiard-hall-time-based-billing-setup).

**R11 — Depósito en reservas.** Para reservas de grupos: depósito = mínimo o primera hora; se aplica al ticket final; política clara de no-show. [CuePoint — Billing](https://www.cuepoint.cloud/blog/billiard-hall-time-based-billing-setup).

**R12 — Walk-out / tab abierto sin pagar.** Procedimiento para marcar un tab "en riesgo" antes de que el cliente llegue a la puerta; el cobro por tab abierto solo funciona si cerrar tabs es un hábito entrenado. [CuePoint — Billing](https://www.cuepoint.cloud/blog/billiard-hall-time-based-billing-setup).

**R13 — Falla de mesa a mitad de sesión.** Política predefinida: pausar la sesión, transferir a otra mesa, o aplicar descuento; nunca improvisar en el mostrador. [CuePoint — Billing](https://www.cuepoint.cloud/blog/billiard-hall-time-based-billing-setup).

---

## 8. Fuentes citadas

1. [CuePoint — How to Price Pool Table Time: Rates, Minimums, and Promos (2026)](https://www.cuepoint.cloud/blog/how-to-price-pool-table-time)
2. [CuePoint — How to Set Up Time-Based Billing at Your Billiard Hall: Rates, Rounding, and Automatic Cutoffs (2026)](https://www.cuepoint.cloud/blog/billiard-hall-time-based-billing-setup)
3. [CuePoint — Billiard Hall POS System: Table Time + Orders in One Checkout](https://www.cuepoint.cloud/use-cases/billiard-hall-pos)
4. [CuePoint — Pool hall inventory management software](https://www.cuepoint.cloud/use-cases/pool-hall-inventory)
5. [CuePoint — Billiard hall membership software](https://www.cuepoint.cloud/use-cases/billiard-hall-memberships)
6. [CuePoint — Billiard hall QR ordering](https://www.cuepoint.cloud/use-cases/billiard-hall-qr-ordering)
7. [CuePoint — Staff & roles](https://www.cuepoint.cloud/use-cases/billiard-hall-staff-management)
8. [NX Restaurant — Setting Up Time-Based Menu Items (2025)](https://help.joinnx.com/hc/en-us/articles/39854187855892-Setting-Up-Time-Based-Menu-Items)
9. [NX Restaurant — Auto-Ringing Menu Items When Starting a Table (2025)](https://help.joinnx.com/hc/en-us/articles/39854206361620-Auto-Ringing-Menu-Items-When-Starting-a-Table)
10. [NX Restaurant — Configuring a Cash Drawer](https://help.joinnx.com/hc/en-us/articles/36805263671700-Devices-Drawers-Configuring-a-Cash-Drawer)
11. [Cerevantix — POS Time-Based Products (Odoo module, v17–20)](https://apps.odoo.com/apps/modules/17.0/cerevantix_pos_time_based_product)
12. [Deelo — How to Manage Lane Reservations, Leagues, and POS for Bowling Alleys (2026)](https://www.deelo.ai/blog/bowling-alley-management-software)
13. [Beancount.io — Billiards and Pool Hall Bookkeeping: Table Time, League Revenue, and Bar Margin (2026)](https://beancount-cms-v2.onbex.co/blog/2026/07/13/billiards-pool-hall-bookkeeping-guide)
14. [Square — How to Choose the Best Retail POS System (2025)](https://squareup.com/au/en/the-bottom-line/operating-your-business/best-retail-pos-system)
15. [Square — What Is PCI Compliance?](https://squareup.com/au/en/the-bottom-line/operating-your-business/pci-compliance)
16. [CueDesk — Snooker Manager App (App Store)](https://apps.apple.com/tr/app/cuedesk-snooker-manager/id6763288911)
17. [ServiceCore — Proration Overview (2026)](https://support.servicecore.com/hc/en-us/articles/360035751111-Proration-Overview)
18. [GitHub — Retailer-POS: offline-first POS (local-first sync)](https://github.com/codedbyhassan/Retailer-POS)

---

*Informe generado a partir de fuentes públicas 2024–2026. Los valores monetarios citados (tarifas por hora, márgenes, costos de re-fieltrado) son rangos ilustrativos del sector y deben ajustarse al mercado local, número de mesas y mix de barra/comida de cada negocio.*
