# Guía de diseño — Kalos Billar Club (Web App POS)

> Web App de punto de venta para billar. Tema **oscuro premium** sobre fondo negro (el logo vive sobre negro). Minimalista, táctil y 100 % responsive. Usuarios: **cajero en tablet** (Android/iPad) y **dueño en escritorio**.
>
> Esta guía está pensada para que un ingeniero implemente CSS + componentes sin decisiones pendientes. Incluye tokens exactos, iconos por función, jerarquía, patrones de componentes, reglas táctiles, micro-interacciones y breakpoints.

---

## 0. Principios rectores (qué es "premium" aquí)

1. **Un solo acento.** Oro/brass para la marca; un verde "fieltro" para lo positivo/confirmado. El resto es gris neutro sobre negro. Máximo 2 acentos por pantalla.
2. **Profundidad por elevación, no por sombras duras.** En tema oscuro las sombras se leen mal; la jerarquía se logra subiendo la luminosidad de las superficies + un hairline superior (luz interior) + blur de fondo.
3. **Feedback en el pointer-down, no en el release.** Todo objetivo táctil responde al instante (escala 0.97).
4. **Números tabulares para dinero y cronómetro.** `font-variant-numeric: tabular-nums` — las cifras no "bailan" al correr el timer.
5. **Menos es más, pero no esconder lo frecuente.** El cajero toca "Mesas / Renta / Cobro" cientos de veces al día: esas acciones van a un toque, sin animaciones que las retrasen.

---

## 1. Dirección visual

### 1.1 Paleta de colores (tokens + Tailwind)

Defínela como CSS custom properties y como colores `brand`/`semantic` en `tailwind.config`. Base **neutra ligeramente cálida** para que el oro no choque (no usar gris azulado como Linear, que va con su acento periwinkle).

| Token | Hex | Tailwind (sugerido) | Uso |
|---|---|---|---|
| `--bg` | `#0B0B0C` | `zinc-950` (custom) | Fondo de la app (canvas) |
| `--surface-1` | `#121214` | — | Sidebar / barra inferior |
| `--surface-2` | `#17181B` | — | Tarjetas, tiles, listas |
| `--surface-3` | `#1E1F24` | — | Popovers, dropdowns, hovers |
| `--surface-4` | `#25262C` | — | Modales, sheets |
| `--border` | `rgba(255,255,255,0.08)` | `white/8` | Hairline por defecto |
| `--border-strong` | `rgba(255,255,255,0.14)` | `white/14` | Borde de inputs en foco |
| `--text-1` | `#F4F4F5` | `zinc-100` | Texto primario |
| `--text-2` | `#A1A1AA` | `zinc-400` | Texto secundario |
| `--text-3` | `#7A7A83` | `zinc-500` | Metadatos, captions |
| `--brand` | `#E6B349` | `brand-500` | **Acento oro** (marca, CTA, mesa activa) |
| `--brand-hover` | `#F0C570` | `brand-400` | Hover del acento |
| `--brand-pressed` | `#C99A32` | `brand-600` | Presionado |
| `--on-brand` | `#171008` | — | Texto/icono sobre oro |
| `--brand-soft` | `rgba(230,179,73,0.14)` | `brand/15` | Tint de selección |
| `--success` | `#34D399` | `emerald-400` | Confirmado, pagado, "cobrar" |
| `--on-success` | `#052E1B` | — | Texto sobre verde |
| `--warning` | `#FBBF24` | `amber-400` | Tiempo cerca del límite, stock bajo |
| `--danger` | `#F87171` | `red-400` | Vencido, anular, destructivo |
| `--info` | `#38BDF8` | `sky-400` | Reservada, info |

> **Contraste verificado (WCAG 2.2):** `--text-1` sobre `--bg` ≈ 17.9:1 (AAA); `--text-2` sobre `--surface-2` ≈ 7.5:1 (AA); `--brand` sobre `--bg` ≈ 10:1 (AA); `--on-brand` sobre `--brand` ≈ 9:1 (AA). `--text-3` solo para texto ≥ 16px bold o 18px normal (AA-large) o elementos no críticos.

```css
:root {
  color-scheme: dark;
  --bg: #0B0B0C;
  --surface-1: #121214;
  --surface-2: #17181B;
  --surface-3: #1E1F24;
  --surface-4: #25262C;
  --border: rgba(255,255,255,.08);
  --border-strong: rgba(255,255,255,.14);
  --text-1: #F4F4F5;
  --text-2: #A1A1AA;
  --text-3: #7A7A83;
  --brand: #E6B349;
  --brand-hover: #F0C570;
  --brand-pressed: #C99A32;
  --on-brand: #171008;
  --brand-soft: rgba(230,179,73,.14);
  --success: #34D399;  --on-success: #052E1B;
  --warning: #FBBF24;  --danger: #F87171;  --info: #38BDF8;
}
```

### 1.2 Tipografía (Google Fonts, licencia OFL — libre)

Carga por `@fontsource` (auto-hospedado, recomendado) o Google Fonts CDN. Tres familias, uso restringido:

| Rol | Fuente | Pesos | Uso |
|---|---|---|---|
| UI / cuerpo | **Inter** (variable) | 400, 500, 600, 700 | Todo texto de interfaz, botones, labels, listas |
| Display / números grandes | **Sora** | 600, 700 | Títulos de página, totales grandes, logo |
| Mono / cronómetro | **JetBrains Mono** | 500, 600 | Cronómetro en vivo, montos en el recibo, códigos |

**Alternativas igual de válidas (OFL):** `Manrope` (cuerpo), `Space Grotesk` (display, más "techy"), `IBM Plex Mono` (mono).

```css
/* Inter con números tabulares + cifras alineadas */
body { font-family: 'Inter', system-ui, sans-serif; font-feature-settings: 'tnum' 1, 'cv11' 1; }
.timer, .amount { font-family: 'JetBrains Mono', ui-monospace, monospace; font-variant-numeric: tabular-nums; }
.display { font-family: 'Sora', 'Inter', sans-serif; }
```

**Escala tipográfica** (en `rem`, respeta el ajuste de tamaño del usuario; `1rem = 16px`):

| Estilo | Tamaño | Peso | Line-height | Tracking | Uso |
|---|---|---|---|---|---|
| Display | `clamp(2rem, 5vw, 2.75rem)` | 700 | 1.05 | `-0.02em` | Total a cobrar, cifras KPI |
| Title 1 | 28px | 600 | 1.2 | `-0.015em` | Título de pantalla |
| Title 2 | 20px | 600 | 1.25 | `-0.01em` | Título de tarjeta/sección |
| Headline | 16px | 600 | 1.4 | 0 | Fila primaria, item del carrito |
| Body | 15px | 400 | 1.5 | 0 | Texto por defecto |
| Callout | 13px | 400 | 1.4 | 0 | Descripción, modificadores |
| Caption | 12px | 500 | 1.3 | `+0.01em` | Badges, labels de nav, metadatos |
| Timer mono | 15px | 600 | 1 | 0 | Cronómetro en vivo |

Regla: **jerarquía por peso + tamaño, no por color** (el color solo baja a `--text-2`/`--text-3`). Máximo 3 tamaños por región de pantalla.

### 1.3 Espaciados (grid de 8pt)

Base `4px`. Usa múltiplos de 8 para márgenes/padding/gaps; `4px` solo para gaps internos (icono↔texto).

`--space-1: 4px · 2: 8px · 3: 12px · 4: 16px · 5: 20px · 6: 24px · 8: 32px · 10: 40px · 12: 48px · 16: 64px`

- Padding de tarjeta: `16px`. Gap de grid de mesas: `12px`. Sección mayor: `32px`. Padding de página (escritorio): `48px`.

### 1.4 Radios

| Elemento | Radio |
|---|---|
| Badges, chips pequeños | `6px` |
| Botones, inputs | `10px` |
| Tarjetas, tiles de producto/mesa | `16px` |
| Modales, sheets (esquinas superiores) | `20px` |
| Pills, avatares | `9999px` |

```css
/* Esquinas continuas estilo iOS (progresivo; degrada a border-radius) */
.card { border-radius: 16px; corner-shape: squircle; }
```

### 1.5 Sombras y profundidad

En oscuro, la profundidad = **superficie más clara + hairline superior interior + (opcional) blur**. Las sombras son un refuerzo sutil, no el mecanismo principal.

| Nivel | Uso | box-shadow |
|---|---|---|
| 0 | Plano | `none` + `border: 1px solid var(--border)` |
| 1 | Tarjeta/tile | `0 1px 2px rgba(0,0,0,.4), inset 0 1px 0 rgba(255,255,255,.04)` |
| 2 | Popover/dropdown | `0 8px 24px rgba(0,0,0,.5), inset 0 1px 0 rgba(255,255,255,.06)` |
| 3 | Modal/sheet | `0 16px 48px rgba(0,0,0,.6)` + scrim `rgba(0,0,0,.5)` |

Materiales translúcidos (barras de navegación):

```css
.nav-chrome {
  background: rgba(18, 18, 20, 0.72);
  backdrop-filter: blur(20px) saturate(160%);
  border-top: 1px solid rgba(255,255,255,.06); /* luz superior, no borde grueso */
}
@media (prefers-reduced-transparency: reduce) {
  .nav-chrome { background: #121214; backdrop-filter: none; }
}
```

---

## 2. Sistema de iconos

**Librería: [`lucide-react`](https://lucide.dev)** (licencia ISC, MIT-compatible; ~1.5k iconos, stroke consistente de 24px, tree-shakeable). Alternativa: `@heroicons/react/24/outline` (MIT, menos iconos). Usa una sola librería en todo el proyecto.

Configuración base:

```tsx
// Icono base: trazo 1.75, 24×24
<Icon strokeWidth={1.75} size={24} aria-hidden="true" />
// Estado activo: relleno sutil + acento
```

### Mapa de iconos por función (lucide-react)

| Función | Icono lucide | Nota |
|---|---|---|
| **Mesas** | `Table2` (o `LayoutGrid`) | Grid/plano de mesas |
| **Renta** | `Timer` (o `Clock3`) | Renta por tiempo |
| **Productos** | `Package` (o `Boxes`) | Catálogo/inventario |
| **Ventas** | `TrendingUp` | Ventas/órdenes abiertas |
| **Reportes** | `BarChart3` (alias actual `ChartColumn`) | Métricas del dueño |
| **Clientes** | `Users` | Directorio de clientes |
| **Caja** | `CashRegister` | Sesión de caja / arqueo |
| **Ajustes** | `Settings` | Configuración |
| **Cronómetro (en vivo)** | `Timer` | Dentro de la tarjeta de mesa |
| **Cerveza / bebida** | `Beer` (alt: `CupSoda`, `Wine`, `Martini`) | Categoría de productos |
| **Botana** | `Popcorn` (alt: `Pizza`, `Cookie`) | Categoría de productos |
| **Cobro (acción)** | `Banknote` (alt: `CreditCard`, `BadgeDollarSign`) | Botón "Cobrar" |
| **Ticket / recibo** | `ReceiptText` (recibo) · `Ticket` (entrada) | Documento de compra |
| **Cerrar** | `X` | Modales |
| **Volver** | `ArrowLeft` | Navegación push |
| **Buscar** | `Search` | Barra de búsqueda |
| **Agregar / quitar** | `Plus` · `Minus` · `Trash2` | Stepper del carrito |
| **Dividir cuenta** | `Split` | Modal de cobro |
| **Más (overflow)** | `Ellipsis` (o `MoreHorizontal`) | Items secundarios del nav |

**Categorías de producto con color semántico (píldoras):** Bebidas `Beer` = `--info`, Botanas `Popcorn` = `--warning`, Cerveza importada `Beer` = `--brand`, Alimentos `Pizza` = `--success`, Extras `Package` = `--text-2`. Los colores de categoría se usan **solo** en el icono/chip, nunca como fondo a plena saturación.

---

## 3. Navegación — menú de iconos responsive

### 3.1 Jerarquía de pantallas

```
Mesas (hub, pantalla inicial del cajero)
 ├─ Cuenta de mesa (pantalla de orden, push full-screen)
 │   └─ Modal de cobro (state machine full-screen)
 ├─ Renta (iniciar/terminar tiempo por mesa)
 └─ ...
Productos · Ventas · Caja · Clientes · Reportes (dueño) · Ajustes
```

- **Cajero (tablet):** 5 destinos primarios en la barra inferior: `Mesas · Renta · Productos · Ventas · Caja`. "Más" (`Ellipsis`) → `Clientes · Ajustes`.
- **Dueño (escritorio):** barra lateral con todo; pantalla inicial = **Reportes**. Mismos ítems, role-gated (el cajero no ve Reportes/Ajustes de negocio si no tiene permiso).

### 3.2 Escritorio (≥ 1024px) — barra lateral de iconos

- Rail colapsado **72px** de ancho (icono 24px + label 11px debajo), expandible a **232px** con icono + label a la derecha. Estado activo = icono `--brand` + pill `--brand-soft` detrás.
- Altura de ítem: **48px**, gap `8px`, padding vertical de grupo `24px`. El ítem activo lleva un indicador de 3px en el borde izquierdo.
- Icono de marca "Kalos" arriba (logo sobre negro), "Ajustes" y avatar del cajero anclados abajo.

```css
.rail { width: 72px; background: var(--surface-1); border-right: 1px solid var(--border); }
.rail-item { display: grid; place-items: center; gap: 4px; height: 56px; border-radius: 10px; }
.rail-item[data-active='true'] { background: var(--brand-soft); color: var(--brand); }
```

### 3.3 Tablet / móvil (< 1024px) — barra inferior

- Altura **64px** + `env(safe-area-inset-bottom)`. Fondo translúcido (`rgba(18,18,20,.72)` + blur 20px).
- **Máximo 5 ítems.** Cada ítem: icono 24px + label 10px. Área táctil mínima 48px de ancho; el ítem activo = icono `--brand` + label `--text-1` + un punto/pill `--brand` bajo el icono.
- 6º destino = "Más" (`Ellipsis`) que abre un **action sheet** (sheet inferior) con los items restantes.

```html
<nav class="bottom-nav">
  <a data-active><Icon/><span>Mesas</span></a>
  <a><Icon/><span>Renta</span></a>
  <a><Icon/><span>Productos</span></a>
  <a><Icon/><span>Ventas</span></a>
  <a><Icon/><span>Caja</span></a>
  <button><Ellipsis/><span>Más</span></button>
</nav>
```

- Al tocar un ítem **no se anima** (frecuencia altísima); solo cambia el estado activo al instante. La transición de **pantalla** es un cross-fade de 160ms (no deslizamiento) para sentir velocidad.

---

## 4. Patrones de componentes clave

### 4.1 Tarjeta de mesa (estado + cronómetro en vivo)

Estados y su representación:

| Estado | Tratamiento | Cronómetro |
|---|---|---|
| **Libre** | `--surface-2`, borde `--border`, número `--text-2` | — |
| **Ocupada / en juego** | borde `--brand`, tint `--brand-soft`, número `--text-1` | ✅ mono, color progresa |
| **Reservada** | borde `--info`, icono `--info` | (hora de reserva) |
| **Por cobrar** | borde `--warning`, pulso sutil `--warning` | ✅ parpadeo discreto |
| **Fuera de servicio** | `--surface-2` atenuado 50%, rayado, sin interacción | — |

```tsx
// Tarjeta de mesa — grid responsive (ver §7)
<div class="table-card" data-state="occupied">
  <header>
    <span class="num">12</span>
    <span class="badge">Renta</span>          {/* o 'Abierta' */}
  </header>
  <div class="timer" role="timer" aria-live="off">01:23:45</div>  {/* actualiza 1s, tabular-nums */}
  <footer><span>$184.00</span><span>4 pers.</span></footer>
</div>
```

- **Cronómetro:** actualiza cada **1s**, fuente `JetBrains Mono`, `tabular-nums`. **Color por tiempo** (configurable): `0–5min` `--success` → `5–10min` `--warning` → `10min+` `--danger`. El cambio de color es una transición de 400ms; **el número nunca se anima con spring** (evita strobing) — solo cambia el valor.
- **Tap en "Ocupada"** → abre la Cuenta de mesa. **Tap largo (long-press 500ms)** → menú contextual (Mover, Anular, Fuera de servicio).
- Animar la tarjeta **solo** al entrar por primera vez (stagger 30–60ms), nunca en cada re-render del timer.

### 4.2 Carrito / Cuenta de mesa

Layout **2 paneles** (patrón universal iPad POS, ~30% / ~70%):

```
┌──────────────┬────────────────────────────────┐
│ Cuenta Mesa 8│  [Píldoras de categoría →]     │
│ Mesa 8 · Renta│  ┌─────┐ ┌─────┐ ┌─────┐       │
│ ─────────────│  │tile │ │tile │ │tile │       │
│ 1× Michelob  │  └─────┘ └─────┘ └─────┘       │
│ 1× Botana    │  ┌─────┐ ┌─────┐ ┌─────┐       │
│ 2× Cue Ball  │  ...  (grid scroll) ...        │
│ ─────────────│                                │
│ Subtotal 184 │                                │
│ Total    184 │  [Cobrar →]  [Abrir/Guardar]   │
└──────────────┴────────────────────────────────┘
```

- **Ítem del carrito:** nombre (16px/600) + modificadores (13px `--text-2`) + precio derecha (tabular). Stepper `− 1 +` con targets de 44px. **Swipe-left** revela "Anular" (`--danger`).
- **Item añadido:** flash verde 200ms en la fila (`--success` al 12%) + el total hace un "tick" (transición de color, no de posición).
- **Total:** Display (700) tabular; el subtotal/impuestos alineados a la derecha.

### 4.3 Selector de productos (con categorías)

- **Barra de categorías:** píldoras horizontales scrollables (altura 40px, padding `8px 16px`, radio 9999). Activa = fondo `--surface-3` + texto `--text-1`; inactiva = `--text-2`. Scroll horizontal con `scroll-snap` y fade en los bordes.
- **Grid de tiles:** `repeat(auto-fill, minmax(112px, 1fr))`, gap 12px. Tile = icono de categoría 24px + nombre (14px/600) + precio (13px `--text-2`, tabular). Radio 16px. Agotado = opacidad 40% + tachado + badge.
- **Modificadores:** sheet inferior (no inline), radio superior 20px, drag-indicator, opciones de 48px con radio/checkbox, CTA fijo abajo "Agregar — $X".

### 4.4 Modal de cobro (state machine full-screen)

Flujo secuencial, **no un modal pequeño**:

1. **Método de pago** — tiles de 120×100 (icono 32px + label): `Banknote` Efectivo · `CreditCard` Tarjeta · `Split` Dividir. Resumen de la cuenta a la izquierda.
2. **Monto / propina** (si aplica) — botones 80×80 con % y monto (22px/700). Seleccionado = borde `--brand` 3px + `--brand-soft`.
3. **Procesando** — spinner 44px + "Presente tarjeta en terminal" + estado de la terminal.
4. **Recibo** — ver §4.5. Autocierre 10–15s con "Sin recibo" por defecto.

- CTA primario "Cobrar $184.00": full-width, **56px**, radio 14px, `--brand` con texto `--on-brand`. Target táctil generoso porque es la acción de mayor frecuencia.

### 4.5 Recibo

- Tarjeta `--surface-2`, ancho máx. 480px, radio 16px, padding 24px. Cabecera "Kalos Billar Club" (Sora 600), número de ticket, fecha.
- Líneas con `border-bottom: 1px dashed var(--border)`; montos en `JetBrains Mono` tabular. Total en Display con `--brand`.
- Botones: "Imprimir" (`Printer`), "Enviar" (`Mail`), "Nuevo recibo". Los botones imprimen/cierran sin animación.

### 4.6 Dashboard de métricas (dueño, escritorio)

- **KPI cards** (4 en fila): "Ventas hoy", "Mesas ocupadas", "Ticket promedio", "Horas rentadas". Cifra = Display tabular; delta ↑/↓ con `--success`/`--danger`.
- **Gráfico de área** (ventas por hora) y **barras** (producto top). Ejes/etiquetas `--text-3`; series en `--brand` (ventas) y `--success` (renta). Animar el draw del área **solo al montar** (600ms ease-out), nunca en cada actualización.
- **Lista "Mesas activas"** reutiliza la tarjeta de mesa en versión compacta (fila).

---

## 5. Usabilidad táctil

### 5.1 Tamaños de objetivo

| Elemento | Mínimo | Ideal |
|---|---|---|
| Target general (Apple HIG) | **44×44px** | 48px |
| Botones de acción primaria (Cobrar, Agregar) | 48px | **56–64px** de alto |
| Ítems del nav inferior | 48px ancho | — |
| Teclado numérico | — | **64–80px** por tecla |
| Stepper +/− | 44px | 48px |

Regla: en tablet **nunca** bajar de 44px; en escritorio con puntero fino se permite 32–36px en filas densas (pero no en el flujo de caja).

### 5.2 Feedback al tocar

```css
.pos-button { transition: transform 100ms ease-out, background-color 100ms; }
.pos-button:active { transform: scale(0.97); }
* { -webkit-tap-highlight-color: transparent; }
```

- Feedback en **pointer-down** (`:active`), commit en release. Cancelable arrastrando fuera (~10px de histéresis).
- **Hover solo con puntero fino** (evitar el "hover fantasma" en táctil):

```css
@media (hover: hover) and (pointer: fine) {
  .pos-button:hover { background: var(--surface-3); }
}
```

### 5.3 Gestos

- **Swipe-left** en ítem de carrito → revela "Anular".
- **Long-press (500ms)** en tarjeta de mesa → menú contextual.
- **Scroll con momentum** en grids/listas (`-webkit-overflow-scrolling: touch`), `overscroll-behavior: contain` para no arrastrar la página.
- **Deslizar sheet hacia abajo** para descartar (velocity-aware, ver §6).
- Nada de `double-tap` que retrase el tap simple; el POS es de un solo toque.

### 5.4 Estados de carga / error / vacío

- **Carga:** skeleton shimmer sutil (no spinners grandes en listas); en botones, spinner de 20px que **gira rápido** (600ms/vuelta) para percibir velocidad.
- **Error:** toast superior (radio 16px, `--danger` + `--on-danger`), auto-dismiss 3–4s, con botón "Reintentar". No bloquear con alert() nativos.
- **Vacío:** icono + línea corta + acción ("Abrir mesa" / "Agregar producto"), en `--text-2`.
- **Offline:** banner fijo discreto "Sin conexión — guardando localmente" (importante en POS).

### 5.5 Accesibilidad y contraste

- Contraste mínimo **AA (4.5:1)** para texto; AA-large (3:1) para iconos de UI y texto grande. (Valores ya verificados en §1.1.)
- `focus-visible` con anillo `--brand` de 2px y offset 2px (teclado/escritorio).
- Todos los targets con `role`/`aria-label`; el cronómetro con `role="timer"` (no anunciar cada segundo — `aria-live="off"`, exponer el estado por separado).
- Soporte completo:
  - `prefers-reduced-motion: reduce` → cross-fades de 200ms, sin springs ni slides.
  - `prefers-reduced-transparency: reduce` → superficies opacas, sin blur.
  - Texto en `rem` para respetar el tamaño de fuente del sistema.
- Botones destructivos con confirmación **solo** si es irreversible (anular una cuenta cerrada); no pedir confirmación en "Agregar al carrito".

---

## 6. Micro-interacciones y animación (premium sin sacrificar rendimiento)

Modelo de springs (Apple → web). Librería: **[Motion](https://motion.dev)** (ex-Framer Motion).

| Interacción | Tipo | Parámetros |
|---|---|---|
| Movimiento / reposicionar | spring crítico | `damping 1.0`, `response 0.4s` |
| Sheet / drawer (gesto) | spring con rebote sutil | `damping 0.8`, `response 0.3s` |
| Flick / arrastre con inercia | spring + velocidad heredada | `bounce 0.2`, `duration 0.4s` |
| Presionar botón | CSS transition | `transform 100ms ease-out` (scale 0.97) |
| Dropdown / tooltip | CSS | `150–200ms cubic-bezier(0.23,1,0.32,1)` |
| Modal / sheet | spring | `250–400ms` |
| Cross-fade entre pantallas | CSS | `160ms ease` |

**Curvas CSS personalizadas** (no usar `ease-in` jamás en UI):

```css
--ease-out: cubic-bezier(0.23, 1, 0.32, 1);      /* salida fuerte */
--ease-in-out: cubic-bezier(0.77, 0, 0.175, 1);  /* movimiento en pantalla */
--ease-drawer: cubic-bezier(0.32, 0.72, 0, 1);   /* drawer estilo iOS */
```

**Reglas de rendimiento (no negociables):**

1. **Animar solo `transform` y `opacity`** (GPU). Nunca `width`/`height`/`margin`/`padding`.
2. En Motion, usar `transform: "translateX(...)"` completo en vez de `x`/`y` (hardware-accelerated).
3. **CSS para animaciones predeterminadas**, JS/springs solo para lo gestual e interrumpible.
4. **Interrumpible siempre:** animar desde el valor *actual* en pantalla (no el target) para poder agarrar y revertir a mitad de camino; heredar la velocidad de liberación en el gesto.
5. **`prefers-reduced-motion`** desactiva springs/slides.

**Micro-interacciones concretas:**

- **Añadir al carrito:** fila parpadea `--success` 200ms + total cambia de color 200ms (no se desplaza).
- **Abrir sheet/modal:** escala `0.95→1` + opacity + slide-up con spring; el backdrop fade 200ms. Cerrar es **más rápido** (salida ~200ms vs entrada ~300ms).
- **Stagger de entrada** de tiles: 30–60ms entre elementos (solo al montar).
- **Popovers origin-aware:** `transform-origin` en el trigger, nunca en el centro. Excepción: modales centrados.
- **Cronómetro en rojo:** el número cambia a `--danger` con transición de color 400ms (sin escala/pulso del número).
- **No animar:** toggles del nav, tap en tiles repetitivos, cambios de estado del timer (más de 100×/día → sin animación).

---

## 7. Diseño responsive — breakpoints y comportamiento

| Rango | Dispositivo | Nav | Layout |
|---|---|---|---|
| `< 640px` | Móvil portrait | Barra inferior (5 ítems) | Una columna; sheets full-screen; grid mesas 2–3 col. |
| `640–1023px` | Móvil landscape / tablet portrait | Barra inferior (5 ítems) | Grid mesas 3–4 col.; carrito como sheet inferior |
| `≥ 1024px` | Tablet landscape / escritorio | **Barra lateral de iconos** (72px → 232px) | Cuenta de mesa en **2 paneles (30/70)**; dashboard multi-columna |

```css
/* Breakpoints Tailwind */
/* sm: 640 · md: 768 · lg: 1024 · xl: 1280 */
.mesas-grid   { grid-template-columns: repeat(auto-fill, minmax(112px, 1fr)); }
@media (min-width: 640px)  { .mesas-grid { grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); } }
@media (min-width: 1024px) { .cuenta { display: grid; grid-template-columns: 320px 1fr; } }
```

**Reglas por dispositivo:**

- **Tablet (cajero):** apaisado es el modo de trabajo. Navegación por iconos abajo, thumbs en el borde (alcance del pulgar). La Cuenta de mesa usa **2 paneles** si el ancho ≥ 768px; si no, el carrito colapsa a sheet.
- **Escritorio (dueño):** barra lateral + hover/focus + atajos de teclado (p. ej. `Esc` cierra modal, `C` abre cobro). Filas más densas (32px) permitidas con puntero fino.
- **Safe areas:** `padding: env(safe-area-inset-*)` en barra inferior y sheets (notch/home indicator).
- **PWA/instalable:** `theme-color: #0B0B0C`, `apple-mobile-web-app-status-bar-style: black-translucent`, `viewport-fit: cover` para el borde a pantalla completa. Deshabilitar el zoom por pinch (POS) y `overscroll-behavior: none` en el shell; scroll solo en contenedores internos.
- **Siempre:** layout en `rem`/`clamp` para tolerar rotación y tamaños de fuente del sistema.

---

## Referencias

- [Apple HIG — Dark Mode](https://developer.apple.com/design/human-interface-guidelines/dark-mode)
- [Apple HIG — Color](https://developer.apple.com/design/human-interface-guidelines/color) · [Typography](https://developer.apple.com/design/human-interface-guidelines/typography) · [Designing for iPadOS](https://developer.apple.com/design/human-interface-guidelines/designing-for-ipados)
- [Material Design 3 — Dark theme (guía de implementación)](https://developer.android.com/develop/ui/views/theming/darktheme) — baseline M3 oscuro: surface `#1C1B1F`, on-surface `#E6E1E5`, primary `#D0BCFF`.
- [Linear — design reference (tokens, escala, densidad)](https://raw.githubusercontent.com/opencoworkai/open-codesign/1d335267822f57eaeca61da0a5fc12f9b7ce434b/apps/desktop/resources/templates/brand-refs/linear/DESIGN.md)
- [iPad POS UI Research (Toast, Square, Lightspeed, TouchBistro + Apple HIG)](https://raw.githubusercontent.com/AIVIIZN/getsear/session-p-C/V8.2/POS_UI_RESEARCH.md)
- [Lucide — iconos](https://lucide.dev) · [Motion (springs)](https://motion.dev) · [Google Fonts](https://fonts.google.com)
- [Josh Comeau — Designing Shadows](https://www.joshwcomeau.com/css/designing-shadows/) · [Smashing — CSS `corner-shape`](https://www.smashingmagazine.com/2026/03/beyond-border-radius-css-corner-shape-property-ui/)

*Fuente de los principios de motion (springs, interruptibilidad, materiales, tipografía): [Designing Fluid Interfaces (WWDC)](https://developer.apple.com/videos/play/wwdc2018/803/) y el marco de decisiones de animación de Emil Kowalski ([animations.dev](https://animations.dev)).*
