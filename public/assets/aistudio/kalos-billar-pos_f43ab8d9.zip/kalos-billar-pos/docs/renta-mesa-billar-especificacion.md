# Especificación técnica: Cobro por renta de mesa por tiempo (billar)

**Versión:** 1.0 — **Fecha:** 2026-10-27 — **Ámbito:** México (IVA 16 %, America/Mexico_City) — **Backend de datos:** Cloud Firestore

---

## Resumen ejecutivo (decisiones de diseño)

| Decisión | Recomendación | Justificación |
|---|---|---|
| Reloj de facturación | **Timestamps del servidor** (`FieldValue.serverTimestamp()`), nunca el reloj del dispositivo | Un reloj alterado no debe sobre/ subcobrar a nadie |
| Estrategia de cronometraje | **Recalcular con timestamp de inicio + pausas acumuladas** | Una sola fuente de verdad, sobrevive recargas y multi-dispositivo |
| Redondeo por defecto | **Redondeo hacia arriba a cuarto de hora (15 min), con mínimo facturable explícito** | Estándar del sector (Kassly: billar "por cuarto de hora") |
| Tarifa a mitad de renta | **Congelar el `rateSnapshot` al abrir; prorratear solo los cruces de horario (happy hour)** | Evita que editar el catálogo cambie cuentas abiertas |
| Estado de mesa vs. cuenta | **Dos máquinas de estado separadas** (física de la mesa + ciclo de la cuenta/tab) | La mesa es un recurso; el tab es la orden económica |
| Propina | **Separada del subtotal y del IVA** (voluntaria no causa IVA; cargo por servicio obligatorio sí) | Cumplimiento SAT/CFDI |
| Dinero y tiempo | **Centavos enteros (int) y segundos enteros (int)**; nunca `float` | Evita errores de redondeo de punto flotante |

---

## 1. Modelo de estados de una mesa

Hay **dos máquinas de estado** que conviene mantener separadas: la de la **mesa** (recurso físico) y la de la **cuenta/tab** (orden económica abierta). Están correlacionadas, no son lo mismo.

### 1.1 Estados de la mesa (`table.status`)

| Estado | Significado | Tab asociado | Cronómetro |
|---|---|---|---|
| `LIBRE` | Sin nadie jugando, lista para rentar | ninguno | — |
| `OCUPADA` (rentada) | Metro corriendo, tab abierta | `ABIERTA` | corriendo |
| `PAUSADA` | Metro detenido temporalmente (cliente salió a fumar, etc.) | `ABIERTA` | detenido (acumula pausa) |
| `POR_COBRAR` | Metro detenido definitivamente; falta cobrar el tab | `POR_COBRAR` | detenido (fin sellado) |
| `EN_LIMPIEZA` | Cobrada; personal limpia/repone | `CERRADA` | — |
| `MANTENIMIENTO` | Fuera de servicio (paño roto, tronera dañada) | ninguno | — |
| `INACTIVA` | Mesa retirada del piso | ninguno | — |

> Nota: `PAUSADA` puede modelarse como sub-estado de `OCUPADA`; se recomienda un estado explícito para que el tablero (floor plan) y las reglas de negocio (¿puedo pausar más de N minutos?) sean claras.

### 1.2 Estados de la cuenta/tab (`tab.status`)

| Estado | Significado |
|---|---|
| `ABIERTA` | Metro corriendo o en pausa; se le pueden agregar productos |
| `POR_COBRAR` | Metro detenido; la orden está lista para pago |
| `CERRADA` | Pagada total o parcialmente; liquidada |
| `ANULADA` | Cortesía / error de apertura (nunca "desaparece" el registro, queda auditado) |

### 1.3 Diagrama de transiciones

```mermaid
stateDiagram-v2
    [*] --> LIBRE
    LIBRE --> OCUPADA : iniciarRenta()\n[tx: crea tab, serverTimestamp start]
    OCUPADA --> PAUSADA : pausar()\n[serverTimestamp pause]
    PAUSADA --> OCUPADA : reanudar()\n[serverTimestamp resume]
    OCUPADA --> POR_COBRAR : detenerCronometro()\n[serverTimestamp end]
    PAUSADA --> POR_COBRAR : detenerCronometro()
    POR_COBRAR --> EN_LIMPIEZA : cobrar()\n[pago completado]
    POR_COBRAR --> OCUPADA : reabrirRenta()\n[opcional: sigue jugando]
    POR_COBRAR --> ANULADA : anular()\n[cortesía/error]
    ANULADA --> LIBRE : liberar()
    EN_LIMPIEZA --> LIBRE : liberar()
    LIBRE --> MANTENIMIENTO : marcarMantenimiento()
    MANTENIMIENTO --> LIBRE : quitarMantenimiento()
    LIBRE --> INACTIVA : desactivar()
    INACTIVA --> LIBRE : reactivar()
```

Tabla de transiciones válidas (matriz de adyacencia, con guardas):

| Desde \ Hasta | LIBRE | OCUPADA | PAUSADA | POR_COBRAR | EN_LIMPIEZA | MANTENIMIENTO |
|---|---|---|---|---|---|---|
| **LIBRE** | — | ✅ iniciar | ❌ | ❌ | ❌ | ✅ marcar mant. |
| **OCUPADA** | ❌ | — | ✅ pausar | ✅ detener | ❌ | ⚠️ solo si vacía* |
| **PAUSADA** | ❌ | ✅ reanudar | — | ✅ detener | ❌ | ❌ |
| **POR_COBRAR** | ❌ | ✅ reabrir | ❌ | — | ✅ cobrar | ❌ |
| **EN_LIMPIEZA** | ✅ liberar | ❌ | ❌ | ❌ | — | ✅ |
| **MANTENIMIENTO** | ✅ quitar | ❌ | ❌ | ❌ | ❌ | — |

\* Poner en mantenimiento una mesa ocupada debe rechazarse (o exigir primero detener/cobrar). Kassly lo expresa como *"un recurso en Maintenance/Inactive no puede meterse; iniciar un metro lo pone en Occupied"*.

**Reglas duras (invariantes):**
1. **Un solo medidor por mesa**: `iniciarRenta` sobre una mesa con tab abierta es rechazado ("esta mesa ya tiene una renta abierta").
2. Toda transición se ejecuta en una **transacción Firestore** que relee el estado y aborta si ya no coincide (concurrencia multi-dispositivo).
3. Ninguna transición "borra" el historial; se conservan `startedAt`, `pausedAt/resumedAt`, `endedAt` y `closedAt` para auditoría y reconciliación de caja.

---

## 2. Cronometraje exacto

### 2.1 Fuente de verdad del tiempo

**El reloj que factura es el del servidor, no el del cliente.** En Firestore esto se logra con `FieldValue.serverTimestamp()`, que es un *centinela*: el valor se resuelve en el reloj del backend en el instante en que la escritura se confirma, no en el dispositivo. El cliente **nunca** debe escribir `new Date()` para `startedAt`/`endedAt`/`pausedAt`/`resumedAt`.

> Kassly lo formula igual: *"Start and stop are stamped by Kassly's own clock, not the device, so a wrong clock never over- or under-charges"* y *"stopping a meter needs a connection"* porque el fin debe sellarse con el reloj de verdad.

**Consecuencia práctica:** iniciar y detener el metro exigen conectividad (la escritura con `serverTimestamp()` debe poder confirmarse). En Firestore con persistencia offline, la escritura se encola localmente y el centinela se resuelve al reconectar; hasta entonces el timestamp de inicio **no está disponible** en el cliente. Por eso:

- **Modelo primario (recomendado):** iniciar/detener requieren red. Si se corta la red a mitad de juego, el metro sigue *mostrándose* en pantalla y se detiene al volver la conexión; se factura desde el inicio real.
- **Modelo híbrido (offline-first opcional):** guardar además un `startedAtClient` provisional (reloj local) para poder *mostrar* un estimado, y reconciliar contra `startedAt` (server) al sincronizar. **El monto final SIEMPRE se calcula con `startedAt`/`endedAt` del servidor.** El provisional solo alimenta el display.

### 2.2 Duración transcurrida facturable

```
elapsedBruto(seg)   = endedAt − startedAt
pausaActiva(seg)    = (pausedAt != null && resumedAt == null) ? (now − pausedAt) : 0
pausasCompletadas   = Σ_i (resumedAt_i − pausedAt_i)          // solo i con resumedAt != null
elapsedFacturable   = elapsedBruto − pausasCompletadas − pausaActiva
```

- Todas las operaciones en **segundos enteros** sobre instantes UTC.
- Se valida `resumedAt ≥ pausedAt` y que los intervalos de pausa no se solapen (guardas en la transacción).
- `elapsedFacturable` nunca es negativo (se satura en 0).

### 2.3 Reloj del servidor vs. cliente (skew) y pantalla

El display del cronómetro es **cosmético**. Para que el tick en pantalla sea exacto pese a que el reloj del teléfono esté desviado:

```
offset(ms) = lastServerTime − clientClockAtThatMoment     // se captura al leer un serverTimestamp conocido
displayNow = clientClockNow + offset
ticksElapsed = displayNow − startedAt − Σ pausas          // solo para pintar el contador
```

El `offset` se refresca en cada snapshot que traiga un `serverTimestamp` resuelto (o vía NTP de la red). Si `offset` es desconocido, se muestra el último valor estimado y se marca "sincronizando". **Nada de esto entra al cálculo de facturación**, que usa solo los timestamps persistidos.

### 2.4 Zona horaria

- **Persistencia:** todos los timestamps se guardan en **UTC** (Firestore `Timestamp` es un instante UTC; es agnóstico a zona).
- **Display:** se formatea a la zona del local, `America/Mexico_City`. Nota 2024–2026: México **eliminó el horario de verano** (a partir del 30/oct/2022), así que `America/Mexico_City` es **UTC−6 fijo todo el año** (excepción: franja fronteriza norte que sigue el DST de EE. UU.). Guardar la zona IANA del local en `venue.timeZone` y **no** codificar "UTC−6".
- **Dónde SÍ importa la zona local:** únicamente en las **reglas de tarifa por horario** (matutino/vespertino/nocturno, happy hour). Ahí se convierte `now` (UTC) a la zona del local y se compara contra ventanas horarias locales. Las *duraciones* (segundos) son independientes de la zona.

---

## 3. Reglas de tarifas

### 3.1 Vocabulario

- **`unit`**: granularidad de cobro → `MINUTO`, `HORA`, `BLOQUE` (bloque de `blockMinutes`).
- **`rate`**: precio por unidad, en centavos (ej. `6000` = $60.00 MXN/hora).
- **`minBillableUnits`**: mínimo facturable (en unidades). Kassly advierte que **dejarlo vacío ≠ "sin mínimo"**: significa "una unidad completa" (una hora, o un bloque completo).
- **`rounding`**: `EXACTO` | `AL_MINUTO` | `CUARTO_HORA` | `HORA` | `BLOQUE` | `MINUTO_MAS_CERCANO`.

### 3.2 Orden de aplicación (canónico)

> **Primero el mínimo, después el redondeo** (mismo orden que Kassly).

```
unitSeconds = { MINUTO:60, HORA:3600, BLOQUE:blockMinutes*60 }[unit]

e    = elapsedFacturable (seg)                    // §2.2
e'   = max(e, minBillableUnits * unitSeconds)     // (1) mínimo
U    = redondear(e')                              // (2) redondeo → unidades facturables
precio = U * rate                                 // (3) precio bruto de renta
```

**Funciones de redondeo** (sobre `e'` en segundos):

| rounding | fórmula de unidades `U` |
|---|---|
| `EXACTO` | `U = e' / unitSeconds` (fracción, 4 decimales) |
| `AL_MINUTO` | `U = ceil(e' / 60) / (unitSeconds / 60)` |
| `CUARTO_HORA` | `U = ceil(e' / 900) * (900 / unitSeconds)` |
| `HORA` | `U = ceil(e' / 3600)` |
| `BLOQUE` | `U = ceil(e' / unitSeconds)` |
| `MINUTO_MAS_CERCANO` | `U = round(e' / 60) / (unitSeconds / 60)` |

> Para bloques, usar `BLOQUE` (ceil al bloque) casi siempre; `CUARTO_HORA` sobre un servicio por bloque produce fracciones de bloque, que suele ser un error (Kassly lo destaca explícitamente).

### 3.3 Tarifas diferenciadas

La tarifa se resuelve con un **`rateSchedule`** (calendario de reglas) evaluado en prioridad descendente:

1. **Paquete explícito** del cliente (ej. "2h + 1 refresco").
2. **Happy hour** (ventana horaria en zona local).
3. **Daypart** (matutino/vespertino/nocturno) por día de la semana.
4. **Tipo de mesa** (normal, profesional/torneo, carambola, snooker).
5. **Default** de la mesa/venue.

Cada regla lleva: `tableTypeId`, `weekdays[]`, `[hh:mm local, hh:mm local)`, `rate`, `unit`, `minBillableUnits`, `rounding`, `discount%`, `activeFrom/activeTo`, `priority`.

**Resolución de la tarifa vigente (recomendación):**

- **Congelar al abrir:** al `iniciarRenta` se escribe en el tab un `rateSnapshot = { rateId, scheduleVersion, unit, unitSeconds, rate, minBillableUnits, rounding, discount }`. Editar el catálogo después **no** altera cuentas ya abiertas (resuelve el caso borde "cambio de precio a mitad de renta").
- **Prorrateo por cruce de horario (opcional, para happy hour que termina a mitad de juego):** dividir `elapsedFacturable` en segmentos en los instantes donde cambia la tarifa vigente y cobrar cada segmento a su tarifa (fórmula en §6.2). El mínimo y el redondeo se aplican **una sola vez al total de la sesión**, distribuyendo la fracción redondeada proporcionalmente a los segmentos.

### 3.4 Ejemplos numéricos (MXN, IVA 16 %)

**Config A:** mesa normal `$60.00/h`, mínimo 30 min, redondeo `CUARTO_HORA`.

| Jugado (neto de pausas) | Mínimo | Redondeo | Unidades | Renta bruta | IVA 16 % | Total |
|---|---|---|---|---|---|---|
| 1 h 05 m | 30 m | cuarto | 1.25 h | $75.00 | $12.00 | $87.00 |
| 1 h 05 m | — | hora | 2.00 h | $120.00 | $19.20 | $139.20 |
| 1 h 05 m | 30 m | exacto | 1.0833 h | $65.00 | $10.40 | $75.40 |
| 10 m | 30 m (mín) | cuarto | 0.50 h | $30.00 | $4.80 | $34.80 |
| 10 m | 1 m | exacto | 0.1667 h | $10.00 | $1.60 | $11.60 |

> Fórmula del renglón 1: `e=3900 s → e'=max(3900,1800)=3900 → U=ceil(3900/900)*900/3600=5*0.25=1.25 → 1.25*6000=7500 ¢ = $75.00`.

**Config B:** sala KTV/billar por bloque `$120.00/2 h` (`BLOQUE`, bloque 120 min).

| Jugado | Mínimo | Redondeo | Unidades (bloques) | Renta | IVA | Total |
|---|---|---|---|---|---|---|
| 2 h 10 m | — | `BLOQUE` | 2 | $240.00 | $38.40 | $278.40 |
| 2 h 10 m | — | `CUARTO_HORA` ⚠️ | 2.1667 | $260.00 | $41.60 | $301.60 |

> ⚠️ El segundo renglón muestra el error típico: `CUARTO_HORA` sobre un servicio por bloque factura fracciones. Para bloques, fijar `BLOQUE`.

**Config C (sesión completa con productos, la más útil):**

Mesa normal `$60/h`, min 30 m, cuarto de hora. Cliente juega 1 h 42 m, con **una pausa de 10 m**. Pide 2 cervezas $35, 1 refresco $25, 1 botana $80, deja 10 % de propina.

```
elapsedBruto   = 102 m
pausas         = 10 m
elapsedFact    = 92 m
e'             = max(92, 30) = 92 m
U              = ceil(92/15) = 7 cuartos = 105 m = 1.75 h
renta          = 1.75 × $60 = $105.00

líneas:
  Renta de mesa (1.75 h)        $105.00   (IVA 16 %)
  2× Cerveza                     $70.00   (IVA 16 %)
  1× Refresco                    $25.00   (IVA 16 %)
  1× Botana                      $80.00   (IVA 16 %)
  -------------------------------------------------
  Subtotal                      $280.00
  IVA (16 %)                     $44.80
  -------------------------------------------------
  Subtotal + IVA                $324.80
  Propina (10 %, voluntaria)     $32.48   → fuera de la base de IVA
  -------------------------------------------------
  Total a cobrar                $357.28
```

La propina voluntaria **no** entra al subtotal ni a la base del IVA; se registra aparte para nómina/CFDI (§4.4).

---

## 4. Modelo de cuenta / orden de mesa (tab)

### 4.1 Asociación mesa ↔ cuenta

- `tables/{tableId}` lleva `currentTabId` (referencia al tab abierto) y `status`.
- `tabs/{tabId}` lleva `tableId`, `venueId`, `openedBy`, `startedAt`, etc.
- **La renta es una línea de servicio más**, no un concepto nuevo: su `qty = unidades facturables` y su `unitPrice = rate` (modelo Kassly: *"the hours ride on the sale as the line's quantity"*). Esto hace que IVA, reportes, comisiones y cierres Z traten el tiempo como una venta ordinaria.

### 4.2 Agregar productos

Cada producto se agrega como línea con **snapshot de precio** en el momento de agregarlo:

```jsonc
{
  "productId": "p_cerveza_m1",
  "name": "Cerveza Modelo",
  "qty": 2,
  "unitPriceCents": 3500,        // precio unitario CONGELADO al momento de agregar
  "taxRate": 0.16,               // tasa por línea (flexible: 0.16 o 0.00)
  "discountCents": 0,
  "addedAt": "<serverTimestamp>",
  "addedBy": "usr_123"
}
```

- El precio se **congela** al agregar: cambiar el catálogo después no re-escribe líneas ya capturadas.
- `baseCents = qty * unitPriceCents - discountCents`.
- Cantidades enteras; soporte de devolución/nota de crédito como línea negativa con auditoría (nunca borrar).

### 4.3 Impuestos (IVA en México)

- **Tasa general 16 %** aplica a: renta de mesa, cerveza, refrescos y alimentos preparados servidos en el local. Algunos alimentos pueden estar a **tasa 0 %** según naturaleza; por eso la tasa vive **por línea** (`taxRate`), no global, para no mezclar bases.
- Cálculo por línea: `taxCents = baseCents * taxRate` (redondeo a centavo al final de la línea).
- `subtotal = Σ baseCents`; `iva = Σ taxCents`; `totalSinPropina = subtotal + iva − descuentosGlobales`.

### 4.4 Propina

Reglas fiscales (Praxium, 2026):

| Tipo | ¿Causa IVA? | Tratamiento |
|---|---|---|
| **Propina voluntaria** (cliente elige %) | **No** | No es ingreso del local; se registra aparte, se reparte al personal y se integra a nómina (ISR/IMSS). **Fuera de la base de IVA y del CFDI de consumo.** |
| **Cargo por servicio obligatorio** (se suma al ticket sin opción) | **Sí** | Es parte del precio del servicio; es ingreso del local y **causa IVA 16 %**. |

Implementación:
- Botones sugeridos 10/15/20 % + "sin propina" + monto libre.
- `tipCents` va en `amounts.tip`, **no** en `subtotal` ni en `iva`. En cierre de turno, el reporte separa `consumo`, `IVA` y `propina` para generar el CFDI global solo sobre consumo+IVA (regla 2.7.1.21 RMF 2026) y alimentar nómina.
- El **cargo por servicio** obligatorio sí se modela como una línea más con `taxRate = 0.16`.

### 4.5 Fusión tiempo + productos en el total

```
subtotal     = renta.linea.base + Σ items.base
descuentos   = renta.linea.discount + Σ items.discount + descuentoGlobal
baseGravable = subtotal - descuentos
iva          = Σ líneas (baseGravable_línea * taxRate_línea)
total        = baseGravable + iva
propina      = total * pctPropina          (o monto libre; NO se suma al total gravable)
aCobrar      = total + propina
```

---

## 5. Persistencia y sincronización en Firestore

### 5.1 Estrategia elegida: **recalcular con timestamp de inicio** (+ pausas)

El tiempo facturable **nunca** se acumula escribiendo "segundos" a Firestore cada segundo. Se persiste el **estado del evento** (start/pausas/resumes/end) y el tiempo se **recalcula** al leerlo. Ventajas: sobrevive recargas, es idempotente, multi-dispositivo consistente, barato (no satura escrituras).

### 5.2 Los tres enfoques comparados

| Estrategia | Cómo funciona | Pros | Contras | Uso recomendado |
|---|---|---|---|---|
| **Recalcular con timestamp de inicio** | Persistir `startedAt` + pausas; `elapsed = now − startedAt − Σpausas` | Fuente de verdad única, sobrevive recargas/offline, barato | Requiere red para sellar start/stop (o reconcilio híbrido) | **Canónico para facturación** |
| **Server timestamp en start/stop** | `serverTimestamp()` en ambos extremos | Reloj inmutable, anti-manipulación | No disponible hasta confirmar la escritura (offline) | **Dentro del enfoque anterior** |
| **Contador por intervalos (heartbeat)** | Cloud Function / job escribe `lastSeen` o incrementa un contador cada N min | Detección de abandono, telemetría | Más escrituras y costo; **no** es la fuente de facturación | Solo para **vigilancia de mesas abandonadas** |

### 5.3 Offline y multi-dispositivo

- **Persistencia offline del SDK Firestore:** cachea localmente y encola escrituras; los `snapshot` listeners reciben datos con `hasPendingWrites` (escrituras locales aún no confirmadas) y `fromCache`. El SDK sincroniza al reconectar.
- **`serverTimestamp()` offline:** la escritura queda como pendiente; el centinela se resuelve con el reloj del servidor **al confirmar**. Hasta entonces no hay valor definitivo → por eso el modelo primario exige red para start/stop.
- **Manejo de reloj en pantalla** sin red: ver §2.3 (offset de skew). El tick es cosmético; la factura es determinista.
- **Concurrencia (dos tabletas intentando abrir la misma mesa):** se resuelve con **transacción Firestore** (read-then-write con reintentos). Solo una gana; la otra recibe "mesa ya ocupada". Kassly lo llama *"one meter per court"*.
- **`enableNetwork()` / `disableNetwork()`:** permiten pasar explícitamente a modo offline y reconectar de forma controlada (p. ej. al entrar a un sótano sin señal).
- **Contadores:** si se necesita un contador de alta escritura (estadísticas, no facturación), usar `increment()` (atómico, sin transacción) o **contadores fragmentados** (sharded counters) para tasas > ~1 escritura/seg/doc.

### 5.4 Recarga / crash a mitad de juego

El tab persistido (`startedAt` + `pauses`) sobrevive porque está en Firestore (no en memoria). Al recargar, el listener reconstruye `elapsed` y el display retoma el tick. Kassly: *"a running meter survives the app closing … comes back with the clock still running"*.

---

## 6. Casos borde y su manejo

### 6.1 Mesa abierta que se queda sin cerrar (abandono / fin de turno)

1. **Vigilancia (heartbeat):** un job programado (Cloud Scheduler → Cloud Function, o cron del backend) recorre `tabs` con `status == ABIERTA` y `startedAt` más viejo que `maxSessionMinutes` (o sin `lastSeen` en N min) → marca `warning` y notifica al encargado.
2. **Cierre de local:** al cerrar el turno, el sistema lista tabs abiertos y exige acción (detener/cobrar/transferir). Opcional: **auto-stop** que sella `endedAt` con `serverTimestamp()` y deja el tab en `POR_COBRAR`.
3. **Protección:** nunca se factura tiempo "infinito"; se puede poner un tope `maxBillableMinutes` configurable (ej. 12 h) que se sella y alerta.

### 6.2 Cambio de precio a mitad de renta

- **Catálogo (precio del servicio) editado mientras el metro corre:** no afecta — el tab guarda `rateSnapshot` congelado al abrir (§3.3). El renglón de renta se factura con esa tarifa congelada.
- **Cruza un horario distinto (happy hour termina, tarifa nocturna empieza):** prorrateo por segmentos:

```
segmentos = partir [startedAt, endedAt] en los instantes donde cambia la tarifa vigente
raw_i     = segundos brutos del segmento i (netos de pausas, distribuidos)
totalRaw  = Σ raw_i
totalBill = redondear( max(totalRaw, minSeconds) )          // mínimo+redondeo UNA vez al total
segBill_i = totalBill * (raw_i / totalRaw)                   // distribuir el redondeo proporcionalmente
precio    = Σ_i ( rate_i * segBill_i / unitSeconds_i )
```

- Se guarda `scheduleVersion` en el `rateSnapshot` para auditar qué reglas se aplicaron.

### 6.3 División de cuenta (split)

- **Por productos:** mover líneas seleccionadas a `tabs/{tabId}/splits/{splitId}` (o a un tab hijo). **El tiempo de renta es indivisible por defecto**: el operador elige cómo repartirlo (50/50, 100 % a un pagador, o proporcional a monto de productos). Nunca repartir el tiempo automáticamente sin regla explícita.
- **Pagos parciales:** `payments[]` con `method`, `amountCents`, `at`, `by`; el tab pasa a `CERRADA` cuando `Σ payments ≥ aCobrar`.
- Todo split en **transacción** para no duplicar líneas ni pagos.

### 6.4 Transferencia de mesa

El cliente cambia de la mesa 3 a la 6 (la 3 se dañó, o se libera la "buena").

1. Transacción: verificar que la mesa destino esté `LIBRE`.
2. `tab.tableId = destino`; `tables/3.status = LIBRE (o EN_LIMPIEZA)`, `currentTabId = null`; `tables/6.status = <estado del tab>`, `currentTabId = tab`.
3. **El cronómetro no se reinicia**: el tiempo pertenece al cliente, no a la mesa. Solo cambia el recurso físico.

### 6.5 Pausa inválida / doble pausa / reanudar sin pausa

- Guardas en transacción: `pausar` exige `status == OCUPADA`; `reanudar` exige `status == PAUSADA` y que exista una pausa con `resumedAt == null`; rechazar `resumedAt < pausedAt` y solapamientos. Idempotencia por `tab.version` (optimistic concurrency).

### 6.6 Reloj del dispositivo manipulado

Mitigado por diseño: la factura usa `serverTimestamp()`. El display puede estar desviado, pero el importe no.

### 6.7 Apertura offline de inicio

Modelo híbrido: se escribe `startedAtClient` (local) para mostrar un estimado y `startedAt = serverTimestamp()` que se resuelve al reconectar. **Si la escritura nunca se confirma** (se apagó sin red), al reconectar se decide: confirmar (usar hora real del servidor en el momento de la confirmación) o anular. Se recomienda marcar el tab como `pendingSync` hasta tener `startedAt` real y **no cobrar** hasta resolverlo.

### 6.8 Doble cobro / reintentos de pago

- `payments` con `idempotencyKey` (ej. id de la transacción de la terminal). Reintento con la misma clave no duplica.
- Cierre del tab en transacción: solo pasa a `CERRADA` si `Σ payments ≥ aCobrar`, con verificación de que no se cerró dos veces.

---

## 7. Esquema de documentos Firestore sugerido

```
venues/{venueId}
tables/{tableId}
tabs/{tabId}
tabs/{tabId}/payments/{paymentId}
products/{productId}
rateSchedules/{rateScheduleId}
rateSchedules/{rateScheduleId}/rules/{ruleId}
counters/salesStats/{venueId}          // sharded counters, solo estadística
```

### 7.1 `venues/{venueId}`

```jsonc
{
  "name": "Billar La Mágica",
  "timeZone": "America/Mexico_City",
  "currency": "MXN",
  "taxDefault": 0.16,
  "maxSessionMinutes": 720,
  "autoStopAtClose": true
}
```

### 7.2 `tables/{tableId}`

```jsonc
{
  "venueId": "v_1",
  "number": 3,
  "name": "Mesa 3",
  "typeId": "mesa_normal",           // o "profesional", "carambola", "snooker"
  "status": "OCUPADA",               // LIBRE|OCUPADA|PAUSADA|POR_COBRAR|EN_LIMPIEZA|MANTENIMIENTO|INACTIVA
  "currentTabId": "tab_...",         // null si LIBRE/EN_LIMPIEZA/MANTENIMIENTO
  "updatedAt": "<serverTimestamp>"
}
```

### 7.3 `tabs/{tabId}` (el corazón del sistema)

```jsonc
{
  "venueId": "v_1",
  "tableId": "table_3",
  "status": "ABIERTA",               // ABIERTA|POR_COBRAR|CERRADA|ANULADA
  "openedBy": "usr_9",
  "customerId": null,                // opcional (cliente frecuente / membresía)

  // ---- cronometraje (reloj del servidor) ----
  "startedAt": "<serverTimestamp>",
  "endedAt": null,                   // serverTimestamp al detener
  "pauses": [
    { "pausedAt": "<ts>", "resumedAt": "<ts|null>", "by": "usr_9" }
  ],

  // ---- tarifa congelada al abrir ----
  "rateSnapshot": {
    "rateId": "r_mesa_normal_dia",
    "scheduleVersion": 12,
    "unit": "HORA",
    "unitSeconds": 3600,
    "rateCents": 6000,
    "minBillableUnits": 0.5,
    "rounding": "CUARTO_HORA",
    "discountPct": 0
  },

  // ---- línea de renta (se completa al detener) ----
  "rentalLine": {
    "productId": "svc_renta_mesa_normal",
    "name": "Renta de mesa (por hora)",
    "billableUnits": null,           // se llena al detener: 1.75
    "unitPriceCents": 6000,
    "baseCents": null,               // 10500
    "taxRate": 0.16,
    "discountCents": 0
  },

  // ---- productos agregados a la cuenta ----
  "items": [
    {
      "productId": "p_cerveza_m1", "name": "Cerveza Modelo",
      "qty": 2, "unitPriceCents": 3500, "taxRate": 0.16,
      "discountCents": 0, "addedAt": "<ts>", "addedBy": "usr_9"
    }
  ],

  // ---- totales (recalculados al detener y al agregar) ----
  "amounts": {
    "subtotalCents": 28000,
    "discountCents": 0,
    "taxCents": 4480,
    "serviceChargeCents": 0,         // cargo por servicio obligatorio (sí causa IVA)
    "tipCents": 3248,                // propina voluntaria (NO causa IVA)
    "totalCents": 35728
  },

  // ---- pagos ----
  "payments": [
    { "method": "CARD", "amountCents": 35728, "at": "<ts>", "by": "usr_9", "idempotencyKey": "t_8831" }
  ],

  "closedAt": null,
  "closedBy": null,
  "version": 7,                      // optimistic concurrency (transacciones)
  "createdAt": "<serverTimestamp>",
  "updatedAt": "<serverTimestamp>"
}
```

> **Escalado:** si una tab llega a tener cientos de líneas o pagos frecuentes, mover `items` y `payments` a subcolecciones (`tabs/{tabId}/items/{itemId}`) y dejar solo totales en el documento raíz. Para un billar (decenas de líneas), el arreglo inline es suficiente y más barato.

### 7.4 `rateSchedules/{id}/rules/{ruleId}`

```jsonc
{
  "rateScheduleId": "rs_2026",
  "priority": 30,                    // menor = más prioridad
  "tableTypeId": "mesa_normal",
  "weekdays": [1,2,3,4,5],           // ISO: lunes=1..domingo=7
  "windowLocal": { "start": "16:00", "end": "19:00" },  // happy hour en zona local
  "unit": "HORA",
  "rateCents": 4500,                 // $45/h happy hour
  "minBillableUnits": 0.5,
  "rounding": "CUARTO_HORA",
  "discountPct": 0,
  "activeFrom": "<ts>", "activeTo": null
}
```

### 7.5 Índices sugeridos

- `tabs`: `[venueId, status, startedAt]` (vigilancia de abandono), `[tableId, status]` (tab abierta de una mesa).
- `tables`: `[venueId, status]` (floor plan).

### 7.6 Reglas de seguridad (Firestore Rules) — esqueleto

```js
match /tabs/{tabId} {
  allow read: if request.auth != null && belongsToVenue(resource.data.venueId);
  allow create: if request.auth != null && request.resource.data.status == 'ABIERTA';
  allow update: if request.auth != null
    && !request.resource.data.diff(resource.data).affectedKeys().hasAny(['startedAt']);
  // startedAt/endedAt los escribe SOLO un Cloud Function con Admin SDK (reloj del servidor),
  // para que un cliente nunca inyecte fechas. El SDK del cliente usa serverTimestamp(),
  // pero la Rules no distingue el origen del valor; por eso el sello se centraliza en backend.
}
```

> **Recomendación de seguridad:** sellar `startedAt`/`endedAt`/`pausedAt`/`resumedAt` desde un **Cloud Function con Admin SDK** (que fija la hora del servidor), en lugar de confiar solo en `serverTimestamp()` desde el cliente. Así el reloj de facturación queda fuera del alcance del dispositivo.

---

## 8. Pseudocódigo

### 8.1 Cronómetro (start / pause / resume / stop / tick)

```typescript
// ===== ABRIR RENTA =====
async function iniciarRenta(tableId, serviceId, userId):
    return db.runTransaction(async tx => {
        const table = (await tx.get(db.doc(`tables/${tableId}`))).data()
        if table.status != 'LIBRE':
            throw 'Esta mesa no está libre'          // un medidor por mesa
        const rate = resolveRate(serviceId, table.typeId, nowInVenueTz(table)) // server
        const tabRef = db.collection('tabs').doc()
        tx.set(tabRef, {
            venueId: table.venueId, tableId, status: 'ABIerta', // 'ABIERTA'
            openedBy: userId,
            startedAt: FieldValue.serverTimestamp(),   // reloj del servidor
            pauses: [], rateSnapshot: rate, items: [], amounts: initialAmounts(),
            version: 1
        })
        tx.update(db.doc(`tables/${tableId}`), {
            status: 'OCUPADA', currentTabId: tabRef.id,
            updatedAt: FieldValue.serverTimestamp()
        })
        return tabRef.id
    })

// ===== PAUSAR =====
async function pausar(tabId, userId):
    return db.runTransaction(async tx => {
        const tab = getTab(tx, tabId)
        if tab.status != 'ABIERTA' || hasActivePause(tab): throw 'Transición inválida'
        tab.pauses.push({ pausedAt: FieldValue.serverTimestamp(), resumedAt: null, by: userId })
        tx.update(tabRef, { pauses: tab.pauses, version: tab.version + 1 })
        tx.update(tableRef, { status: 'PAUSADA' })
    })

// ===== REANUDAR =====
async function reanudar(tabId, userId):
    return db.runTransaction(async tx => {
        const tab = getTab(tx, tabId)
        const p = tab.pauses.find(p => p.resumedAt == null)
        if tab.status != 'PAUSADA' || !p: throw 'Transición inválida'
        p.resumedAt = FieldValue.serverTimestamp()
        tx.update(tabRef, { pauses: tab.pauses, version: tab.version + 1 })
        tx.update(tableRef, { status: 'OCUPADA' })
    })

// ===== DETENER CRONÓMETRO =====
async function detenerCronometro(tabId, userId):
    return db.runTransaction(async tx => {
        const tab = getTab(tx, tabId)
        if tab.status != 'ABIERTA': throw 'Ya detenido'
        tab.endedAt = FieldValue.serverTimestamp()      // sello final (servidor)
        const elapsed = elapsedFacturable(tab)          // §2.2 (con endedAt ya fijado)
        const { units, price } = calcularRenta(elapsed, tab.rateSnapshot)  // §3.2
        tab.rentalLine.billableUnits = units
        tab.rentalLine.baseCents = price
        tab.status = 'POR_COBRAR'
        recomputeAmounts(tab)                            // §4.5
        tx.update(tabRef, tab)
        tx.update(tableRef, { status: 'POR_COBRAR' })
    })

// ===== TICK (solo display, no escribe) =====
function tick(tab, nowClientMs, offsetMs):
    now = nowClientMs + offsetMs                          // corrección de skew §2.3
    if tab.endedAt: return tab.endedAt - tab.startedAt
    e = now - tab.startedAt
    for p in tab.pauses:
        e -= (p.resumedAt ?? now) - p.pausedAt            // pausa activa usa `now`
    return max(0, e)
```

### 8.2 Cálculo de renta (núcleo puro, sin I/O)

```typescript
function calcularRenta(elapsedSec, rs /* rateSnapshot */):
    unitSec = rs.unitSeconds
    e1 = max(elapsedSec, rs.minBillableUnits * unitSec)   // (1) mínimo
    units = redondear(e1, rs.rounding, unitSec)           // (2) redondeo
    priceCents = round(units * rs.rateCents)              // (3) precio (centavos enteros)
    return { units, priceCents }

function redondear(e1, modo, unitSec):
    switch modo:
        'EXACTO':            return e1 / unitSec
        'AL_MINUTO':         return ceil(e1 / 60) / (unitSec / 60)
        'CUARTO_HORA':       return ceil(e1 / 900) * (900 / unitSec)
        'HORA':              return ceil(e1 / 3600)
        'BLOQUE':            return ceil(e1 / unitSec)
        'MINUTO_MAS_CERCANO':return round(e1 / 60) / (unitSec / 60)
```

### 8.3 Cierre / cobro de la cuenta

```typescript
async function cerrarTab(tabId, payments[], userId):
    return db.runTransaction(async tx => {
        const tab = getTab(tx, tabId)
        if tab.status == 'CERRADA': throw 'Ya cerrada'
        if tab.status == 'ABIERTA': detenerCronometroEnTx(tx, tab)   // sella tiempo si faltaba

        const aCobrar = tab.amounts.totalCents + tab.amounts.tipCents
        for pay in payments:
            if !pay.idempotencyKey or existsPayment(tab, pay.idempotencyKey): continue
            tab.payments.push(pay)
            tx.set(db.doc(`tabs/${tabId}/payments/${pay.idempotencyKey}`), pay)

        const pagado = sum(tab.payments.amountCents)
        if pagado >= aCobrar:
            tab.status = 'CERRADA'
            tab.closedAt = FieldValue.serverTimestamp()
            tab.closedBy = userId
            tx.update(tableRef, { status: 'EN_LIMPIEZA', currentTabId: null })
        // si es pago parcial, queda POR_COBRAR con saldo; o se hace split (§6.3)
        tx.update(tabRef, tab)
    })

// liberar mesa después de limpieza
async function liberarMesa(tableId):
    tx.update(tableRef, { status: 'LIBRE', currentTabId: null })
```

---

## 9. Checklist de implementación

1. Config de venue: `timeZone`, `currency`, `taxDefault`, máximos de sesión.
2. CRUD de mesas con `typeId` y estados.
3. Catálogo de servicios de renta con `unit`, `rate`, `minBillableUnits`, `rounding`.
4. `rateSchedule` con reglas priorizadas (happy hour / daypart / tipo de mesa).
5. Transacciones de apertura/pausa/reanudar/detener con `serverTimestamp()` (o Cloud Function Admin para sellar).
6. Tab con líneas de productos + snapshot de precio + `rateSnapshot` congelado.
7. Cálculo de totales con IVA por línea y propina separada.
8. Job de vigilancia de abandono + cierre de turno.
9. Splits y transferencia de mesa en transacción.
10. Reglas de seguridad + índice `[venueId, status, startedAt]`.

---

## 10. Fuentes citadas

1. **Kassly — Rentals (manual del producto, lógica exacta de renta por hora/bloque, mínimo, redondeo, reloj del servidor, offline, un medidor por recurso):** <https://kasslypos.com/docs/rentals>
2. **Kassly — Court & Room Rentals (feature overview):** <https://kasslypos.com/features/rentals>
3. **Firebase — Add data to Firestore (`FieldValue.serverTimestamp()`, sentinel resuelto en el servidor):** <https://firebase.google.com/docs/firestore/manage-data/add-data#server_timestamp>
4. **Firebase — Transactions and batched writes (read-then-write atómico, reintentos, uso para transiciones de estado):** <https://firebase.google.com/docs/firestore/manage-data/transactions>
5. **Firebase — Access data offline (persistencia offline, pending writes, enable/disableNetwork):** <https://firebase.google.com/docs/firestore/manage-data/enable-offline>
6. **Firebase — Distributed counters (`increment()` atómico y counters fragmentados):** <https://firebase.google.com/docs/firestore/solutions/counters>
7. **Praxium — Propinas en restaurante: IVA, ISR y cómo registrarlas (propina voluntaria no causa IVA; cargo por servicio obligatorio sí; reporte por turno; CFDI global):** <https://praxiumconsultores.com/blog/propinas-en-restaurante-iva-isr-y-como-registrarlas>
8. **Praxium — Cómo facturar propinas y consumos ante el SAT 2026:** <https://praxiumconsultores.com/blog/como-facturar-propinas-restaurante-sat>
9. **Flipdish — Manage Dine-In Open Table Tabs (flujo de tab: asignar mesa, agregar ítems, split, pago):** <https://help.flipdish.com/en/articles/9585200-manage-dine-in-open-table-tabs>
10. **SpotOn — Start-A-Tab (apertura de cuenta de mesa en POS):** <https://help.spoton.com/space/SK/3566862372/Start-A-Tab+%7C+SpotOn+Express+(FOH)>

---

*Nota metodológica:* las fuentes 1–2 (Kassly) documentan de primera mano la lógica de negocio de renta por tiempo; las 3–6 son la documentación oficial de Firestore para timestamps/transacciones/offline/contadores; las 7–8 aportan el tratamiento fiscal mexicano de IVA y propina; las 9–10 documentan el flujo de "tab" en POS de restaurante. Las decisiones numéricas (IVA 16 %, eliminación del horario de verano en México) se basan en la normativa vigente 2024–2026.
