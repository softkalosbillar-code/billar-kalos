# Due Diligence: POS open-source para billar, gestión de mesas y renta por tiempo

> Objetivo: filtrar repositorios OSS útiles para construir una **Web App POS de billar** con
> **React + Vite + TypeScript + Tailwind + Firebase (Firestore + Auth + Hosting)**.
> Fecha de la investigación: **2026-10-27**. Métricas obtenidas vía API pública de GitHub.

## Resumen ejecutivo

- **No existe un POS open-source maduro y específico para billar/renta por tiempo.** Los proyectos
  "billiard/snooker/pool" que existen en GitHub son pequeños (0–5 ⭐), la mayoría sin licencia o
  abandonados. Sirven **solo como referencia de dominio**, no como base.
- Los **POS consolidados** (opensourcepos, Odoo POS, Chromis/uniCenta, Floreant) son la mejor fuente
  de **patrones de negocio** (tickets, recibos, inventario, plano de salón, pagos, reportes), pero
  usan stacks legacy (PHP/Java/Python) y no se integran con Firebase.
- Para tu stack objetivo, los repos más valiosos son los **React/TS/Tailwind** modernos
  (`firedevelop/POSplus`, `TheUnknown550/POS-System`) y los que ya usan **Firestore**
  (`RaizianOfficial/firebase-pos-scanner`, `SindyMl/pos`). Ninguno es "copia-y-pega": se **adaptan
  como esqueleto/referencia**, y el modelo de **mesas + cobro por tiempo** hay que diseñarlo tú.

---

## (a) Tabla comparativa

| Repo | ⭐ | Último commit | Licencia | Stack | Niche |
|---|---|---|---|---|---|
| [opensourcepos/opensourcepos](https://github.com/opensourcepos/opensourcepos) | 4 465 | 2026-10-27 (activo) | Other (propia) | PHP/CodeIgniter3 + MySQL + Bootstrap3 | POS web retail/restaurante |
| [odoo/odoo](https://github.com/odoo/odoo) | 55 376 | 2026-10-27 (activo) | LGPL-3.0 (Community) | Python + JS/OWL | ERP completo, módulo POS con plano de salón |
| [fat-tire/floreantpos](https://github.com/fat-tire/floreantpos) | 64 | 2026-07-23 | Other (GPL-3) | Java (Swing) | POS restaurante (fork activo de Floreant/uniCenta) |
| [ChromisPos/ChromisPOS](https://github.com/ChromisPos/ChromisPOS) | 20 | 2025-08-01 | GPL (fork uniCenta) | Java (Swing) | POS con floor plan / mesas |
| [vul-os/beepbite](https://github.com/vul-os/beepbite) | 6 | 2026-08-09 | Apache-2.0 | Go + React | POS restaurante self-hosted (till, KDS, plano, inventario) |
| [mateopiza/ai-point-of-sale](https://github.com/mateopiza/ai-point-of-sale) | 6 | 2026-07-25 | MIT | TypeScript | POS offline-first retail/restaurante |
| [firedevelop/POSplus](https://github.com/firedevelop/POSplus) | 5 | 2025-07-14 | MIT | **React 18 + TS + Tailwind + Vite** | UI de POS (solo frontend) |
| [shutdown57/booking](https://github.com/shutdown57/booking) | 5 | 2024-08-12 | Sin licencia | Laravel + Vue3/Inertia + Tailwind | Reservas (snooker/tenis) |
| [TheUnknown550/POS-System](https://github.com/TheUnknown550/POS-System) | 4 | 2025-09-13 | MIT (README) | **React + TS + Tailwind + Vite + Node/Express/Postgres** | POS restaurante full-stack |
| [rizuji23/kasir-billing-v4](https://github.com/rizuji23/kasir-billing-v4) | 3 | 2023-04-25 | Sin licencia | Electron + React + TS | **POS específico de billar** |
| [SindyMl/pos](https://github.com/SindyMl/pos) | 3 | 2025-09-20 | Sin licencia | Flutter/Dart + **Firebase** | POS móvil con sync Firestore |
| [RaizianOfficial/firebase-pos-scanner](https://github.com/RaizianOfficial/firebase-pos-scanner) | 2 | 2026-03-26 | MIT (README) | **Next.js + React + Tailwind + Firestore/Auth** | POS con Firestore (template) |
| [aj501/NickBilliardsPrjQT](https://github.com/aj501/NickBilliardsPrjQT) | 2 | 2023-05-15 | Other | C++/Qt | Mini-POS bar de billar |
| [steventete/SysPool](https://github.com/steventete/SysPool) | 0 | 2024-11-16 | MIT | C# (MAUI) | Reserva de mesas/productos de billar |

> ⭐/forks son instantáneas al 2026-10-27. "Último commit" = campo `pushed_at` de la API.

---

## (b) Los 5 repos más aprovechables (justificación)

### 1. `firedevelop/POSplus` — *mejor referencia de UI/UX para tu stack exacto*
- **Por qué:** React 18 + TypeScript + Tailwind CSS + Vite, **MIT**. Es prácticamente tu stack de
  frontend (solo le falta Firebase). Está **en español** entre sus 5 idiomas.
- **Qué copiar:** reducer de orden (`orderReducer` con add/remove/clear/update-tip/discount),
  cálculo de subtotales/descuentos/propinas, generación de ticket térmico, sistema de temas
  dinámicos y i18n tipada. La arquitectura `src/{components,data,reducers,types,i18n}` es limpia.
- **Límite:** no tiene backend ni persistencia (el menú está hardcodeado en `src/data/menu`). Es
  un cascarón de UI, no un POS completo.
- **Uso:** **base de UI / referencia de componentes** — no base de datos.

### 2. `TheUnknown550/POS-System` — *mejor referencia full-stack React de dominio POS*
- **Por qué:** React + TS + Tailwind + Vite en frontend y **Express + Sequelize** en backend; MIT.
  Implementa el dominio completo que necesitas: **gestión de mesas, staff, órdenes, pagos,
  multi-sucursal, dashboard**.
- **Qué copiar:** los modelos y endpoints (Product, Category, Order, Payment, Table/Staff) como
  mapa para tu esquema Firestore. Su separación `backend/` (API + modelos + migraciones/seed) es
  exactamente la estructura a replicar con Firestore rules + seed.
- **Límite:** usa PostgreSQL, no Firebase; proyecto joven (4 ⭐) y con poca actividad desde 2025-09.
- **Uso:** **referencia de arquitectura y modelo de datos** (traducir Sequelize → Firestore).

### 3. `RaizianOfficial/firebase-pos-scanner` — *esqueleto Firestore + Auth mínimo*
- **Por qué:** Next.js + React + Tailwind + **Firestore + Auth**, con el flujo completo
  scan → carrito → factura → PDF. Es la prueba de concepto más cercana a tu backend objetivo.
- **Qué copiar:** el **esquema Firestore** documentado (`products` con `barcode/name/price`;
  `sales` con `totalAmount/createdAt` y subcolección `items` con `name/price/quantity`) y el
  patrón de env vars `NEXT_PUBLIC_FIREBASE_*`. La recepción PDF con jsPDF y el escáner html5-qrcode.
- **Límite:** muy básico (2 ⭐), sin autenticación por roles real, sin mesas ni tiempo, sin
  inventario de stock.
- **Uso:** **punto de partida del cableado Firebase** — no un POS.

### 4. `opensourcepos/opensourcepos` — *mejor referencia de dominio/reportes/recibos*
- **Por qué:** es el POS web open-source más popular y mantenido (4.4k ⭐, commits en 2026). Tiene
  la **madurez de dominio** que los repos React/Firebase no tienen.
- **Qué copiar:** modelo relacional (items → sales → payments → customers/employees/suppliers),
  lógica de **recibos/refunds, impuestos, gift cards, reportes (Z-report)**, control de inventario.
- **Límite:** PHP/CodeIgniter/MySQL/Bootstrap3 (legacy), sin soporte nativo de "renta por tiempo".
- **Uso:** **referencia de negocio y de modelado de datos**, no de código.

### 5. `rizuji23/kasir-billing-v4` — *referencia específica de billar (dominio)*
- **Por qué:** es el único proyecto encontrado que declara explícitamente
  "POS & Micromanagement for Billiard (Pool)", en Electron + React + TS.
- **Qué copiar (conceptualmente):** cómo modela **mesas de billar, sesiones/tiempo de mesa y
  microgestión** (tarifas por hora, estado de mesa: libre/ocupada). Es lo más parecido a tu
  "renta por tiempo".
- **Límite:** **sin licencia** y sin commits desde 2023; no usar código tal cual, solo inspiración.
- **Uso:** **solo referencia de dominio** (y con cuidado por la licencia).

**Bonus conceptual:** `odoo/odoo` (módulo `point_of_sale`) y `ChromisPos/ChromisPOS` /
`fat-tire/floreantpos` son la mejor fuente para el **plano de salón + apertura/cierre de mesa +
tabs** y para entender el flujo completo de caja (apertura de caja → tickets → Z-report). No se
reutiliza su código (Python/Java desktop), pero sí su modelo mental.

---

## (c) Patrones de datos y arquitectura comunes

### Arquitectura (los maduros y los React convergen en lo mismo)
1. **Catálogo/productos** separados del **ticket/venta** (nunca guardar el precio solo en la venta:
   se copia el precio al `sale line` para preservar histórico).
2. **Ticket/orden como agregado:** cabecera (`sale`) + líneas (`sale items`). Cada línea es
   inmmutable y guarda `productId`, `name`, `price`, `qty`, `tax`.
3. **Pagos desnormalizados o en colección aparte** (`payments`: monto, método cash/card, cambio,
   referencia), ligados al ticket; soporta pago parcial y split.
4. **Entidades de personal y permisos:** `employees/users` con roles (admin, cajero) — en Firestore
   esto se traduce a **Auth + custom claims** y reglas de seguridad por rol.
5. **Reportes/caja:** apertura y cierre de caja (`cash session`/`shift`), y el ticket se liga a esa
   sesión para el corte (Z-report).
6. **Frontend:** un **reducer/state machine** central para la orden activa (carrito), cálculo
   derivado (subtotal, descuento, propina, impuesto, total), y persistencia al confirmar.

### Modelo de datos (equivalencia relacional → Firestore)
| Concepto | Tabla (SQL) | Colección Firestore sugerida |
|---|---|---|
| Producto/servicio (mesa-hora, bebida, combo) | `products` / `items` | `products/{id}` con `type: 'table_hour' | 'drink' | 'food'`, `price`, `taxRate`, `stock` |
| Mesas/recursos | `tables` / `places` / `floors` | `tables/{id}` con `name`, `status: free|occupied|reserved`, `ratePerHour` |
| Sesión/renta de mesa (lo específico de billar) | `table_sessions` | `tableSessions/{id}` con `tableId`, `startedAt`, `endedAt`, `ratePerHour`, `elapsedSec` |
| Ticket / orden | `tickets` / `sales` | `orders/{id}` con `tableId`, `status: open|paid`, `subtotal`, `tax`, `tip`, `total`, `createdBy` |
| Líneas | `ticketlines` / `sale_items` | subcolección `orders/{id}/items` (o array) |
| Pagos | `payments` | subcolección `orders/{id}/payments` |
| Sesión de caja | `cashregisters` / `sessions` | `shifts/{id}` con `openedAt`, `closedAt`, `openingCash`, `closingCash` |
| Usuarios | `employees` | Auth UID + `users/{uid}` (rol, nombre) |

### Patrón clave para "renta por tiempo" (lo que casi ningún repo resuelve)
- **No** modelar el tiempo como un producto normal con cantidad manual: es frágil y propenso a error.
- Modelo recomendado (inferido de kasir-billing, booking y buenas prácticas):
  - `tables` con tarifa por hora y estado.
  - `tableSessions` que registra `startedAt` y calcula el costo **en vivo** (`elapsed * rate`,
    con tarifas por franja si hace falta) hasta `endedAt`.
  - El ticket de la mesa agrega **dos tipos de línea**: el cargo de tiempo (calculado) + los
    productos consumidos (bebidas/comida). Ambos se cobran en el mismo ticket al cerrar la mesa.
- `shutdown57/booking` y `steventete/SysPool` son útiles para el lado **reserva/agenda** (slots,
  disponibilidad), que es complementario (no lo mismo) al "abrir mesa" en vivo.

---

## (d) Recomendación de stack

Para tu objetivo (POS de billar, multiusuario, bajo costo de operación), la combinación que ya
elegiste es correcta; estos son los matices que aporta la investigación:

- **Frontend:** React 18 + **Vite** + TypeScript + Tailwind + **React Router**. Toma como base de
  UI el patrón de `firedevelop/POSplus` (reducer de orden + ticket + temas) y el dominio de
  `TheUnknown550/POS-System` (mesas, staff, pagos, dashboard). Añade **TanStack Query** (o SWR)
  para cachear lecturas de Firestore y **Zustand/Context** para el carrito/UI.
- **Backend/datos:** **Firestore** (documentos + subcolecciones) en lugar de PostgreSQL. Reglas de
  seguridad por rol con **Firebase Auth + custom claims** (admin/cajero). Modelo documental de la
  tabla (c) anterior.
- **Tiempo/cobro:** implementa el cálculo de renta **en el servidor/cliente con timestamp del
  servidor** (`serverTimestamp()`) y redondeos a minuto con tarifas por franja; no confíes en el
  reloj del navegador. Para el corte, guarda `elapsedSec` congelado al cerrar.
- **Recibos:** genera ticket térmico en HTML/CSS (como `POSplus`) e imprime; para PDF usa jsPDF
  (patrón de `firebase-pos-scanner`). El recibo es una **vista del `order` ya persistido**, nunca
  la fuente de verdad.
- **Hosting:** Firebase Hosting (SPA) + Cloud Functions **solo** para: cierre de sesiones de mesa,
  cálculo de tarifas por franja, y reportes agregados (contadores para evitar lecturas costosas).
- **Qué NO usar:** no bases el producto en Odoo/Chromis/Floreant/opensourcepos (legacy, acoplamiento
  alto, hosting propio). Úsalos solo como referencia de dominio. Evita los repos "billiard" sin
  licencia como base de código.

---

## (e) Fuentes citadas (URLs reales)

- [opensourcepos/opensourcepos](https://github.com/opensourcepos/opensourcepos)
- [odoo/odoo](https://github.com/odoo/odoo)
- [fat-tire/floreantpos](https://github.com/fat-tire/floreantpos)
- [ChromisPos/ChromisPOS](https://github.com/ChromisPos/ChromisPOS)
- [vul-os/beepbite](https://github.com/vul-os/beepbite)
- [mateopiza/ai-point-of-sale](https://github.com/mateopiza/ai-point-of-sale)
- [firedevelop/POSplus](https://github.com/firedevelop/POSplus)
- [shutdown57/booking](https://github.com/shutdown57/booking)
- [TheUnknown550/POS-System](https://github.com/TheUnknown550/POS-System)
- [rizuji23/kasir-billing-v4](https://github.com/rizuji23/kasir-billing-v4)
- [SindyMl/pos](https://github.com/SindyMl/pos)
- [RaizianOfficial/firebase-pos-scanner](https://github.com/RaizianOfficial/firebase-pos-scanner)
- [aj501/NickBilliardsPrjQT](https://github.com/aj501/NickBilliardsPrjQT)
- [steventete/SysPool](https://github.com/steventete/SysPool)

*Métricas (estrellas, forks, `pushed_at`, licencia, lenguaje) obtenidas de
`https://api.github.com/repos/{owner}/{repo}` el 2026-10-27. Los README citados se leyeron desde
`raw.githubusercontent.com`.*
