import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react'
import { getStore } from '../data'
import type { Store } from '../data/store'
import type {
  BilliardTable,
  Payment,
  Product,
  Role,
  Settings,
  Shift,
  Tab,
  TableStatus,
  User,
} from '../lib/types'

export interface Toast {
  id: number
  message: string
  type: 'success' | 'error' | 'info'
}

interface AppContextValue {
  store: Store
  user: User | null
  tables: BilliardTable[]
  products: Product[]
  tabs: Tab[]
  settings: Settings
  shift: Shift | null
  loading: boolean
  toasts: Toast[]
  signIn: (name: string, role: Role) => Promise<void>
  signOut: () => Promise<void>
  refresh: () => Promise<void>
  openRental: (tableId: string) => Promise<Tab | null>
  pauseRental: (tabId: string) => Promise<void>
  resumeRental: (tabId: string) => Promise<void>
  addItem: (tabId: string, product: Product, qty: number) => Promise<void>
  setItemQty: (tabId: string, itemId: string, qty: number) => Promise<void>
  removeItem: (tabId: string, itemId: string) => Promise<void>
  setDiscount: (tabId: string, amount: number) => Promise<void>
  setTip: (tabId: string, amount: number) => Promise<void>
  closeTab: (tabId: string, payments: Payment[]) => Promise<Tab | null>
  cancelTab: (tabId: string) => Promise<void>
  setTableStatus: (tableId: string, status: TableStatus) => Promise<void>
  saveProduct: (product: Product) => Promise<void>
  saveSettings: (settings: Settings) => Promise<void>
  openShift: (cash: number) => Promise<void>
  closeShift: (cash: number) => Promise<void>
  notify: (message: string, type?: Toast['type']) => void
}

const AppContext = createContext<AppContextValue | null>(null)

let toastSeq = 0

export function AppProvider({ children }: { children: ReactNode }) {
  const store = useMemo(() => getStore(), [])
  const [user, setUser] = useState<User | null>(null)
  const [tables, setTables] = useState<BilliardTable[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [tabs, setTabs] = useState<Tab[]>([])
  const [settings, setSettings] = useState<Settings | null>(null)
  const [shift, setShift] = useState<Shift | null>(null)
  const [loading, setLoading] = useState(true)
  const [toasts, setToasts] = useState<Toast[]>([])

  const notify = useCallback(
    (message: string, type: Toast['type'] = 'info') => {
      const id = ++toastSeq
      setToasts((t) => [...t, { id, message, type }])
      setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3500)
    },
    [],
  )

  const refresh = useCallback(async () => {
    const [t, p, tb, s, sh] = await Promise.all([
      store.listTables(),
      store.listProducts(),
      store.listTabs(),
      store.getSettings(),
      store.getOpenShift(),
    ])
    setTables(t)
    setProducts(p)
    setTabs(tb)
    setSettings(s)
    setShift(sh)
  }, [store])

  useEffect(() => {
    let active = true
    ;(async () => {
      try {
        await refresh()
      } catch (e) {
        notify(e instanceof Error ? e.message : 'Error al cargar', 'error')
      } finally {
        if (active) setLoading(false)
      }
    })()
    const unsub = store.subscribe(() => {
      if (active) void refresh()
    })
    return () => {
      active = false
      unsub()
    }
  }, [store, refresh, notify])

  const run = useCallback(
    async (fn: () => Promise<unknown>) => {
      try {
        await fn()
        await refresh()
      } catch (e) {
        notify(e instanceof Error ? e.message : 'Ocurrió un error', 'error')
        throw e
      }
    },
    [refresh, notify],
  )

  const signIn = useCallback(
    async (name: string, role: Role) => {
      const u = await store.signIn(name, role)
      setUser(u)
      await refresh()
    },
    [store, refresh],
  )

  const signOut = useCallback(async () => {
    await store.signOut()
    setUser(null)
  }, [store])

  const openRental = useCallback(
    async (tableId: string): Promise<Tab | null> => {
      try {
        const tab = await store.openRental(tableId, settings!)
        await refresh()
        notify(`Mesa ${tab.tableName} rentada — cronómetro iniciado`, 'success')
        return tab
      } catch (e) {
        notify(e instanceof Error ? e.message : 'No se pudo rentar', 'error')
        return null
      }
    },
    [store, settings, refresh, notify],
  )

  const value: AppContextValue = {
    store,
    user,
    tables,
    products,
    tabs,
    settings: settings!,
    shift,
    loading,
    toasts,
    signIn,
    signOut,
    refresh,
    openRental,
    pauseRental: (tabId) => run(() => store.pauseRental(tabId)),
    resumeRental: (tabId) => run(() => store.resumeRental(tabId)),
    addItem: (tabId, product, qty) => run(() => store.addItem(tabId, product, qty)),
    setItemQty: (tabId, itemId, qty) => run(() => store.setItemQty(tabId, itemId, qty)),
    removeItem: (tabId, itemId) => run(() => store.removeItem(tabId, itemId)),
    setDiscount: (tabId, amount) => run(() => store.setDiscount(tabId, amount)),
    setTip: (tabId, amount) => run(() => store.setTip(tabId, amount)),
    closeTab: async (tabId, payments) => {
      try {
        const tab = await store.closeTab(tabId, payments)
        await refresh()
        notify(`Cobro de ${tab.tableName} completado`, 'success')
        return tab
      } catch (e) {
        notify(e instanceof Error ? e.message : 'No se pudo cobrar', 'error')
        return null
      }
    },
    cancelTab: (tabId) => run(() => store.cancelTab(tabId)),
    setTableStatus: (tableId, status) => run(() => store.setTableStatus(tableId, status)),
    saveProduct: (product) => run(() => store.saveProduct(product)),
    saveSettings: (s) => run(() => store.saveSettings(s)),
    openShift: (cash) => run(() => store.openShift(cash)),
    closeShift: (cash) => run(() => store.closeShift(cash)),
    notify,
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp debe usarse dentro de <AppProvider>')
  return ctx
}

/** Reloj de UI que hace tick cada segundo (cosmético; la facturación usa timestamps). */
export function useNow(active = true): number {
  const [now, setNow] = useState(() => Date.now())
  useEffect(() => {
    if (!active) return
    setNow(Date.now())
    const id = setInterval(() => setNow(Date.now()), 1000)
    return () => clearInterval(id)
  }, [active])
  return now
}
