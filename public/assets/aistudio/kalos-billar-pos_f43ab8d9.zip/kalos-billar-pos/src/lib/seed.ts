import type {
  BilliardTable,
  Product,
  Settings,
} from './types'

export const VENUE_ID = 'kalos'

export function seedTables(): BilliardTable[] {
  const defs: Array<[string, string, number]> = [
    ['Mesa 1', 'Estándar', 60],
    ['Mesa 2', 'Estándar', 60],
    ['Mesa 3', 'Estándar', 60],
    ['Mesa 4', 'Estándar', 60],
    ['Mesa 5', 'Premium', 90],
    ['Mesa 6', 'Premium', 90],
    ['Mesa 7', 'Snooker', 120],
    ['Mesa 8', 'Carambola', 80],
  ]
  return defs.map(([name, type, rate], i) => ({
    id: `t${i + 1}`,
    name,
    type,
    ratePerHour: rate,
    status: 'libre',
    activeTabId: null,
  }))
}

export function seedProducts(): Product[] {
  const list: Array<[string, Product['category'], number, string, number | null]> = [
    ['Corona', 'cerveza', 45, '🍺', 48],
    ['Modelo Especial', 'cerveza', 50, '🍺', 48],
    ['Victoria', 'cerveza', 48, '🍺', 40],
    ['Indio', 'cerveza', 46, '🍺', 36],
    ['Heineken', 'cerveza', 55, '🍺', 24],
    ['Michelada', 'cerveza', 60, '🍺', null],
    ['Coca-Cola', 'refresco', 25, '🥤', 60],
    ['Coca-Cola Light', 'refresco', 25, '🥤', 40],
    ['Jarrito', 'refresco', 30, '🥤', 24],
    ['Agua natural', 'refresco', 20, '💧', 80],
    ['Topo Chico', 'refresco', 35, '🥤', 36],
    ['Papas fritas', 'botana', 35, '🍟', 30],
    ['Cacahuates', 'botana', 30, '🥜', 30],
    ['Nachos con queso', 'botana', 65, '🧀', null],
    ['Alitas BBQ', 'botana', 95, '🍗', null],
    ['Palomitas', 'botana', 40, '🍿', null],
  ]
  return list.map(([name, category, price, emoji, stock], i) => ({
    id: `p${i + 1}`,
    name,
    category,
    price,
    taxRate: 0.16,
    emoji,
    stock,
    active: true,
  }))
}

export function seedSettings(): Settings {
  return {
    venueName: 'Kalos Billar Club',
    currency: 'MXN',
    taxName: 'IVA',
    defaultTaxRate: 0.16,
    minimumMinutes: 30,
    rounding: 'cuarto_hora',
    tipEnabled: true,
  }
}
