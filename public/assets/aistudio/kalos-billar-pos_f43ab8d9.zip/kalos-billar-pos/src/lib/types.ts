// ===== Tipos del dominio (Kalos Billar Club POS) =====

export type Role = 'admin' | 'cajero'

export interface User {
  uid: string
  name: string
  role: Role
  email?: string
}

// ----- Mesas -----
export type TableStatus =
  | 'libre'
  | 'ocupada'
  | 'pausada'
  | 'por_cobrar'
  | 'limpieza'
  | 'mantenimiento'

export interface BilliardTable {
  id: string
  name: string
  type: string
  ratePerHour: number
  status: TableStatus
  activeTabId: string | null
}

// ----- Productos -----
export type ProductCategory = 'cerveza' | 'refresco' | 'botana' | 'otro'

export interface Product {
  id: string
  name: string
  category: ProductCategory
  price: number
  taxRate: number
  emoji: string
  stock: number | null
  active: boolean
}

// ----- Configuración / tarifas -----
export type RoundingMode = 'exacto' | 'minuto' | 'cuarto_hora' | 'hora'

export interface Settings {
  venueName: string
  currency: string
  taxName: string
  defaultTaxRate: number
  minimumMinutes: number
  rounding: RoundingMode
  tipEnabled: boolean
}

// ----- Renta por tiempo -----
export interface RentalPause {
  pausedAt: number
  resumedAt?: number
}

export interface Rental {
  startedAt: number
  endedAt?: number
  pauses: RentalPause[]
  ratePerHour: number
  minimumMinutes: number
  rounding: RoundingMode
  taxRate: number
}

// ----- Cuenta de mesa (tab) -----
export type PaymentMethod = 'efectivo' | 'tarjeta' | 'transferencia' | 'otro'

export interface TabItem {
  id: string
  productId: string
  name: string
  emoji: string
  qty: number
  unitPrice: number
  taxRate: number
}

export interface Payment {
  id: string
  method: PaymentMethod
  amount: number
  at: number
}

export interface TabTotals {
  rentalCharge: number
  productsSubtotal: number
  subtotal: number
  tax: number
  discount: number
  tip: number
  total: number
}

export type TabStatus = 'abierta' | 'por_cobrar' | 'cerrada' | 'anulada'

export interface Tab {
  id: string
  venueId: string
  tableId: string
  tableName: string
  status: TabStatus
  openedAt: number
  closedAt?: number
  rental: Rental | null
  items: TabItem[]
  discount: number
  tip: number
  payments: Payment[]
  totals?: TabTotals
}

// ----- Caja / turno -----
export interface Shift {
  id: string
  openedAt: number
  closedAt?: number
  openingCash: number
  closingCash?: number
}
