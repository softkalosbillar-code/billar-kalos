import { computeTotals } from '../lib/billing'
import { VENUE_ID, seedProducts, seedSettings, seedTables } from '../lib/seed'
import type {
  BilliardTable,
  Payment,
  Product,
  Role,
  Settings,
  Shift,
  Tab,
  TableStatus,
  User,
} from '../lib/types'
import type { Store } from './store'

const KEY = 'kalos-pos-state-v1'

interface Persisted {
  tables: BilliardTable[]
  products: Product[]
  tabs: Tab[]
  settings: Settings
  shift: Shift | null
}

function uid(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID()
  return `id-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`
}

function emptyState(): Persisted {
  return {
    tables: seedTables(),
    products: seedProducts(),
    tabs: [],
    settings: seedSettings(),
    shift: null,
  }
}

export class LocalStore implements Store {
  readonly mode = 'demo' as const
  private state: Persisted
  private listeners = new Set<() => void>()
  private currentUser: User | null = null

  constructor() {
    this.state = this.load()
  }

  private load(): Persisted {
    try {
      const raw = localStorage.getItem(KEY)
      if (raw) return JSON.parse(raw) as Persisted
    } catch {
      /* ignore corrupt state */
    }
    return emptyState()
  }

  private persist() {
    try {
      localStorage.setItem(KEY, JSON.stringify(this.state))
    } catch {
      /* storage full or unavailable */
    }
    this.notify()
  }

  private notify() {
    for (const l of this.listeners) l()
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }

  // ----- Auth -----
  async signIn(name: string, role: Role): Promise<User> {
    this.currentUser = { uid: uid(), name, role }
    this.notify()
    return this.currentUser
  }

  async signOut(): Promise<void> {
    this.currentUser = null
    this.notify()
  }

  // ----- Lecturas -----
  async listTables(): Promise<BilliardTable[]> {
    return [...this.state.tables]
  }
  async listProducts(): Promise<Product[]> {
    return [...this.state.products]
  }
  async listTabs(): Promise<Tab[]> {
    return [...this.state.tabs].sort((a, b) => b.openedAt - a.openedAt)
  }
  async getSettings(): Promise<Settings> {
    return { ...this.state.settings }
  }
  async getOpenShift(): Promise<Shift | null> {
    return this.state.shift && !this.state.shift.closedAt
      ? { ...this.state.shift }
      : null
  }

  // ----- Renta -----
  async openRental(tableId: string, settings: Settings): Promise<Tab> {
    const table = this.state.tables.find((t) => t.id === tableId)
    if (!table) throw new Error('Mesa no encontrada')
    if (table.status !== 'libre')
      throw new Error('La mesa no está libre para rentar')

    const now = Date.now()
    const tab: Tab = {
      id: uid(),
      venueId: VENUE_ID,
      tableId,
      tableName: table.name,
      status: 'abierta',
      openedAt: now,
      rental: {
        startedAt: now,
        pauses: [],
        ratePerHour: table.ratePerHour,
        minimumMinutes: settings.minimumMinutes,
        rounding: settings.rounding,
        taxRate: settings.defaultTaxRate,
      },
      items: [],
      discount: 0,
      tip: 0,
      payments: [],
    }
    this.state.tabs.push(tab)
    table.status = 'ocupada'
    table.activeTabId = tab.id
    this.persist()
    return tab
  }

  async pauseRental(tabId: string): Promise<void> {
    const tab = this.mustTab(tabId)
    if (!tab.rental) return
    const last = tab.rental.pauses[tab.rental.pauses.length - 1]
    if (last && !last.resumedAt) return // ya está en pausa
    tab.rental.pauses.push({ pausedAt: Date.now() })
    this.setTableState(tab.tableId, 'pausada')
    this.persist()
  }

  async resumeRental(tabId: string): Promise<void> {
    const tab = this.mustTab(tabId)
    if (!tab.rental) return
    const last = tab.rental.pauses[tab.rental.pauses.length - 1]
    if (last && !last.resumedAt) last.resumedAt = Date.now()
    this.setTableState(tab.tableId, 'ocupada')
    this.persist()
  }

  // ----- Ítems -----
  async addItem(tabId: string, product: Product, qty: number): Promise<void> {
    const tab = this.mustTab(tabId)
    const existing = tab.items.find((i) => i.productId === product.id)
    if (existing) {
      existing.qty += qty
    } else {
      tab.items.push({
        id: uid(),
        productId: product.id,
        name: product.name,
        emoji: product.emoji,
        qty,
        unitPrice: product.price,
        taxRate: product.taxRate,
      })
    }
    this.decrementStock(product.id, qty)
    this.persist()
  }

  async setItemQty(tabId: string, itemId: string, qty: number): Promise<void> {
    const tab = this.mustTab(tabId)
    const item = tab.items.find((i) => i.id === itemId)
    if (!item) return
    if (qty <= 0) {
      tab.items = tab.items.filter((i) => i.id !== itemId)
    } else {
      item.qty = qty
    }
    this.persist()
  }

  async removeItem(tabId: string, itemId: string): Promise<void> {
    const tab = this.mustTab(tabId)
    tab.items = tab.items.filter((i) => i.id !== itemId)
    this.persist()
  }

  async setDiscount(tabId: string, amount: number): Promise<void> {
    this.mustTab(tabId).discount = Math.max(0, amount)
    this.persist()
  }

  async setTip(tabId: string, amount: number): Promise<void> {
    this.mustTab(tabId).tip = Math.max(0, amount)
    this.persist()
  }

  // ----- Cierre -----
  async closeTab(tabId: string, payments: Payment[]): Promise<Tab> {
    const tab = this.mustTab(tabId)
    const now = Date.now()
    if (tab.rental && !tab.rental.endedAt) tab.rental.endedAt = now
    tab.status = 'cerrada'
    tab.closedAt = now
    tab.payments = payments.map((p) => ({ ...p, at: p.at || now }))
    tab.totals = computeTotals(tab, now)
    this.freeTable(tab.tableId)
    this.persist()
    return tab
  }

  async cancelTab(tabId: string): Promise<void> {
    const tab = this.mustTab(tabId)
    if (tab.rental && !tab.rental.endedAt) tab.rental.endedAt = Date.now()
    tab.status = 'anulada'
    tab.closedAt = Date.now()
    this.freeTable(tab.tableId)
    this.persist()
  }

  // ----- Mesas -----
  async setTableStatus(tableId: string, status: TableStatus): Promise<void> {
    const table = this.state.tables.find((t) => t.id === tableId)
    if (!table) return
    if (table.status === 'ocupada' || table.status === 'pausada')
      throw new Error('No puedes cambiar una mesa que está rentada')
    table.status = status
    this.persist()
  }

  // ----- Catálogo / ajustes -----
  async saveProduct(product: Product): Promise<void> {
    const idx = this.state.products.findIndex((p) => p.id === product.id)
    if (idx >= 0) this.state.products[idx] = product
    else this.state.products.push(product)
    this.persist()
  }

  async saveSettings(settings: Settings): Promise<void> {
    this.state.settings = settings
    this.persist()
  }

  // ----- Caja -----
  async openShift(openingCash: number): Promise<Shift> {
    if (this.state.shift && !this.state.shift.closedAt)
      throw new Error('Ya hay un turno abierto')
    const shift: Shift = { id: uid(), openedAt: Date.now(), openingCash }
    this.state.shift = shift
    this.persist()
    return shift
  }

  async closeShift(closingCash: number): Promise<Shift> {
    if (!this.state.shift) throw new Error('No hay turno abierto')
    this.state.shift.closedAt = Date.now()
    this.state.shift.closingCash = closingCash
    this.persist()
    return this.state.shift
  }

  // ----- Helpers -----
  private mustTab(tabId: string): Tab {
    const tab = this.state.tabs.find((t) => t.id === tabId)
    if (!tab) throw new Error('Cuenta no encontrada')
    return tab
  }

  private setTableState(tableId: string, status: TableStatus) {
    const t = this.state.tables.find((x) => x.id === tableId)
    if (t) t.status = status
  }

  private freeTable(tableId: string) {
    const t = this.state.tables.find((x) => x.id === tableId)
    if (t) {
      t.status = 'libre'
      t.activeTabId = null
    }
  }

  private decrementStock(productId: string, qty: number) {
    const p = this.state.products.find((x) => x.id === productId)
    if (p && p.stock != null) p.stock = Math.max(0, p.stock - qty)
  }
}
