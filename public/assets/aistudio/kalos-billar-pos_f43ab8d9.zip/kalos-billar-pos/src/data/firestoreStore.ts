import {
  collection,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  setDoc,
  Timestamp,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore'
import { signInAnonymously } from 'firebase/auth'
import { getAuthInstance, getDb } from '../lib/firebase'
import { computeTotals } from '../lib/billing'
import { VENUE_ID, seedProducts, seedSettings, seedTables } from '../lib/seed'
import type {
  BilliardTable,
  Payment,
  Product,
  Role,
  Settings,
  Shift,
  Tab,
  TableStatus,
  User,
} from '../lib/types'
import type { Store } from './store'

function uid(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID()
  return `id-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`
}

/**
 * Implementación Firestore. NOTA: usa Timestamp.now() (reloj del dispositivo) por
 * simplicidad; la versión endurecida para producción debe sellar los timestamps con
 * serverTimestamp() + reglas de seguridad + transacciones (ver
 * renta-mesa-billar-especificacion.md en la raíz del workspace).
 */
export class FirestoreStore implements Store {
  readonly mode = 'firestore' as const
  private db = getDb()
  private unsubs: Array<() => void> = []
  private currentUser: User | null = null

  private col<T>(name: string) {
    return collection(this.db, 'venues', VENUE_ID, name) as unknown as ReturnType<
      typeof collection
    >
  }

  // ----- Auth (anónimo + rol en users/{uid}) -----
  async signIn(name: string, role: Role): Promise<User> {
    const auth = getAuthInstance()
    const cred = await signInAnonymously(auth)
    const userId = cred.user.uid
    await setDoc(doc(this.db, 'venues', VENUE_ID, 'users', userId), {
      name,
      role,
      updatedAt: Timestamp.now(),
    })
    this.currentUser = { uid: userId, name, role }
    return this.currentUser
  }

  async signOut(): Promise<void> {
    await getAuthInstance().signOut()
    this.currentUser = null
  }

  // ----- Lecturas -----
  async listTables(): Promise<BilliardTable[]> {
    const snap = await getDocs(query(this.col('tables')))
    return snap.docs.map((d) => d.data() as BilliardTable)
  }
  async listProducts(): Promise<Product[]> {
    const snap = await getDocs(query(this.col('products')))
    return snap.docs.map((d) => d.data() as Product)
  }
  async listTabs(): Promise<Tab[]> {
    const snap = await getDocs(
      query(this.col('tabs'), where('status', 'in', ['abierta', 'por_cobrar', 'cerrada', 'anulada'])),
    )
    return snap.docs.map((d) => d.data() as Tab)
  }
  async getSettings(): Promise<Settings> {
    const ref = doc(this.db, 'venues', VENUE_ID, 'settings', 'main')
    const snap = await getDoc(ref)
    return snap.exists() ? (snap.data() as Settings) : seedSettings()
  }
  async getOpenShift(): Promise<Shift | null> {
    const snap = await getDocs(query(this.col('shifts'), where('closedAt', '==', null)))
    if (snap.empty) return null
    return snap.docs[0].data() as Shift
  }

  subscribe(listener: () => void): () => void {
    const q = query(this.col('tabs'))
    const unsub = onSnapshot(q, listener)
    this.unsubs.push(unsub)
    return unsub
  }

  // ----- Renta -----
  async openRental(tableId: string, settings: Settings): Promise<Tab> {
    const tableRef = doc(this.db, 'venues', VENUE_ID, 'tables', tableId)
    const tableSnap = await getDoc(tableRef)
    const table = tableSnap.data() as BilliardTable
    if (!table || table.status !== 'libre')
      throw new Error('La mesa no está libre para rentar')

    const now = Timestamp.now()
    const tab: Tab = {
      id: uid(),
      venueId: VENUE_ID,
      tableId,
      tableName: table.name,
      status: 'abierta',
      openedAt: now.toMillis(),
      rental: {
        startedAt: now.toMillis(),
        pauses: [],
        ratePerHour: table.ratePerHour,
        minimumMinutes: settings.minimumMinutes,
        rounding: settings.rounding,
        taxRate: settings.defaultTaxRate,
      },
      items: [],
      discount: 0,
      tip: 0,
      payments: [],
    }
    const batch = writeBatch(this.db)
    batch.set(doc(this.db, 'venues', VENUE_ID, 'tabs', tab.id), tab)
    batch.update(tableRef, { status: 'ocupada', activeTabId: tab.id })
    await batch.commit()
    return tab
  }

  async pauseRental(tabId: string): Promise<void> {
    const ref = doc(this.db, 'venues', VENUE_ID, 'tabs', tabId)
    const tab = (await getDoc(ref)).data() as Tab
    if (!tab.rental) return
    const last = tab.rental.pauses[tab.rental.pauses.length - 1]
    if (last && !last.resumedAt) return
    tab.rental.pauses.push({ pausedAt: Date.now() })
    const batch = writeBatch(this.db)
    batch.update(ref, { rental: tab.rental })
    batch.update(doc(this.db, 'venues', VENUE_ID, 'tables', tab.tableId), {
      status: 'pausada',
    })
    await batch.commit()
  }

  async resumeRental(tabId: string): Promise<void> {
    const ref = doc(this.db, 'venues', VENUE_ID, 'tabs', tabId)
    const tab = (await getDoc(ref)).data() as Tab
    if (!tab.rental) return
    const last = tab.rental.pauses[tab.rental.pauses.length - 1]
    if (last && !last.resumedAt) last.resumedAt = Date.now()
    const batch = writeBatch(this.db)
    batch.update(ref, { rental: tab.rental })
    batch.update(doc(this.db, 'venues', VENUE_ID, 'tables', tab.tableId), {
      status: 'ocupada',
    })
    await batch.commit()
  }

  // ----- Ítems -----
  async addItem(tabId: string, product: Product, qty: number): Promise<void> {
    const ref = doc(this.db, 'venues', VENUE_ID, 'tabs', tabId)
    const tab = (await getDoc(ref)).data() as Tab
    const existing = tab.items.find((i) => i.productId === product.id)
    if (existing) existing.qty += qty
    else
      tab.items.push({
        id: uid(),
        productId: product.id,
        name: product.name,
        emoji: product.emoji,
        qty,
        unitPrice: product.price,
        taxRate: product.taxRate,
      })
    await updateDoc(ref, { items: tab.items })
  }

  async setItemQty(tabId: string, itemId: string, qty: number): Promise<void> {
    const ref = doc(this.db, 'venues', VENUE_ID, 'tabs', tabId)
    const tab = (await getDoc(ref)).data() as Tab
    if (qty <= 0) tab.items = tab.items.filter((i) => i.id !== itemId)
    else {
      const item = tab.items.find((i) => i.id === itemId)
      if (item) item.qty = qty
    }
    await updateDoc(ref, { items: tab.items })
  }

  async removeItem(tabId: string, itemId: string): Promise<void> {
    const ref = doc(this.db, 'venues', VENUE_ID, 'tabs', tabId)
    const tab = (await getDoc(ref)).data() as Tab
    tab.items = tab.items.filter((i) => i.id !== itemId)
    await updateDoc(ref, { items: tab.items })
  }

  async setDiscount(tabId: string, amount: number): Promise<void> {
    await updateDoc(doc(this.db, 'venues', VENUE_ID, 'tabs', tabId), {
      discount: Math.max(0, amount),
    })
  }
  async setTip(tabId: string, amount: number): Promise<void> {
    await updateDoc(doc(this.db, 'venues', VENUE_ID, 'tabs', tabId), {
      tip: Math.max(0, amount),
    })
  }

  // ----- Cierre -----
  async closeTab(tabId: string, payments: Payment[]): Promise<Tab> {
    const ref = doc(this.db, 'venues', VENUE_ID, 'tabs', tabId)
    const tab = (await getDoc(ref)).data() as Tab
    const now = Date.now()
    if (tab.rental && !tab.rental.endedAt) tab.rental.endedAt = now
    tab.status = 'cerrada'
    tab.closedAt = now
    tab.payments = payments
    tab.totals = computeTotals(tab, now)
    const batch = writeBatch(this.db)
    batch.update(ref, {
      status: 'cerrada',
      closedAt: now,
      rental: tab.rental,
      payments,
      totals: tab.totals,
    })
    batch.update(doc(this.db, 'venues', VENUE_ID, 'tables', tab.tableId), {
      status: 'libre',
      activeTabId: null,
    })
    await batch.commit()
    return tab
  }

  async cancelTab(tabId: string): Promise<void> {
    const ref = doc(this.db, 'venues', VENUE_ID, 'tabs', tabId)
    const tab = (await getDoc(ref)).data() as Tab
    if (tab.rental && !tab.rental.endedAt) tab.rental.endedAt = Date.now()
    const batch = writeBatch(this.db)
    batch.update(ref, { status: 'anulada', closedAt: Date.now(), rental: tab.rental })
    batch.update(doc(this.db, 'venues', VENUE_ID, 'tables', tab.tableId), {
      status: 'libre',
      activeTabId: null,
    })
    await batch.commit()
  }

  // ----- Mesas / catálogo / ajustes -----
  async setTableStatus(tableId: string, status: TableStatus): Promise<void> {
    await updateDoc(doc(this.db, 'venues', VENUE_ID, 'tables', tableId), { status })
  }
  async saveProduct(product: Product): Promise<void> {
    await setDoc(doc(this.db, 'venues', VENUE_ID, 'products', product.id), product)
  }
  async saveSettings(settings: Settings): Promise<void> {
    await setDoc(doc(this.db, 'venues', VENUE_ID, 'settings', 'main'), settings)
  }

  async openShift(openingCash: number): Promise<Shift> {
    const shift: Shift = { id: uid(), openedAt: Date.now(), openingCash }
    await setDoc(doc(this.db, 'venues', VENUE_ID, 'shifts', shift.id), shift)
    return shift
  }
  async closeShift(closingCash: number): Promise<Shift> {
    const snap = await getDocs(query(this.col('shifts'), where('closedAt', '==', null)))
    if (snap.empty) throw new Error('No hay turno abierto')
    const ref = snap.docs[0].ref
    const data = snap.docs[0].data() as Shift
    data.closedAt = Date.now()
    data.closingCash = closingCash
    await updateDoc(ref, { closedAt: data.closedAt, closingCash })
    return data
  }
}

// seed exports se re-exportan para referencia externa sin warnings de no-uso
export const _seed = { seedTables, seedProducts, seedSettings }
