import type {
  BilliardTable,
  Payment,
  Product,
  Role,
  Settings,
  Shift,
  Tab,
  TableStatus,
  User,
} from '../lib/types'

/**
 * Contrato de persistencia del POS. Dos implementaciones:
 *  - LocalStore  (demo, localStorage) — funciona sin backend.
 *  - FirestoreStore (Google Firebase) — producción.
 */
export interface Store {
  readonly mode: 'demo' | 'firestore'

  signIn(name: string, role: Role): Promise<User>
  signOut(): Promise<void>

  listTables(): Promise<BilliardTable[]>
  listProducts(): Promise<Product[]>
  listTabs(): Promise<Tab[]>
  getSettings(): Promise<Settings>
  getOpenShift(): Promise<Shift | null>

  openRental(tableId: string, settings: Settings): Promise<Tab>
  pauseRental(tabId: string): Promise<void>
  resumeRental(tabId: string): Promise<void>

  addItem(tabId: string, product: Product, qty: number): Promise<void>
  setItemQty(tabId: string, itemId: string, qty: number): Promise<void>
  removeItem(tabId: string, itemId: string): Promise<void>
  setDiscount(tabId: string, amount: number): Promise<void>
  setTip(tabId: string, amount: number): Promise<void>

  closeTab(tabId: string, payments: Payment[]): Promise<Tab>
  cancelTab(tabId: string): Promise<void>

  setTableStatus(tableId: string, status: TableStatus): Promise<void>
  saveProduct(product: Product): Promise<void>
  saveSettings(settings: Settings): Promise<void>

  openShift(openingCash: number): Promise<Shift>
  closeShift(closingCash: number): Promise<Shift>

  /** Suscripción a cambios (realtime en Firestore, eventos locales en demo). */
  subscribe(listener: () => void): () => void
}
