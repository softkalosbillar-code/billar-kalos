import { isFirebaseConfigured } from '../lib/firebase'
import { FirestoreStore } from './firestoreStore'
import { LocalStore } from './localStore'
import type { Store } from './store'

let store: Store | null = null

/**
 * Devuelve la implementación activa:
 *  - demo (localStorage) por defecto o si VITE_DEMO_MODE=true / sin config de Firebase.
 *  - firestore cuando hay config y VITE_DEMO_MODE=false.
 */
export function getStore(): Store {
  if (store) return store
  const demoMode = import.meta.env.VITE_DEMO_MODE !== 'false'
  if (demoMode || !isFirebaseConfigured()) {
    store = new LocalStore()
  } else {
    store = new FirestoreStore()
  }
  return store
}

export type { Store }
