import { useMemo, useState, type ReactNode } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import {
  ArrowLeft,
  Banknote,
  CheckCircle2,
  CreditCard,
  Minus,
  Pause,
  Play,
  Plus,
  ReceiptText,
  Trash2,
  Wallet,
  X,
} from 'lucide-react'
import { useApp, useNow } from '../state/AppContext'
import { computeRentalCharge, computeTotals } from '../lib/billing'
import { money, moneyNoSymbol, duration } from '../lib/format'
import { facturableElapsedSec } from '../lib/time'
import { Modal } from '../components/Modal'
import { ProductTile } from '../components/ProductTile'
import type { Payment, PaymentMethod, Product, ProductCategory, Tab } from '../lib/types'

type CatFilter = 'todo' | ProductCategory

const CATS: { id: CatFilter; label: string }[] = [
  { id: 'todo', label: 'Todo' },
  { id: 'cerveza', label: '🍺 Cerveza' },
  { id: 'refresco', label: '🥤 Refrescos' },
  { id: 'botana', label: '🍿 Botana' },
]

export function CuentaMesa() {
  const { tabId } = useParams()
  const navigate = useNavigate()
  const {
    tabs,
    products,
    settings,
    addItem,
    setItemQty,
    removeItem,
    pauseRental,
    resumeRental,
    closeTab,
    cancelTab,
  } = useApp()

  const [cat, setCat] = useState<CatFilter>('todo')
  const [checkoutOpen, setCheckoutOpen] = useState(false)
  const [cancelOpen, setCancelOpen] = useState(false)
  const [receipt, setReceipt] = useState<Tab | null>(null)

  const tab = tabs.find((t) => t.id === tabId)
  const active = !!tab && (tab.status === 'abierta' || tab.status === 'por_cobrar')
  const now = useNow(active)

  const rental = tab?.rental ?? null
  const charge = rental ? computeRentalCharge(rental, now) : null
  const totals = tab ? computeTotals(tab, now) : null

  const isPaused =
    !!rental && rental.pauses.length > 0 && !rental.pauses[rental.pauses.length - 1].resumedAt

  const filtered = useMemo(
    () =>
      cat === 'todo'
        ? products.filter((p) => p.active)
        : products.filter((p) => p.active && p.category === cat),
    [cat, products],
  )

  if (!tab) {
    return (
      <div className="min-h-dvh bg-bg grid place-items-center px-6 text-center">
        <div>
          <ReceiptText size={40} className="mx-auto text-ink-3" />
          <p className="mt-4 text-ink-1 font-semibold">Cuenta no encontrada</p>
          <button
            onClick={() => navigate('/')}
            className="mt-4 inline-flex items-center gap-2 text-brand font-medium"
          >
            <ArrowLeft size={18} /> Volver a mesas
          </button>
        </div>
      </div>
    )
  }

  const elapsedSec = active && rental ? facturableElapsedSec(rental, now) : 0

  async function onPaid(method: PaymentMethod, received: number) {
    const payments: Payment[] = [
      { id: `pay-${Date.now()}`, method, amount: totals!.total, at: Date.now() },
    ]
    void received // change is computed locally, not persisted
    const closed = await closeTab(tab!.id, payments)
    if (closed) setReceipt(closed)
  }

  return (
    <div className="min-h-dvh bg-bg flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-white/10 bg-bg/85 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto w-full px-4 sm:px-6 py-3 flex items-center gap-3">
          <button
            onClick={() => navigate('/')}
            className="p-2.5 rounded-xl hover:bg-white/10 text-ink-2 transition-colors"
            aria-label="Volver"
          >
            <ArrowLeft size={22} />
          </button>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h1 className="font-display text-lg font-bold text-ink-1 truncate">
                {tab.tableName}
              </h1>
              {isPaused && (
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-warning/20 text-warning">
                  Pausada
                </span>
              )}
            </div>
            <p className="text-xs text-ink-3">
              {money(tab.rental?.ratePerHour ?? 0)}/h · abierta a las{' '}
              {new Date(tab.openedAt).toLocaleTimeString('es-MX', {
                hour: '2-digit',
                minute: '2-digit',
              })}
            </p>
          </div>

          {active && rental && (
            <button
              onClick={() => (isPaused ? resumeRental(tab.id) : pauseRental(tab.id))}
              className={`inline-flex items-center gap-2 h-11 px-4 rounded-xl font-semibold transition active:scale-[0.97] ${
                isPaused
                  ? 'bg-brand text-brand-on hover:bg-brand-hover'
                  : 'bg-surface-3 border border-white/10 text-ink-1 hover:border-white/25'
              }`}
            >
              {isPaused ? <Play size={18} /> : <Pause size={18} />}
              <span className="hidden sm:inline">
                {isPaused ? 'Reanudar' : 'Pausar'}
              </span>
            </button>
          )}
        </div>
      </header>

      {/* Cronómetro destacado */}
      <div className="border-b border-white/10 bg-surface-1/50">
        <div className="max-w-6xl mx-auto w-full px-4 sm:px-6 py-4 flex flex-wrap items-end justify-between gap-4">
          <div>
            <div className="text-[11px] uppercase tracking-wider text-ink-3 font-medium">
              Tiempo transcurrido
            </div>
            <div className="font-mono text-4xl sm:text-5xl font-semibold text-ink-1 tabular-nums tracking-tight">
              {duration(elapsedSec)}
            </div>
          </div>
          <div className="text-right">
            <div className="text-[11px] uppercase tracking-wider text-ink-3 font-medium">
              Renta
            </div>
            <div className="font-mono text-3xl font-semibold text-brand tabular-nums">
              {money(charge?.charge ?? 0)}
            </div>
          </div>
        </div>
      </div>

      {/* Cuerpo */}
      <div className="flex-1 max-w-6xl mx-auto w-full px-4 sm:px-6 py-5">
        <div className="grid lg:grid-cols-[1.1fr_0.9fr] gap-5 items-start">
          {/* Productos */}
          <section className="order-2 lg:order-1">
            <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
              {CATS.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setCat(c.id)}
                  className={`shrink-0 h-10 px-4 rounded-full text-sm font-medium transition ${
                    cat === c.id
                      ? 'bg-surface-3 text-ink-1 border border-white/20'
                      : 'bg-surface-2 text-ink-2 border border-white/10'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>
            <div className="mt-4 grid grid-cols-3 sm:grid-cols-4 gap-2.5">
              {filtered.map((p) => (
                <ProductTile
                  key={p.id}
                  product={p}
                  compact
                  onAdd={(prod) => addItem(tab.id, prod, 1)}
                />
              ))}
            </div>
          </section>

          {/* Carrito */}
          <section className="order-1 lg:order-2 lg:sticky lg:top-20">
            <div className="rounded-card border border-white/10 bg-surface-2 shadow-card overflow-hidden">
              <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between">
                <h2 className="font-semibold text-ink-1">Cuenta</h2>
                <span className="text-xs text-ink-3">
                  {tab.items.reduce((s, i) => s + i.qty, 0)} productos
                </span>
              </div>

              <div className="divide-y divide-white/5 max-h-[46vh] overflow-y-auto">
                {rental && (
                  <div className="flex items-center justify-between px-4 py-3">
                    <div className="flex items-center gap-3">
                      <span className="text-xl">🎱</span>
                      <div>
                        <div className="text-sm font-medium text-ink-1">
                          Renta de mesa
                        </div>
                        <div className="text-xs text-ink-3">
                          {duration(elapsedSec)}
                        </div>
                      </div>
                    </div>
                    <span className="text-sm font-semibold text-ink-1 tabular-nums">
                      {money(charge?.charge ?? 0)}
                    </span>
                  </div>
                )}

                {tab.items.map((item) => (
                  <div key={item.id} className="flex items-center gap-3 px-4 py-3">
                    <span className="text-xl">{item.emoji}</span>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-ink-1 truncate">
                        {item.name}
                      </div>
                      <div className="text-xs text-ink-3 tabular-nums">
                        {money(item.unitPrice)} c/u
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <StepBtn
                        onClick={() => setItemQty(tab.id, item.id, item.qty - 1)}
                        disabled={item.qty <= 1}
                        icon={<Minus size={16} />}
                      />
                      <span className="w-7 text-center text-sm font-semibold tabular-nums">
                        {item.qty}
                      </span>
                      <StepBtn
                        onClick={() => setItemQty(tab.id, item.id, item.qty + 1)}
                        icon={<Plus size={16} />}
                      />
                      <button
                        onClick={() => removeItem(tab.id, item.id)}
                        className="ml-1 p-2 rounded-lg text-ink-3 hover:text-danger hover:bg-danger/10 transition-colors"
                        aria-label="Quitar"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}

                {!rental && tab.items.length === 0 && (
                  <div className="px-4 py-8 text-center text-sm text-ink-3">
                    Agrega productos a esta cuenta
                  </div>
                )}
              </div>

              <div className="px-4 py-4 border-t border-white/10 space-y-1.5 text-sm">
                <Row label="Productos" value={money(totals?.productsSubtotal ?? 0)} />
                <Row label="Renta" value={money(totals?.rentalCharge ?? 0)} />
                <Row label={settings.taxName} value={money(totals?.tax ?? 0)} />
              </div>
            </div>
          </section>
        </div>
      </div>

      {/* Barra de cobro */}
      <footer className="sticky bottom-0 z-30 border-t border-white/10 bg-surface-1/90 backdrop-blur-xl pb-[env(safe-area-inset-bottom)]">
        <div className="max-w-6xl mx-auto w-full px-4 sm:px-6 py-3 flex items-center gap-3">
          <div className="flex-1 min-w-0">
            <div className="text-[11px] uppercase tracking-wider text-ink-3 font-medium">
              Total a cobrar
            </div>
            <div className="font-display text-2xl font-bold text-ink-1 tabular-nums">
              {money(totals?.total ?? 0)}
            </div>
          </div>
          <button
            onClick={() => setCancelOpen(true)}
            className="h-12 px-4 rounded-xl border border-white/10 text-ink-2 hover:text-danger hover:border-danger/40 transition"
          >
            Anular
          </button>
          <button
            onClick={() => setCheckoutOpen(true)}
            className="h-12 px-6 rounded-xl bg-brand text-brand-on font-bold hover:bg-brand-hover active:scale-[0.97] transition"
          >
            Cobrar
          </button>
        </div>
      </footer>

      {checkoutOpen && totals && (
        <Checkout
          total={totals.total}
          tipEnabled={settings.tipEnabled}
          onClose={() => setCheckoutOpen(false)}
          onPaid={onPaid}
        />
      )}

      <Modal open={cancelOpen} onClose={() => setCancelOpen(false)} title="Anular cuenta">
        <p className="text-sm text-ink-2">
          La cuenta de <strong className="text-ink-1">{tab.tableName}</strong> se
          cancelará y la mesa quedará libre. Esta acción no se puede deshacer.
        </p>
        <div className="mt-5 flex gap-3">
          <button
            onClick={() => setCancelOpen(false)}
            className="flex-1 h-12 rounded-xl bg-surface-3 border border-white/10 text-ink-1 font-semibold"
          >
            Regresar
          </button>
          <button
            onClick={async () => {
              await cancelTab(tab.id)
              setCancelOpen(false)
              navigate('/')
            }}
            className="flex-1 h-12 rounded-xl bg-danger text-white font-semibold hover:brightness-110"
          >
            Anular
          </button>
        </div>
      </Modal>

      {receipt && <ReceiptOverlay tab={receipt} onDone={() => navigate('/')} />}
    </div>
  )
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between text-ink-2">
      <span>{label}</span>
      <span className="text-ink-1 tabular-nums font-medium">{value}</span>
    </div>
  )
}

function StepBtn({
  onClick,
  disabled,
  icon,
}: {
  onClick: () => void
  disabled?: boolean
  icon: ReactNode
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="p-2 rounded-lg bg-surface-3 border border-white/10 text-ink-1 hover:border-white/25 disabled:opacity-30 transition active:scale-90"
    >
      {icon}
    </button>
  )
}

const METHODS: { id: PaymentMethod; label: string; icon: typeof Banknote }[] = [
  { id: 'efectivo', label: 'Efectivo', icon: Banknote },
  { id: 'tarjeta', label: 'Tarjeta', icon: CreditCard },
  { id: 'transferencia', label: 'Transferencia', icon: Wallet },
  { id: 'otro', label: 'Otro', icon: Banknote },
]

function Checkout({
  total,
  tipEnabled,
  onClose,
  onPaid,
}: {
  total: number
  tipEnabled: boolean
  onClose: () => void
  onPaid: (method: PaymentMethod, received: number) => void
}) {
  const [method, setMethod] = useState<PaymentMethod>('efectivo')
  const [tip, setTip] = useState('')
  const [received, setReceived] = useState('')

  const tipVal = Number(tip) || 0
  const grandTotal = total + tipVal
  const receivedVal = Number(received) || 0
  const change = receivedVal - grandTotal

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full sm:max-w-md rounded-t-modal sm:rounded-modal bg-surface-4 border border-white/10 shadow-modal max-h-[92vh] overflow-y-auto animate-rise">
        <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4 border-b border-white/10 bg-surface-4">
          <h2 className="text-ink-1 font-semibold text-lg">Cobrar</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-white/10 text-ink-2"
            aria-label="Cerrar"
          >
            <X size={20} />
          </button>
        </div>

        <div className="p-5 space-y-5">
          <div className="text-center">
            <div className="text-xs text-ink-3 uppercase tracking-wider">Total</div>
            <div className="font-display text-4xl font-bold text-ink-1 tabular-nums">
              {money(total)}
            </div>
            {tipVal > 0 && (
              <div className="text-xs text-ink-2 mt-1">
                + propina {money(tipVal)} = {money(grandTotal)}
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            {METHODS.map((m) => (
              <button
                key={m.id}
                onClick={() => setMethod(m.id)}
                className={`flex flex-col items-center gap-2 rounded-2xl border py-4 transition ${
                  method === m.id
                    ? 'border-brand bg-brand-soft text-brand'
                    : 'border-white/10 bg-surface-3 text-ink-2'
                }`}
              >
                <m.icon size={24} />
                <span className="text-sm font-medium">{m.label}</span>
              </button>
            ))}
          </div>

          {method === 'efectivo' && (
            <div>
              <label className="text-xs text-ink-3 uppercase tracking-wider">
                Recibido
              </label>
              <input
                inputMode="decimal"
                value={received}
                onChange={(e) => setReceived(e.target.value)}
                placeholder={moneyNoSymbol(grandTotal)}
                className="mt-1.5 w-full h-12 px-4 rounded-xl bg-surface-3 border border-white/10 text-ink-1 font-mono text-lg focus:outline-none focus:border-brand/60"
              />
              {receivedVal > 0 && (
                <div
                  className={`mt-2 text-sm font-medium ${
                    change >= 0 ? 'text-success' : 'text-danger'
                  }`}
                >
                  {change >= 0
                    ? `Cambio: ${money(change)}`
                    : `Faltan: ${money(Math.abs(change))}`}
                </div>
              )}
            </div>
          )}

          {tipEnabled && (
            <div>
              <label className="text-xs text-ink-3 uppercase tracking-wider">
                Propina (opcional)
              </label>
              <input
                inputMode="decimal"
                value={tip}
                onChange={(e) => setTip(e.target.value)}
                placeholder="0.00"
                className="mt-1.5 w-full h-12 px-4 rounded-xl bg-surface-3 border border-white/10 text-ink-1 font-mono text-lg focus:outline-none focus:border-brand/60"
              />
            </div>
          )}

          <button
            onClick={() => onPaid(method, receivedVal)}
            className="w-full h-14 rounded-xl bg-brand text-brand-on font-bold hover:bg-brand-hover active:scale-[0.98] transition"
          >
            Cobrar {money(grandTotal)}
          </button>
        </div>
      </div>
    </div>
  )
}

function ReceiptOverlay({ tab, onDone }: { tab: Tab; onDone: () => void }) {
  const t = tab.totals
  return (
    <div className="fixed inset-0 z-[60] grid place-items-center bg-black/70 backdrop-blur-sm px-4">
      <div className="w-full max-w-sm rounded-modal bg-surface-4 border border-white/10 shadow-modal p-6 animate-rise">
        <CheckCircle2 size={48} className="mx-auto text-success" />
        <h2 className="mt-4 text-center font-display text-xl font-bold text-ink-1">
          Cobro completado
        </h2>
        <p className="text-center text-sm text-ink-2 mt-1">
          {tab.tableName} · {tab.items.length} productos + renta
        </p>

        <div className="mt-5 rounded-card bg-surface-3 border border-white/10 p-4 space-y-2 text-sm">
          <Row label="Renta" value={money(t?.rentalCharge ?? 0)} />
          <Row label="Productos" value={money(t?.productsSubtotal ?? 0)} />
          <Row label="IVA" value={money(t?.tax ?? 0)} />
          {t?.tip ? <Row label="Propina" value={money(t.tip)} /> : null}
          <div className="border-t border-white/10 pt-2 flex items-center justify-between">
            <span className="font-semibold text-ink-1">Total</span>
            <span className="font-display text-2xl font-bold text-brand tabular-nums">
              {money(t?.total ?? 0)}
            </span>
          </div>
        </div>

        <button
          onClick={onDone}
          className="mt-5 w-full h-12 rounded-xl bg-brand text-brand-on font-bold hover:bg-brand-hover transition"
        >
          Listo
        </button>
      </div>
    </div>
  )
}
