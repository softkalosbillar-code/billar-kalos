import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Brush, Wrench, CircleCheck } from 'lucide-react'
import { useApp } from '../state/AppContext'
import { TableCard } from '../components/TableCard'
import { Modal } from '../components/Modal'
import type { BilliardTable, Tab } from '../lib/types'

export function Mesas() {
  const { tables, tabs, openRental, setTableStatus } = useApp()
  const navigate = useNavigate()
  const [menuTable, setMenuTable] = useState<BilliardTable | null>(null)

  const activeTab = (table: BilliardTable): Tab | null =>
    table.activeTabId
      ? tabs.find((t) => t.id === table.activeTabId && t.status !== 'cerrada' && t.status !== 'anulada') ?? null
      : null

  const occupied = tables.filter(
    (t) => t.status === 'ocupada' || t.status === 'pausada',
  ).length
  const libre = tables.filter((t) => t.status === 'libre').length

  async function onTap(table: BilliardTable) {
    if (table.status === 'libre') {
      const tab = await openRental(table.id)
      if (tab) navigate(`/mesa/${tab.id}`)
    } else if (table.status === 'ocupada' || table.status === 'pausada') {
      if (table.activeTabId) navigate(`/mesa/${table.activeTabId}`)
    }
  }

  return (
    <div>
      <div className="flex items-end justify-between gap-4 mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-ink-1">Mesas</h1>
          <p className="text-sm text-ink-2 mt-1">
            {occupied} ocupadas · {libre} libres · {tables.length} en total
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3">
        {tables.map((table) => (
          <TableCard
            key={table.id}
            table={table}
            tab={activeTab(table)}
            onTap={() => onTap(table)}
            onMenu={() => setMenuTable(table)}
          />
        ))}
      </div>

      <Modal
        open={!!menuTable}
        onClose={() => setMenuTable(null)}
        title={menuTable?.name}
      >
        {menuTable && (
          <div className="space-y-2">
            {menuTable.status === 'libre' && (
              <>
                <MenuAction
                  icon={Brush}
                  label="Marcar en limpieza"
                  onClick={async () => {
                    await setTableStatus(menuTable.id, 'limpieza')
                    setMenuTable(null)
                  }}
                />
                <MenuAction
                  icon={Wrench}
                  label="Marcar en mantenimiento"
                  onClick={async () => {
                    await setTableStatus(menuTable.id, 'mantenimiento')
                    setMenuTable(null)
                  }}
                />
              </>
            )}
            {(menuTable.status === 'limpieza' || menuTable.status === 'mantenimiento') && (
              <MenuAction
                icon={CircleCheck}
                label="Poner disponible"
                onClick={async () => {
                  await setTableStatus(menuTable.id, 'libre')
                  setMenuTable(null)
                }}
              />
            )}
            {(menuTable.status === 'ocupada' || menuTable.status === 'pausada') && (
              <MenuAction
                icon={CircleCheck}
                label="Ver cuenta de la mesa"
                onClick={() => {
                  if (menuTable.activeTabId) navigate(`/mesa/${menuTable.activeTabId}`)
                  setMenuTable(null)
                }}
              />
            )}
            {menuTable.status === 'libre' && (
              <MenuAction
                icon={CircleCheck}
                label="Rentar ahora"
                onClick={async () => {
                  const tab = await openRental(menuTable.id)
                  setMenuTable(null)
                  if (tab) navigate(`/mesa/${tab.id}`)
                }}
              />
            )}
          </div>
        )}
      </Modal>
    </div>
  )
}

function MenuAction({
  icon: Icon,
  label,
  onClick,
}: {
  icon: typeof Brush
  label: string
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-surface-3 border border-white/10 text-ink-1 text-sm font-medium hover:border-white/25 active:scale-[0.98] transition"
    >
      <Icon size={18} className="text-brand" />
      {label}
    </button>
  )
}
