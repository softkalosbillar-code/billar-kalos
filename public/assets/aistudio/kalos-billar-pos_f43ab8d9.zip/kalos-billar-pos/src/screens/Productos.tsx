import { useState, type ReactNode } from 'react'
import { Package, Plus } from 'lucide-react'
import { useApp } from '../state/AppContext'
import { ProductTile } from '../components/ProductTile'
import { Modal } from '../components/Modal'
import type { Product, ProductCategory } from '../lib/types'

const CAT_OPTIONS: { id: ProductCategory; label: string }[] = [
  { id: 'cerveza', label: '🍺 Cerveza' },
  { id: 'refresco', label: '🥤 Refresco' },
  { id: 'botana', label: '🍿 Botana' },
  { id: 'otro', label: '📦 Otro' },
]

const EMPTY: Omit<Product, 'id'> = {
  name: '',
  category: 'cerveza',
  price: 0,
  taxRate: 0.16,
  emoji: '🍺',
  stock: null,
  active: true,
}

export function Productos() {
  const { products, saveProduct, user, settings } = useApp()
  const [editing, setEditing] = useState<Product | null>(null)
  const [creating, setCreating] = useState(false)

  const admin = user?.role === 'admin'

  function openNew() {
    setCreating(true)
  }

  function openEdit(p: Product) {
    setEditing(p)
  }

  return (
    <div>
      <div className="flex items-end justify-between gap-4 mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-ink-1">Productos</h1>
          <p className="text-sm text-ink-2 mt-1">
            {products.filter((p) => p.active).length} activos · IVA{' '}
            {Math.round(settings.defaultTaxRate * 100)}%
          </p>
        </div>
        {admin && (
          <button
            onClick={openNew}
            className="inline-flex items-center gap-2 h-11 px-4 rounded-xl bg-brand text-brand-on font-semibold hover:bg-brand-hover active:scale-[0.97] transition"
          >
            <Plus size={18} />
            <span className="hidden sm:inline">Nuevo producto</span>
          </button>
        )}
      </div>

      {products.length === 0 ? (
        <div className="grid place-items-center py-20 text-center">
          <Package size={40} className="text-ink-3" />
          <p className="mt-3 text-ink-2">No hay productos todavía</p>
        </div>
      ) : (
        <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-2.5">
          {products.map((p) => (
            <ProductTile
              key={p.id}
              product={p}
              onEdit={admin ? openEdit : undefined}
            />
          ))}
        </div>
      )}

      {(creating || editing) && (
        <ProductForm
          initial={editing ?? { ...EMPTY, id: `p-${Date.now()}` }}
          onClose={() => {
            setCreating(false)
            setEditing(null)
          }}
          onSave={async (p) => {
            await saveProduct(p)
            setCreating(false)
            setEditing(null)
          }}
        />
      )}
    </div>
  )
}

function ProductForm({
  initial,
  onClose,
  onSave,
}: {
  initial: Product
  onClose: () => void
  onSave: (p: Product) => Promise<void>
}) {
  const [draft, setDraft] = useState<Product>(initial)

  function set<K extends keyof Product>(k: K, v: Product[K]) {
    setDraft((d) => ({ ...d, [k]: v }))
  }

  return (
    <Modal
      open
      onClose={onClose}
      title={initial.name ? `Editar ${initial.name}` : 'Nuevo producto'}
    >
      <div className="space-y-4">
        <Field label="Nombre">
          <input
            value={draft.name}
            onChange={(e) => set('name', e.target.value)}
            className={inputCls}
            placeholder="Ej. Corona"
          />
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Categoría">
            <select
              value={draft.category}
              onChange={(e) => set('category', e.target.value as ProductCategory)}
              className={inputCls}
            >
              {CAT_OPTIONS.map((c) => (
                <option key={c.id} value={c.id} className="bg-surface-4">
                  {c.label}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Emoji">
            <input
              value={draft.emoji}
              onChange={(e) => set('emoji', e.target.value)}
              className={inputCls}
            />
          </Field>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Precio (MXN)">
            <input
              inputMode="decimal"
              value={draft.price === 0 ? '' : String(draft.price)}
              onChange={(e) => set('price', Number(e.target.value) || 0)}
              className={inputCls}
              placeholder="0.00"
            />
          </Field>
          <Field label="Stock (vacío = ilimitado)">
            <input
              inputMode="numeric"
              value={draft.stock == null ? '' : String(draft.stock)}
              onChange={(e) =>
                set('stock', e.target.value === '' ? null : Number(e.target.value))
              }
              className={inputCls}
              placeholder="∞"
            />
          </Field>
        </div>

        <label className="flex items-center gap-3 text-sm text-ink-2">
          <input
            type="checkbox"
            checked={draft.active}
            onChange={(e) => set('active', e.target.checked)}
            className="w-4 h-4 accent-[#E6B349]"
          />
          Producto activo (visible en caja)
        </label>

        <button
          onClick={() => onSave(draft)}
          disabled={!draft.name.trim()}
          className="w-full h-12 rounded-xl bg-brand text-brand-on font-bold hover:bg-brand-hover disabled:opacity-40 transition"
        >
          Guardar
        </button>
      </div>
    </Modal>
  )
}

const inputCls =
  'mt-1.5 w-full h-11 px-3.5 rounded-xl bg-surface-3 border border-white/10 text-ink-1 focus:outline-none focus:border-brand/60 transition'

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <label className="text-xs text-ink-3 uppercase tracking-wider">{label}</label>
      {children}
    </div>
  )
}
