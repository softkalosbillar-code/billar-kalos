import { useMemo, type ReactNode } from 'react'
import { BarChart3 } from 'lucide-react'
import { useApp } from '../state/AppContext'
import { money } from '../lib/format'
import { facturableElapsedSec } from '../lib/time'

export function Reportes() {
  const { tabs, tables } = useApp()

  const todayStart = new Date()
  todayStart.setHours(0, 0, 0, 0)

  const todaySales = useMemo(
    () =>
      tabs.filter(
        (t) => t.status === 'cerrada' && (t.closedAt ?? 0) >= todayStart.getTime(),
      ),
    [tabs, todayStart],
  )

  const ventasHoy = todaySales.reduce((s, t) => s + (t.totals?.total ?? 0), 0)
  const ticketPromedio = todaySales.length ? ventasHoy / todaySales.length : 0
  const horasRentadas = todaySales.reduce((s, t) => {
    if (!t.rental) return s
    return s + facturableElapsedSec(t.rental, t.rental.endedAt ?? t.openedAt) / 3600
  }, 0)
  const ocupadas = tables.filter(
    (t) => t.status === 'ocupada' || t.status === 'pausada',
  ).length

  const topProducts = useMemo(() => {
    const m = new Map<string, { name: string; emoji: string; qty: number }>()
    for (const t of todaySales)
      for (const i of t.items) {
        const cur = m.get(i.productId) ?? { name: i.name, emoji: i.emoji, qty: 0 }
        cur.qty += i.qty
        m.set(i.productId, cur)
      }
    return [...m.values()].sort((a, b) => b.qty - a.qty).slice(0, 5)
  }, [todaySales])

  const byTable = useMemo(() => {
    const m = new Map<string, number>()
    for (const t of todaySales)
      m.set(t.tableName, (m.get(t.tableName) ?? 0) + (t.totals?.total ?? 0))
    return [...m.entries()].sort((a, b) => b[1] - a[1])
  }, [todaySales])

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-display text-2xl font-bold text-ink-1">Reportes</h1>
        <p className="text-sm text-ink-2 mt-1">Resumen de hoy</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Kpi label="Ventas hoy" value={money(ventasHoy)} accent />
        <Kpi label="Horas rentadas" value={`${horasRentadas.toFixed(1)} h`} />
        <Kpi label="Ticket promedio" value={money(ticketPromedio)} />
        <Kpi label="Mesas ocupadas" value={`${ocupadas} / ${tables.length}`} />
      </div>

      <div className="grid lg:grid-cols-2 gap-5 mt-6">
        <Panel title="Top productos">
          {topProducts.length === 0 ? (
            <Empty />
          ) : (
            <div className="space-y-2">
              {topProducts.map((p, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="w-6 text-center text-xs text-ink-3 font-semibold">
                    {i + 1}
                  </span>
                  <span className="text-lg">{p.emoji}</span>
                  <span className="flex-1 text-sm text-ink-1 truncate">{p.name}</span>
                  <span className="text-sm font-semibold text-ink-1 tabular-nums">
                    {p.qty}
                  </span>
                </div>
              ))}
            </div>
          )}
        </Panel>

        <Panel title="Ventas por mesa">
          {byTable.length === 0 ? (
            <Empty />
          ) : (
            <div className="space-y-2.5">
              {byTable.map(([name, v]) => {
                const max = byTable[0][1] || 1
                return (
                  <div key={name}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-ink-2">{name}</span>
                      <span className="text-ink-1 tabular-nums font-medium">
                        {money(v)}
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-surface-3 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-brand"
                        style={{ width: `${Math.max(4, (v / max) * 100)}%` }}
                      />
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </Panel>
      </div>
    </div>
  )
}

function Kpi({
  label,
  value,
  accent,
}: {
  label: string
  value: string
  accent?: boolean
}) {
  return (
    <div className="rounded-card border border-white/10 bg-surface-2 p-4">
      <div className="text-xs text-ink-3 uppercase tracking-wider">{label}</div>
      <div
        className={`mt-1.5 font-display text-2xl font-bold tabular-nums ${
          accent ? 'text-brand' : 'text-ink-1'
        }`}
      >
        {value}
      </div>
    </div>
  )
}

function Panel({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="rounded-card border border-white/10 bg-surface-2 p-5">
      <h2 className="font-semibold text-ink-1 mb-4">{title}</h2>
      {children}
    </div>
  )
}

function Empty() {
  return (
    <div className="py-6 text-center text-sm text-ink-3 flex items-center justify-center gap-2">
      <BarChart3 size={18} /> Sin datos hoy
    </div>
  )
}
