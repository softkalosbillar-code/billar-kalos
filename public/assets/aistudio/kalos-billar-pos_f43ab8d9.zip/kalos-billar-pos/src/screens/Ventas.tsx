import { useMemo, useState } from 'react'
import { ReceiptText } from 'lucide-react'
import { useApp } from '../state/AppContext'
import { money, shortDateTime } from '../lib/format'
import type { PaymentMethod } from '../lib/types'

const METHOD_LABEL: Record<PaymentMethod, string> = {
  efectivo: 'Efectivo',
  tarjeta: 'Tarjeta',
  transferencia: 'Transferencia',
  otro: 'Otro',
}

export function Ventas() {
  const { tabs } = useApp()
  const [all, setAll] = useState(false)

  const sales = useMemo(
    () =>
      tabs
        .filter((t) => t.status === 'cerrada')
        .sort((a, b) => (b.closedAt ?? 0) - (a.closedAt ?? 0)),
    [tabs],
  )

  const todayStart = new Date()
  todayStart.setHours(0, 0, 0, 0)
  const todaySales = sales.filter((t) => (t.closedAt ?? 0) >= todayStart.getTime())
  const shown = all ? sales : todaySales

  const total = shown.reduce((s, t) => s + (t.totals?.total ?? 0), 0)

  return (
    <div>
      <div className="flex items-end justify-between gap-4 mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-ink-1">Ventas</h1>
          <p className="text-sm text-ink-2 mt-1">
            {shown.length} tickets · {money(total)}
          </p>
        </div>
        <button
          onClick={() => setAll((v) => !v)}
          className="h-10 px-4 rounded-xl bg-surface-3 border border-white/10 text-sm font-medium text-ink-1 hover:border-white/25 transition"
        >
          {all ? 'Solo hoy' : 'Ver todas'}
        </button>
      </div>

      {shown.length === 0 ? (
        <div className="grid place-items-center py-20 text-center">
          <ReceiptText size={40} className="text-ink-3" />
          <p className="mt-3 text-ink-2">Sin ventas {all ? '' : 'hoy'}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {shown.map((t) => (
            <div
              key={t.id}
              className="flex items-center gap-4 rounded-card border border-white/10 bg-surface-2 p-4"
            >
              <div className="w-11 h-11 rounded-xl bg-brand-soft text-brand grid place-items-center text-lg shrink-0">
                🎱
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-ink-1">{t.tableName}</div>
                <div className="text-xs text-ink-3">
                  {shortDateTime(t.closedAt ?? t.openedAt)} ·{' '}
                  {t.items.length} productos + renta
                </div>
              </div>
              <div className="text-right shrink-0">
                <div className="font-display font-bold text-ink-1 tabular-nums">
                  {money(t.totals?.total ?? 0)}
                </div>
                <div className="text-xs text-ink-3 capitalize">
                  {t.payments[0] ? METHOD_LABEL[t.payments[0].method] : '—'}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
