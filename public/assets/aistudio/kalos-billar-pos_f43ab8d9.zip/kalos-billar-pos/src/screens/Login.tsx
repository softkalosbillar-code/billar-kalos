import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ChevronRight, ShieldCheck, UserRound } from 'lucide-react'
import { useApp } from '../state/AppContext'
import { Logo } from '../components/Logo'
import type { Role } from '../lib/types'

export function Login() {
  const { signIn, user } = useApp()
  const navigate = useNavigate()
  const [name, setName] = useState('')

  useEffect(() => {
    if (user) navigate('/', { replace: true })
  }, [user, navigate])

  async function enter(role: Role) {
    const n = name.trim() || (role === 'admin' ? 'Administrador' : 'Cajero')
    await signIn(n, role)
    navigate('/', { replace: true })
  }

  return (
    <div className="min-h-dvh bg-bg grid place-items-center px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center text-center">
          <Logo variant="full" height={120} />
          <h1 className="mt-8 font-display text-2xl font-bold text-ink-1">
            Punto de venta
          </h1>
          <p className="mt-1 text-sm text-ink-2">
            Renta de mesas por tiempo · productos · cobro
          </p>
        </div>

        <div className="mt-8 space-y-3">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Tu nombre (opcional)"
            className="w-full h-12 px-4 rounded-xl bg-surface-2 border border-white/10 text-ink-1 placeholder:text-ink-3 focus:outline-none focus:border-brand/60 focus:ring-2 focus:ring-brand/20 transition"
          />
          <button
            onClick={() => enter('cajero')}
            className="w-full h-14 rounded-xl bg-surface-3 border border-white/10 hover:border-white/25 text-ink-1 font-semibold flex items-center justify-between px-5 active:scale-[0.98] transition"
          >
            <span className="flex items-center gap-3">
              <UserRound size={20} className="text-brand" />
              Entrar como Cajero
            </span>
            <ChevronRight size={20} className="text-ink-3" />
          </button>
          <button
            onClick={() => enter('admin')}
            className="w-full h-14 rounded-xl bg-brand text-brand-on font-semibold flex items-center justify-between px-5 hover:bg-brand-hover active:scale-[0.98] transition"
          >
            <span className="flex items-center gap-3">
              <ShieldCheck size={20} />
              Entrar como Administrador
            </span>
            <ChevronRight size={20} />
          </button>
        </div>

        <p className="mt-6 text-center text-xs text-ink-3">
          Modo demostración — datos locales. Conecta Firebase para sincronizar en
          la nube.
        </p>
      </div>
    </div>
  )
}
