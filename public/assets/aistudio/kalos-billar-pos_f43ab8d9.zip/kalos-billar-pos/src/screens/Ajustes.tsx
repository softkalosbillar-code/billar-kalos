import { useState, type ReactNode } from 'react'
import { Save } from 'lucide-react'
import { useApp } from '../state/AppContext'
import { ROUNDING_LABELS } from '../lib/time'
import type { RoundingMode } from '../lib/types'

export function Ajustes() {
  const { settings, saveSettings, notify } = useApp()
  const [draft, setDraft] = useState(settings)
  const [saving, setSaving] = useState(false)

  async function save() {
    setSaving(true)
    await saveSettings(draft)
    notify('Ajustes guardados', 'success')
    setSaving(false)
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-display text-2xl font-bold text-ink-1">Ajustes</h1>
        <p className="text-sm text-ink-2 mt-1">
          Tarifas, redondeo e impuestos del negocio
        </p>
      </div>

      <div className="max-w-lg space-y-5">
        <Field label="Nombre del negocio">
          <input
            value={draft.venueName}
            onChange={(e) => setDraft({ ...draft, venueName: e.target.value })}
            className={inputCls}
          />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label={`${draft.taxName} (%)`}>
            <input
              inputMode="decimal"
              value={String(Math.round(draft.defaultTaxRate * 100))}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  defaultTaxRate: (Number(e.target.value) || 0) / 100,
                })
              }
              className={inputCls}
            />
          </Field>
          <Field label="Mínimo de renta (min)">
            <input
              inputMode="numeric"
              value={String(draft.minimumMinutes)}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  minimumMinutes: Math.max(0, Number(e.target.value) || 0),
                })
              }
              className={inputCls}
            />
          </Field>
        </div>

        <Field label="Redondeo de tiempo">
          <select
            value={draft.rounding}
            onChange={(e) =>
              setDraft({ ...draft, rounding: e.target.value as RoundingMode })
            }
            className={inputCls}
          >
            {(Object.keys(ROUNDING_LABELS) as RoundingMode[]).map((m) => (
              <option key={m} value={m} className="bg-surface-4">
                {ROUNDING_LABELS[m]}
              </option>
            ))}
          </select>
        </Field>

        <label className="flex items-center gap-3 text-sm text-ink-2">
          <input
            type="checkbox"
            checked={draft.tipEnabled}
            onChange={(e) => setDraft({ ...draft, tipEnabled: e.target.checked })}
            className="w-4 h-4 accent-[#E6B349]"
          />
          Permitir propina al cobrar
        </label>

        <div className="rounded-card border border-white/10 bg-surface-2 p-4 text-xs text-ink-3 leading-relaxed">
          <p>
            Ejemplo: mesa de $60/h, mínimo 30 min, redondeo a cuarto de hora. Una
            renta de 1h05m se factura como 1.25h = <strong className="text-ink-1">$75</strong>{' '}
            + IVA.
          </p>
        </div>

        <button
          onClick={save}
          disabled={saving}
          className="inline-flex items-center gap-2 h-12 px-6 rounded-xl bg-brand text-brand-on font-bold hover:bg-brand-hover disabled:opacity-50 transition"
        >
          <Save size={18} />
          Guardar cambios
        </button>
      </div>
    </div>
  )
}

const inputCls =
  'mt-1.5 w-full h-11 px-3.5 rounded-xl bg-surface-3 border border-white/10 text-ink-1 focus:outline-none focus:border-brand/60 transition'

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <label className="text-xs text-ink-3 uppercase tracking-wider">{label}</label>
      {children}
    </div>
  )
}
