import { useMemo, useState } from 'react'
import { CircleDollarSign } from 'lucide-react'
import { useApp } from '../state/AppContext'
import { money, shortDateTime } from '../lib/format'
import { Modal } from '../components/Modal'
import type { PaymentMethod } from '../lib/types'

const METHOD_LABEL: Record<PaymentMethod, string> = {
  efectivo: 'Efectivo',
  tarjeta: 'Tarjeta',
  transferencia: 'Transferencia',
  otro: 'Otro',
}

export function Caja() {
  const { tabs, shift, openShift, closeShift } = useApp()
  const [openModal, setOpenModal] = useState(false)
  const [closeModal, setCloseModal] = useState(false)
  const [cash, setCash] = useState('')

  const todayStart = new Date()
  todayStart.setHours(0, 0, 0, 0)
  const todaySales = useMemo(
    () =>
      tabs.filter(
        (t) => t.status === 'cerrada' && (t.closedAt ?? 0) >= todayStart.getTime(),
      ),
    [tabs, todayStart],
  )

  const byMethod = useMemo(() => {
    const m = new Map<PaymentMethod, number>()
    for (const t of todaySales)
      for (const p of t.payments) m.set(p.method, (m.get(p.method) ?? 0) + p.amount)
    return m
  }, [todaySales])

  const total = todaySales.reduce((s, t) => s + (t.totals?.total ?? 0), 0)

  return (
    <div>
      <div className="flex items-end justify-between gap-4 mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-ink-1">Caja</h1>
          <p className="text-sm text-ink-2 mt-1">
            {shift
              ? `Turno abierto desde ${shortDateTime(shift.openedAt)}`
              : 'No hay turno abierto'}
          </p>
        </div>
        {shift ? (
          <button
            onClick={() => setCloseModal(true)}
            className="h-11 px-4 rounded-xl bg-surface-3 border border-white/10 text-ink-1 font-semibold hover:border-white/25 transition"
          >
            Cerrar turno
          </button>
        ) : (
          <button
            onClick={() => setOpenModal(true)}
            className="h-11 px-4 rounded-xl bg-brand text-brand-on font-semibold hover:bg-brand-hover transition"
          >
            Abrir turno
          </button>
        )}
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Ventas hoy" value={money(total)} accent />
        <StatCard label="Tickets" value={String(todaySales.length)} />
        {(['efectivo', 'tarjeta', 'transferencia', 'otro'] as PaymentMethod[]).map(
          (m) =>
            (byMethod.get(m) ?? 0) > 0 && (
              <StatCard key={m} label={METHOD_LABEL[m]} value={money(byMethod.get(m)!)} />
            ),
        )}
      </div>

      {shift && (
        <div className="mt-5 rounded-card border border-white/10 bg-surface-2 p-5">
          <div className="flex items-center gap-3">
            <CircleDollarSign size={22} className="text-brand" />
            <div>
              <div className="text-sm text-ink-2">Fondo de apertura</div>
              <div className="font-display text-xl font-bold text-ink-1 tabular-nums">
                {money(shift.openingCash)}
              </div>
            </div>
          </div>
        </div>
      )}

      <Modal open={openModal} onClose={() => setOpenModal(false)} title="Abrir turno">
        <p className="text-sm text-ink-2">Ingresa el efectivo inicial de la caja.</p>
        <input
          inputMode="decimal"
          value={cash}
          onChange={(e) => setCash(e.target.value)}
          placeholder="500.00"
          className="mt-4 w-full h-12 px-4 rounded-xl bg-surface-3 border border-white/10 text-ink-1 font-mono text-lg focus:outline-none focus:border-brand/60"
        />
        <button
          onClick={async () => {
            await openShift(Number(cash) || 0)
            setCash('')
            setOpenModal(false)
          }}
          className="mt-4 w-full h-12 rounded-xl bg-brand text-brand-on font-bold hover:bg-brand-hover transition"
        >
          Abrir turno
        </button>
      </Modal>

      <Modal open={closeModal} onClose={() => setCloseModal(false)} title="Cerrar turno">
        <p className="text-sm text-ink-2">
          Registra el efectivo final para calcular el arqueo.
        </p>
        <div className="mt-4 rounded-card bg-surface-3 border border-white/10 p-4">
          <div className="flex justify-between text-sm text-ink-2">
            <span>Ventas del turno</span>
            <span className="text-ink-1 tabular-nums font-medium">{money(total)}</span>
          </div>
        </div>
        <input
          inputMode="decimal"
          value={cash}
          onChange={(e) => setCash(e.target.value)}
          placeholder="Efectivo final"
          className="mt-4 w-full h-12 px-4 rounded-xl bg-surface-3 border border-white/10 text-ink-1 font-mono text-lg focus:outline-none focus:border-brand/60"
        />
        <button
          onClick={async () => {
            await closeShift(Number(cash) || 0)
            setCash('')
            setCloseModal(false)
          }}
          className="mt-4 w-full h-12 rounded-xl bg-brand text-brand-on font-bold hover:bg-brand-hover transition"
        >
          Cerrar turno
        </button>
      </Modal>
    </div>
  )
}

function StatCard({
  label,
  value,
  accent,
}: {
  label: string
  value: string
  accent?: boolean
}) {
  return (
    <div className="rounded-card border border-white/10 bg-surface-2 p-4">
      <div className="text-xs text-ink-3 uppercase tracking-wider">{label}</div>
      <div
        className={`mt-1.5 font-display text-xl font-bold tabular-nums ${
          accent ? 'text-brand' : 'text-ink-1'
        }`}
      >
        {value}
      </div>
    </div>
  )
}
