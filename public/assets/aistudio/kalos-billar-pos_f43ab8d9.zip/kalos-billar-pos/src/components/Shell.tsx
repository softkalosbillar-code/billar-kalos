import { useState } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import {
  BarChart3,
  Coins,
  Ellipsis,
  LogOut,
  Package,
  Settings,
  Table2,
  TrendingUp,
  type LucideIcon,
} from 'lucide-react'
import { useApp } from '../state/AppContext'
import { Logo } from './Logo'

interface NavItem {
  to: string
  label: string
  icon: LucideIcon
  admin?: boolean
  end?: boolean
}

const PRIMARY: NavItem[] = [
  { to: '/', label: 'Mesas', icon: Table2, end: true },
  { to: '/productos', label: 'Productos', icon: Package },
  { to: '/ventas', label: 'Ventas', icon: TrendingUp },
  { to: '/caja', label: 'Caja', icon: Coins },
]

const SECONDARY: NavItem[] = [
  { to: '/reportes', label: 'Reportes', icon: BarChart3, admin: true },
  { to: '/ajustes', label: 'Ajustes', icon: Settings, admin: true },
]

function isAdmin(role: string | undefined) {
  return role === 'admin'
}

export function Shell() {
  const { user, signOut, store } = useApp()
  const navigate = useNavigate()
  const [moreOpen, setMoreOpen] = useState(false)

  const admin = isAdmin(user?.role)
  const visible = [...PRIMARY, ...SECONDARY.filter((i) => !i.admin || admin)]

  async function onSignOut() {
    await signOut()
    navigate('/login')
  }

  return (
    <div className="min-h-dvh bg-bg text-ink-1">
      {/* Sidebar rail (escritorio) */}
      <aside className="hidden lg:flex fixed inset-y-0 left-0 w-20 flex-col items-center border-r border-white/10 bg-surface-1 z-40">
        <div className="py-5">
          <Logo variant="mark" height={40} className="rounded-xl" />
        </div>
        <nav className="flex-1 flex flex-col items-center gap-1 w-full px-2">
          {visible.map((item) => (
            <RailLink key={item.to} item={item} />
          ))}
        </nav>
        <button
          onClick={onSignOut}
          className="mb-5 p-3 rounded-xl text-ink-3 hover:text-ink-1 hover:bg-white/5 transition-colors"
          title="Cerrar sesión"
        >
          <LogOut size={22} />
        </button>
      </aside>

      {/* Main */}
      <div className="lg:pl-20 flex flex-col min-h-dvh">
        <header className="sticky top-0 z-30 flex items-center justify-between px-4 sm:px-6 h-16 border-b border-white/10 bg-bg/80 backdrop-blur-xl">
          <div className="flex items-center gap-3">
            <Logo variant="full" height={30} className="lg:hidden" />
            <span className="hidden lg:flex items-center gap-2">
              <Logo variant="mark" height={24} className="rounded-md opacity-90" />
              <span className="font-display font-semibold text-ink-1">
                Kalos Billar Club
              </span>
            </span>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 rounded-full bg-surface-2 border border-white/10 pl-1 pr-3 py-1">
              <div className="w-7 h-7 rounded-full bg-brand text-brand-on grid place-items-center text-xs font-bold uppercase">
                {user?.name?.charAt(0) ?? 'U'}
              </div>
              <div className="leading-tight">
                <div className="text-sm font-semibold text-ink-1">{user?.name}</div>
                <div className="text-[11px] text-ink-3 capitalize">{user?.role}</div>
              </div>
            </div>
            {store.mode === 'demo' && (
              <span className="hidden sm:inline-flex text-[11px] font-medium px-2 py-1 rounded-full bg-brand-soft text-brand">
                Modo demo
              </span>
            )}
          </div>
        </header>

        <main className="flex-1 px-4 sm:px-6 py-5 pb-28 lg:pb-8 max-w-6xl w-full mx-auto">
          <Outlet />
        </main>
      </div>

      {/* Bottom nav (móvil/tablet) */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 border-t border-white/10 bg-surface-1/80 backdrop-blur-xl pb-[env(safe-area-inset-bottom)]">
        <div className="grid grid-cols-5 h-16">
          {PRIMARY.map((item) => (
            <BottomLink key={item.to} item={item} />
          ))}
          <button
            onClick={() => setMoreOpen((v) => !v)}
            className="flex flex-col items-center justify-center gap-1 text-ink-3"
          >
            <Ellipsis size={22} />
            <span className="text-[11px] font-medium">Más</span>
          </button>
        </div>
        {moreOpen && (
          <div className="absolute bottom-20 right-3 left-3 sm:left-auto sm:w-64 rounded-modal bg-surface-4 border border-white/10 shadow-popover p-2 animate-rise">
            {SECONDARY.filter((i) => !i.admin || admin).map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={() => setMoreOpen(false)}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium ${
                    isActive ? 'bg-brand-soft text-brand' : 'text-ink-2'
                  }`
                }
              >
                <item.icon size={20} />
                {item.label}
              </NavLink>
            ))}
            <button
              onClick={onSignOut}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-ink-2"
            >
              <LogOut size={20} />
              Cerrar sesión
            </button>
          </div>
        )}
      </nav>
    </div>
  )
}

function RailLink({ item }: { item: NavItem }) {
  return (
    <NavLink
      to={item.to}
      end={item.end}
      title={item.label}
      className={({ isActive }) =>
        `group flex flex-col items-center justify-center gap-1 w-full h-14 rounded-xl transition-colors ${
          isActive
            ? 'bg-brand-soft text-brand'
            : 'text-ink-3 hover:text-ink-1 hover:bg-white/5'
        }`
      }
    >
      {({ isActive }) => (
        <>
          <item.icon size={22} strokeWidth={isActive ? 2.2 : 1.75} />
          <span className="text-[11px] font-medium">{item.label}</span>
        </>
      )}
    </NavLink>
  )
}

function BottomLink({ item }: { item: NavItem }) {
  return (
    <NavLink
      to={item.to}
      end={item.end}
      className={({ isActive }) =>
        `flex flex-col items-center justify-center gap-1 transition-colors ${
          isActive ? 'text-brand' : 'text-ink-3'
        }`
      }
    >
      {({ isActive }) => (
        <>
          <item.icon size={22} strokeWidth={isActive ? 2.2 : 1.75} />
          <span className="text-[11px] font-medium">{item.label}</span>
        </>
      )}
    </NavLink>
  )
}
