import { MoreVertical } from 'lucide-react'
import { facturableElapsedSec } from '../lib/time'
import { duration, money } from '../lib/format'
import { useNow } from '../state/AppContext'
import type { BilliardTable, Tab, TableStatus } from '../lib/types'

const STATUS_META: Record<
  TableStatus,
  { label: string; dot: string; text: string }
> = {
  libre: { label: 'Libre', dot: 'bg-ink-3', text: 'text-ink-3' },
  ocupada: { label: 'Rentada', dot: 'bg-brand animate-pulse', text: 'text-brand' },
  pausada: { label: 'Pausada', dot: 'bg-warning', text: 'text-warning' },
  por_cobrar: { label: 'Por cobrar', dot: 'bg-warning animate-pulse', text: 'text-warning' },
  limpieza: { label: 'Limpieza', dot: 'bg-info', text: 'text-info' },
  mantenimiento: { label: 'Mantenimiento', dot: 'bg-danger', text: 'text-danger' },
}

interface TableCardProps {
  table: BilliardTable
  tab: Tab | null
  onTap: () => void
  onMenu?: () => void
}

export function TableCard({ table, tab, onTap, onMenu }: TableCardProps) {
  const active = table.status === 'ocupada' || table.status === 'pausada'
  const now = useNow(active)
  const meta = STATUS_META[table.status]

  const elapsed = active && tab?.rental ? facturableElapsedSec(tab.rental, now) : 0

  return (
    <button
      onClick={onTap}
      className={`group relative text-left rounded-card border p-4 shadow-card transition-all duration-150 active:scale-[0.97] ${
        active
          ? 'bg-surface-2 border-brand/40'
          : 'bg-surface-2 border-white/10 hover:border-white/20'
      }`}
    >
      <div className="flex items-start justify-between">
        <div className="min-w-0">
          <div className="text-base font-semibold text-ink-1 leading-tight">
            {table.name}
          </div>
          <div className="text-xs text-ink-3 mt-0.5">{table.type}</div>
        </div>
        {onMenu && (
          <span
            role="button"
            tabIndex={0}
            onClick={(e) => {
              e.stopPropagation()
              onMenu()
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.stopPropagation()
                onMenu()
              }
            }}
            className="p-1.5 rounded-lg text-ink-3 hover:text-ink-1 hover:bg-white/10 transition-colors"
          >
            <MoreVertical size={18} />
          </span>
        )}
      </div>

      <div className="mt-4 h-10 flex items-end">
        {active ? (
          <span className="font-mono text-2xl font-semibold text-ink-1 tabular-nums tracking-tight">
            {duration(elapsed)}
          </span>
        ) : table.status === 'libre' ? (
          <span className="text-2xl text-ink-2 font-display font-semibold">
            {money(table.ratePerHour)}
            <span className="text-sm font-normal text-ink-3">/h</span>
          </span>
        ) : (
          <span className="text-xl text-ink-2 font-display font-semibold">
            {meta.label}
          </span>
        )}
      </div>

      <div className="mt-3 flex items-center justify-between">
        <span className="inline-flex items-center gap-1.5 text-xs font-medium">
          <span className={`w-2 h-2 rounded-full ${meta.dot}`} />
          <span className={meta.text}>{meta.label}</span>
        </span>
        <span className="text-xs text-ink-3 tabular-nums">
          {money(table.ratePerHour)}/h
        </span>
      </div>
    </button>
  )
}
