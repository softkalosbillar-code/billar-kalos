import type { ReactNode } from 'react'
import { HashRouter, Navigate, Route, Routes } from 'react-router-dom'
import { AlertCircle, CheckCircle2, Info } from 'lucide-react'
import { AppProvider, useApp } from './state/AppContext'
import { Shell } from './components/Shell'
import { Login } from './screens/Login'
import { Mesas } from './screens/Mesas'
import { CuentaMesa } from './screens/CuentaMesa'
import { Productos } from './screens/Productos'
import { Ventas } from './screens/Ventas'
import { Caja } from './screens/Caja'
import { Reportes } from './screens/Reportes'
import { Ajustes } from './screens/Ajustes'

function RequireAuth({ children }: { children: ReactNode }) {
  const { user, loading } = useApp()
  if (loading) return <Splash />
  if (!user) return <Navigate to="/login" replace />
  return <>{children}</>
}

function Splash() {
  return (
    <div className="min-h-dvh grid place-items-center bg-bg">
      <div className="w-8 h-8 rounded-full border-2 border-brand border-t-transparent animate-spin" />
    </div>
  )
}

function Toasts() {
  const { toasts } = useApp()
  return (
    <div className="fixed top-4 right-4 z-[70] space-y-2 w-[calc(100%-2rem)] max-w-xs pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="flex items-start gap-3 rounded-xl border border-white/10 bg-surface-4/95 backdrop-blur shadow-popover px-4 py-3 animate-rise"
        >
          {t.type === 'success' ? (
            <CheckCircle2 size={18} className="text-success shrink-0" />
          ) : t.type === 'error' ? (
            <AlertCircle size={18} className="text-danger shrink-0" />
          ) : (
            <Info size={18} className="text-info shrink-0" />
          )}
          <span className="text-sm text-ink-1 flex-1">{t.message}</span>
        </div>
      ))}
    </div>
  )
}

export default function App() {
  return (
    <AppProvider>
      <HashRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            path="/mesa/:tabId"
            element={
              <RequireAuth>
                <CuentaMesa />
              </RequireAuth>
            }
          />
          <Route
            path="/"
            element={
              <RequireAuth>
                <Shell />
              </RequireAuth>
            }
          >
            <Route index element={<Mesas />} />
            <Route path="productos" element={<Productos />} />
            <Route path="ventas" element={<Ventas />} />
            <Route path="caja" element={<Caja />} />
            <Route path="reportes" element={<Reportes />} />
            <Route path="ajustes" element={<Ajustes />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        <Toasts />
      </HashRouter>
    </AppProvider>
  )
}
